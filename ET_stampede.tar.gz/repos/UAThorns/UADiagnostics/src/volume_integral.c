/* This code is not finished and likely buggy. The computation of the charge
   seems fine, but the ADM Mass is not consistent with what I expect if the
   horizons are excised. Someone should fix it. */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>

#include "SpaceMask.h"

#define PI 3.1415926535897932384626433832795028841971693993751058209749445923

void ADMMass_Volume(CCTK_ARGUMENTS);

void ADMMass_Volume_Global(CCTK_ARGUMENTS);


void ADMMass_Volume(CCTK_ARGUMENTS){
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  if(compute_every <= 0 || cctk_iteration % compute_every != 0) return;

  CCTK_REAL radius;
  CCTK_REAL origin_x, origin_y, origin_z, distance;

  CCTK_INT *N_horizons;         /* At the moment the thorn requires AHFinderDirect */
  N_horizons = ((CCTK_INT *) CCTK_ParameterGet("N_horizons", "AHFinderDirect", NULL));
  if ((N_horizons == NULL) || (*N_horizons < 0)) N_horizons = 0;

  /* Here we prepare a mask with zeros and ones. The points with zero are inside
     an horizon, the points with one outside. */

#pragma omp parallel for
  for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++)
    horizon_mask[ijk] = 1.0;

  for (int horizon = 1; horizon <= *N_horizons; horizon++)
    if (HorizonWasFound(horizon)) {
      HorizonLocalCoordinateOrigin(horizon, &origin_x, &origin_y, &origin_z);
      if (HorizonRadiusInDirection(horizon,
                                   cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2],
                                   x, y, z,
                                   radius_h) >= 0) { /* Detg contains the radius here */
        /* #pragma omp parallel for private(i,j,k) */
#pragma omp parallel for
        for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++) {
                /* calculate the distance to the origin of the horizon */
                CCTK_REAL distance = sqrt((x[ijk]-origin_x)*(x[ijk]-origin_x) +
                                          (y[ijk]-origin_y)*(y[ijk]-origin_y) +
                                          (z[ijk]-origin_z)*(z[ijk]-origin_z));
                /* from that, calculate the distance to the horizon */
                /* -> will be negative in the inside */
                if (distance > 0.0)
                  distance = distance - radius_h[ijk]; /* detg here is horizon radius */
                else
                  distance = -1.0;
                /* if it is inside the horizon, set the mask accordingly */
                if (distance <= 0.0)
                  horizon_mask[ijk] *= 0.0;
              }
      }
    }

  CCTK_INT i,j,k;

  /* grid-function strides */
  const CCTK_INT di = 1;
  const CCTK_INT dj = cctk_lsh[0];
  const CCTK_INT dk = cctk_lsh[0]*cctk_lsh[1];

  /* denominators for derivatives */
  const CCTK_REAL OneOverTwoDX = 1.0 / (2.0 * CCTK_DELTA_SPACE(0));
  const CCTK_REAL OneOverTwoDY = 1.0 / (2.0 * CCTK_DELTA_SPACE(1));
  const CCTK_REAL OneOverTwoDZ = 1.0 / (2.0 * CCTK_DELTA_SPACE(2));
  const CCTK_REAL OneOverTwelveDX = 1.0 / (12.0 * CCTK_DELTA_SPACE(0));
  const CCTK_REAL OneOverTwelveDY = 1.0 / (12.0 * CCTK_DELTA_SPACE(1));
  const CCTK_REAL OneOverTwelveDZ = 1.0 / (12.0 * CCTK_DELTA_SPACE(2));

  if (ADMMass_use_surface_distance_as_volume_radius && (volume_radius[*LoopCounter] < 0.0))
    radius = surface_distance[*LoopCounter];
  else
    radius = volume_radius[*LoopCounter];

  if ((radius <= 0.0)&&(!ADMMass_use_all_volume_as_volume_radius))
    {
      CCTK_WARN(2, "radius < 0 / not set, not calculating "
                "the volume integral to get the ADM mass.");
      return;
    }

#pragma omp parallel for
  for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++){
    ADMMass_VolumeMass_GF[ijk] = 0.0;
    Charge_Volume_GF[ijk] = 0.0;
    ADMMass_VolumeMass_pot_x[ijk] = 0.0;
    ADMMass_VolumeMass_pot_y[ijk] = 0.0;
    ADMMass_VolumeMass_pot_z[ijk] = 0.0;
  }

  int ghostzones_needed = 0;
  if      (derivs_order == 2) ghostzones_needed = 1;
  else if (derivs_order == 4) ghostzones_needed = 2;

#pragma omp parallel for private(i,j,k)
  for(k=ghostzones_needed; k<cctk_lsh[2]-ghostzones_needed; k++)
    for(j=ghostzones_needed; j<cctk_lsh[1]-ghostzones_needed; j++)
      for(i=ghostzones_needed; i<cctk_lsh[0]-ghostzones_needed; i++) {

        CCTK_INT  ti, tj, tk;
        CCTK_INT ijk = CCTK_GFINDEX3D(cctkGH, i, j, k);

        CCTK_REAL dEi[3];
        CCTK_REAL dsqrt_gamma[3];

        CCTK_REAL u[3][3], dg[3][3][3];

        u[0][0] = (gyy[ijk] * gzz[ijk] - gyz[ijk] * gyz[ijk]) / detg[ijk];
        u[1][1] = (gxx[ijk] * gzz[ijk] - gxz[ijk] * gxz[ijk]) / detg[ijk];
        u[2][2] = (gxx[ijk] * gyy[ijk] - gxy[ijk] * gxy[ijk]) / detg[ijk];
        u[0][1] = (gxz[ijk] * gyz[ijk] - gxy[ijk] * gzz[ijk]) / detg[ijk];
        u[0][2] = (gxy[ijk] * gyz[ijk] - gxz[ijk] * gyy[ijk]) / detg[ijk];
        u[1][2] = (gxz[ijk] * gxy[ijk] - gyz[ijk] * gxx[ijk]) / detg[ijk];
        u[1][0] = u[0][1];
        u[2][0] = u[0][2];
        u[2][1] = u[1][2];

        if (derivs_order == 2){

          dg[0][0][0] = ( gxx[di+ijk] - gxx[-di+ijk] ) * OneOverTwoDX;
          dg[0][0][1] = ( gxx[dj+ijk] - gxx[-dj+ijk] ) * OneOverTwoDY;
          dg[0][0][2] = ( gxx[dk+ijk] - gxx[-dk+ijk] ) * OneOverTwoDZ;

          dg[0][1][0] = ( gxy[di+ijk] - gxy[-di+ijk] ) * OneOverTwoDX;
          dg[0][1][1] = ( gxy[dj+ijk] - gxy[-dj+ijk] ) * OneOverTwoDY;
          dg[0][1][2] = ( gxy[dk+ijk] - gxy[-dk+ijk] ) * OneOverTwoDZ;

          dg[0][2][0] = ( gxz[di+ijk] - gxz[-di+ijk] ) * OneOverTwoDX;
          dg[0][2][1] = ( gxz[dj+ijk] - gxz[-dj+ijk] ) * OneOverTwoDY;
          dg[0][2][2] = ( gxz[dk+ijk] - gxz[-dk+ijk] ) * OneOverTwoDZ;

          dg[1][0][0] = dg[0][1][0];
          dg[1][0][1] = dg[0][1][1];
          dg[1][0][2] = dg[0][1][2];

          dg[1][1][0] = ( gyy[di+ijk] - gyy[-di+ijk] ) * OneOverTwoDX;
          dg[1][1][1] = ( gyy[dj+ijk] - gyy[-dj+ijk] ) * OneOverTwoDY;
          dg[1][1][2] = ( gyy[dk+ijk] - gyy[-dk+ijk] ) * OneOverTwoDZ;

          dg[1][2][0] = ( gyz[di+ijk] - gyz[-di+ijk] ) * OneOverTwoDX;
          dg[1][2][1] = ( gyz[dj+ijk] - gyz[-dj+ijk] ) * OneOverTwoDY;
          dg[1][2][2] = ( gyz[dk+ijk] - gyz[-dk+ijk] ) * OneOverTwoDZ;

          dg[2][0][0] = dg[0][2][0];
          dg[2][0][1] = dg[0][2][1];
          dg[2][0][2] = dg[0][2][2];

          dg[2][1][0] = dg[1][2][0];
          dg[2][1][1] = dg[1][2][1];
          dg[2][1][2] = dg[1][2][2];

          dg[2][2][0] = ( gzz[di+ijk] - gzz[-di+ijk] ) * OneOverTwoDX;
          dg[2][2][1] = ( gzz[dj+ijk] - gzz[-dj+ijk] ) * OneOverTwoDY;
          dg[2][2][2] = ( gzz[dk+ijk] - gzz[-dk+ijk] ) * OneOverTwoDZ;

          dEi[0] = ( Ex[di+ijk] - Ex[-di+ijk] ) * OneOverTwoDX;
          dEi[1] = ( Ey[dj+ijk] - Ey[-dj+ijk] ) * OneOverTwoDY;
          dEi[2] = ( Ez[dk+ijk] - Ez[-dk+ijk] ) * OneOverTwoDZ;

          dsqrt_gamma[0] = ( sqrt(detg[di+ijk]) - sqrt(detg[-di+ijk]) ) * OneOverTwoDX;
          dsqrt_gamma[1] = ( sqrt(detg[dj+ijk]) - sqrt(detg[-dj+ijk]) ) * OneOverTwoDY;
          dsqrt_gamma[2] = ( sqrt(detg[dk+ijk]) - sqrt(detg[-dk+ijk]) ) * OneOverTwoDZ;

        }else if (derivs_order == 4){

          dg[0][0][0] = ( -gxx[2*di+ijk] + 8 * gxx[di+ijk] - 8 * gxx[-di+ijk] + gxx[-2*di+ijk] ) * OneOverTwelveDX;
          dg[0][0][1] = ( -gxx[2*dj+ijk] + 8 * gxx[dj+ijk] - 8 * gxx[-dj+ijk] + gxx[-2*dj+ijk] ) * OneOverTwelveDY;
          dg[0][0][2] = ( -gxx[2*dk+ijk] + 8 * gxx[dk+ijk] - 8 * gxx[-dk+ijk] + gxx[-2*dk+ijk] ) * OneOverTwelveDZ;

          dg[0][1][0] = ( -gxy[2*di+ijk] + 8 * gxy[di+ijk] - 8 * gxy[-di+ijk] + gxy[-2*di+ijk] ) * OneOverTwelveDX;
          dg[0][1][1] = ( -gxy[2*dj+ijk] + 8 * gxy[dj+ijk] - 8 * gxy[-dj+ijk] + gxy[-2*dj+ijk] ) * OneOverTwelveDY;
          dg[0][1][2] = ( -gxy[2*dk+ijk] + 8 * gxy[dk+ijk] - 8 * gxy[-dk+ijk] + gxy[-2*dk+ijk] ) * OneOverTwelveDZ;

          dg[0][2][0] = ( -gxz[2*di+ijk] + 8 * gxz[di+ijk] - 8 * gxz[-di+ijk] + gxz[-2*di+ijk] ) * OneOverTwelveDX;
          dg[0][2][1] = ( -gxz[2*dj+ijk] + 8 * gxz[dj+ijk] - 8 * gxz[-dj+ijk] + gxz[-2*dj+ijk] ) * OneOverTwelveDY;
          dg[0][2][2] = ( -gxz[2*dk+ijk] + 8 * gxz[dk+ijk] - 8 * gxz[-dk+ijk] + gxz[-2*dk+ijk] ) * OneOverTwelveDZ;

          dg[1][0][0] = dg[0][1][0];
          dg[1][0][1] = dg[0][1][1];
          dg[1][0][2] = dg[0][1][2];

          dg[1][1][0] = ( -gyy[2*di+ijk] + 8 * gyy[di+ijk] - 8 * gyy[-di+ijk] + gyy[-2*di+ijk] ) * OneOverTwelveDX;
          dg[1][1][1] = ( -gyy[2*dj+ijk] + 8 * gyy[dj+ijk] - 8 * gyy[-dj+ijk] + gyy[-2*dj+ijk] ) * OneOverTwelveDY;
          dg[1][1][2] = ( -gyy[2*dk+ijk] + 8 * gyy[dk+ijk] - 8 * gyy[-dk+ijk] + gyy[-2*dk+ijk] ) * OneOverTwelveDZ;

          dg[1][2][0] = ( -gyz[2*di+ijk] + 8 * gyz[di+ijk] - 8 * gyz[-di+ijk] + gyz[-2*di+ijk] ) * OneOverTwelveDX;
          dg[1][2][1] = ( -gyz[2*dj+ijk] + 8 * gyz[dj+ijk] - 8 * gyz[-dj+ijk] + gyz[-2*dj+ijk] ) * OneOverTwelveDY;
          dg[1][2][2] = ( -gyz[2*dk+ijk] + 8 * gyz[dk+ijk] - 8 * gyz[-dk+ijk] + gyz[-2*dk+ijk] ) * OneOverTwelveDZ;

          dg[2][0][0] = dg[0][2][0];
          dg[2][0][1] = dg[0][2][1];
          dg[2][0][2] = dg[0][2][2];

          dg[2][1][0] = dg[1][2][0];
          dg[2][1][1] = dg[1][2][1];
          dg[2][1][2] = dg[1][2][2];

          dg[2][2][0] = ( -gzz[2*di+ijk] + 8 * gzz[di+ijk] - 8 * gzz[-di+ijk] + gzz[-2*di+ijk] ) * OneOverTwelveDX;
          dg[2][2][1] = ( -gzz[2*dj+ijk] + 8 * gzz[dj+ijk] - 8 * gzz[-dj+ijk] + gzz[-2*dj+ijk] ) * OneOverTwelveDY;
          dg[2][2][2] = ( -gzz[2*dk+ijk] + 8 * gzz[dk+ijk] - 8 * gzz[-dk+ijk] + gzz[-2*dk+ijk] ) * OneOverTwelveDZ;

          dEi[0] = ( - Ex[ 2*di+ijk] + 8 * Ex[ di+ijk] - 8 * Ex[-di+ijk] + Ex[-2*di+ijk] ) * OneOverTwelveDX;
          dEi[1] = ( - Ey[ 2*dj+ijk] + 8 * Ey[ dj+ijk] - 8 * Ey[-dj+ijk] + Ey[-2*dj+ijk] ) * OneOverTwelveDY;
          dEi[2] = ( - Ez[ 2*dk+ijk] + 8 * Ez[ dk+ijk] - 8 * Ez[-dk+ijk] + Ez[-2*dk+ijk] ) * OneOverTwelveDZ;

          dsqrt_gamma[0] = ( -     sqrt(detg[ 2*di+ijk]) + 8 * sqrt(detg[ di+ijk])
                             - 8 * sqrt(detg[-di+ijk])   +     sqrt(detg[-2*di+ijk]) ) * OneOverTwelveDX;
          dsqrt_gamma[1] = ( -     sqrt(detg[ 2*dj+ijk]) + 8 * sqrt(detg[ dj+ijk])
                             - 8 * sqrt(detg[-dj+ijk])   +     sqrt(detg[-2*dj+ijk]) ) * OneOverTwelveDY;
          dsqrt_gamma[2] = ( -     sqrt(detg[ 2*dk+ijk]) + 8 * sqrt(detg[ dk+ijk])
                             - 8 * sqrt(detg[-dk+ijk])   +     sqrt(detg[-2*dk+ijk]) ) * OneOverTwelveDZ;

        }else{
          CCTK_WARN(0, "derivs_order non implemented!");
        }

        for (ti = 0; ti < 3; ti++)
          for (tj = 0; tj < 3; tj++)
            for (tk = 0; tk < 3; tk++)
              {
                ADMMass_VolumeMass_pot_x[ijk] += u[ti][tj] * u[tk][0] * ( dg[ti][tk][tj] - dg[ti][tj][tk] );
                ADMMass_VolumeMass_pot_y[ijk] += u[ti][tj] * u[tk][1] * ( dg[ti][tk][tj] - dg[ti][tj][tk] );
                ADMMass_VolumeMass_pot_z[ijk] += u[ti][tj] * u[tk][2] * ( dg[ti][tk][tj] - dg[ti][tj][tk] );
              }

        CCTK_REAL ef[3] = {Ex[ijk], Ey[ijk], Ez[ijk]};

        for (ti = 0; ti < 3; ti++)
          Charge_Volume_GF[ijk] += sqrt(detg[ijk]) * dEi[ti] + ef[ti] * dsqrt_gamma[ti];

        /* Charge_Volume_GF[ijk] += d_Ei[ti] - 1.5 * ef[ti] * d_ch[ti] / detg_chi[ijk]; */

        /* if (x[ijk] == 6.5 && y[ijk] == 0 && z[ijk] == 0){ */
        /*   printf("dsqrt_gamma %g, %g, %g\n", dsqrt_gamma_Ei[0], dsqrt_gamma_Ei[1], dsqrt_gamma_Ei[2]); */
        /*   printf("d sqrt %g, %g, %g\n", sqrt(detg[ijk])*d_Ei[0] + ef[0] * d_sqrt_gamma[0], */
        /*          sqrt(detg[ijk])*d_Ei[1] + ef[1] * d_sqrt_gamma[1], */
        /*          sqrt(detg[ijk])*d_Ei[2] + ef[2] * d_sqrt_gamma[2]); */
        /*   printf("d chi %g, %g, %g\n", sqrt(detg[ijk])*(d_Ei[0] - 1.5 * ef[0] * d_ch[0] / detg_chi[ijk]), */
        /*          sqrt(detg[ijk])*(d_Ei[1] - 1.5 * ef[1] * d_ch[1] / detg_chi[ijk]), */
        /*          sqrt(detg[ijk])*(d_Ei[2] - 1.5 * ef[2] * d_ch[1] / detg_chi[ijk])); */
        /*   printf("sqrt(detg) %g\n", sqrt(detg[ijk])); */
        /*   printf("OneOverTwelve %g, %g, %g\n", OneOverTwelveDX, OneOverTwelveDY, OneOverTwelveDZ); */
        /*   printf("E ch divE %g %g %g %g %g\n", ef[0], ef[1], ef[2], detg_chi[ijk], Charge_Volume_GF[ijk]); */
        /*   printf("dE %g %g %g\n", d_Ei[0], d_Ei[1], d_Ei[2]); */
        /*   printf("dch %g %g %g\n", d_ch[0], d_ch[1], d_ch[2]); */
        /*   printf("x1 %g %g %g %g\n", Ex[di+ijk], Ex[-di+ijk], detg_chi[di+ijk], detg_chi[-di+ijk]); */
        /*   printf("x2 %g %g %g %g\n", Ex[2*di+ijk], Ex[-2*di+ijk], detg_chi[2*di+ijk], detg_chi[-2*di+ijk]); */
        /*   printf("y1 %g %g %g %g\n", Ey[dj+ijk], Ey[-dj+ijk], detg_chi[dj+ijk], detg_chi[-dj+ijk]); */
        /*   printf("y2 %g %g %g %g\n", Ey[2*dj+ijk], Ey[-2*dj+ijk], detg_chi[2*dj+ijk], detg_chi[-2*dj+ijk]); */
        /*   printf("z1 %g %g %g %g\n", Ez[dk+ijk], Ez[-dk+ijk], detg_chi[dk+ijk], detg_chi[-dk+ijk]); */
        /*   printf("z2 %g %g %g %g\n", Ez[2*dk+ijk], Ez[-2*dk+ijk], detg_chi[2*dk+ijk], detg_chi[-2*dk+ijk]); */
        /* } */

        ADMMass_VolumeMass_pot_x[ijk] *= alp[ijk] * sqrt(detg[ijk]);
        ADMMass_VolumeMass_pot_y[ijk] *= alp[ijk] * sqrt(detg[ijk]);
        ADMMass_VolumeMass_pot_z[ijk] *= alp[ijk] * sqrt(detg[ijk]);
      }

  /* The treatment of ghostzones here is not very robust, but it should work
     with three ghostzones */
  for(k=cctk_nghostzones[2];k<cctk_lsh[2]-cctk_nghostzones[2];k++)
    for(j=cctk_nghostzones[1];j<cctk_lsh[1]-cctk_nghostzones[1];j++)
      for(i=cctk_nghostzones[0];i<cctk_lsh[0]-cctk_nghostzones[0];i++)
        {
          CCTK_INT ijk = CCTK_GFINDEX3D(cctkGH, i, j, k);

          if ((ADMMass_use_all_volume_as_volume_radius) ||
              ((x[ijk]-x_pos[*LoopCounter])* (x[ijk]-x_pos[*LoopCounter]) +
               (y[ijk]-y_pos[*LoopCounter])* (y[ijk]-y_pos[*LoopCounter]) +
               (z[ijk]-z_pos[*LoopCounter])* (z[ijk]-z_pos[*LoopCounter])
               <= radius * radius))
            {
              ADMMass_VolumeMass_GF[ijk] =
                ((ADMMass_VolumeMass_pot_x[CCTK_GFINDEX3D(cctkGH,i+1,j,k)]-
                  ADMMass_VolumeMass_pot_x[CCTK_GFINDEX3D(cctkGH,i-1,j,k)])*
                 OneOverTwoDX+
                 (ADMMass_VolumeMass_pot_y[CCTK_GFINDEX3D(cctkGH,i,j+1,k)]-
                  ADMMass_VolumeMass_pot_y[CCTK_GFINDEX3D(cctkGH,i,j-1,k)])*
                 OneOverTwoDY+
                 (ADMMass_VolumeMass_pot_z[CCTK_GFINDEX3D(cctkGH,i,j,k+1)]-
                  ADMMass_VolumeMass_pot_z[CCTK_GFINDEX3D(cctkGH,i,j,k-1)])*
                 OneOverTwoDZ);
              /* Excise horizons */
              ADMMass_VolumeMass_GF[ijk] *= horizon_mask[ijk];
              Charge_Volume_GF[ijk] *= horizon_mask[ijk];
            }
        }

  *grid_spacing_product = cctk_delta_space[0]*cctk_delta_space[1]*cctk_delta_space[2];

}

void ADMMass_Volume_Global(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS
    DECLARE_CCTK_PARAMETERS

    CCTK_INT reduction_handle;

  reduction_handle = CCTK_ReductionHandle("sum");
  if (reduction_handle < 0)
    CCTK_WARN(0, "Unable to get reduction handle.");

  if (CCTK_Reduce(cctkGH, -1, reduction_handle, 1,
                  CCTK_VARIABLE_REAL,
                  &ADMMass_Volume[*LoopCounter], 1,
                  CCTK_VarIndex("ADMMass::ADMMass_VolumeMass_GF")))
    CCTK_WARN(0, "Error while reducing ADMMass_VolumeMass_GF");

  if (CCTK_Reduce(cctkGH, -1, reduction_handle, 1,
                  CCTK_VARIABLE_REAL,
                  &Charge_Volume[*LoopCounter], 1,
                  CCTK_VarIndex("ADMMass::Charge_Volume_GF")))
    CCTK_WARN(0, "Error while reducing Charge_Volume_GF");

  ADMMass_Volume[*LoopCounter] *= *grid_spacing_product / (16.0*PI);

  Charge_Volume[*LoopCounter] *=  *grid_spacing_product / (4.0*PI);
}
