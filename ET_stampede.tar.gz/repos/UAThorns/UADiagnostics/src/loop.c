#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>

void InitLoopCounter(CCTK_ARGUMENTS);

void SetLoopCounter(CCTK_ARGUMENTS);

void Loop(CCTK_ARGUMENTS);

/* Initialise the loop counter */
void UAD_InitLoopCounter(CCTK_ARGUMENTS)
{
    DECLARE_CCTK_ARGUMENTS
    DECLARE_CCTK_PARAMETERS

    *LoopCounter = 0;
}

/* Set the loop counter to the value of the parameter ADMMass:ADMMass_number */
void UAD_SetLoopCounter(CCTK_ARGUMENTS)
{
    DECLARE_CCTK_ARGUMENTS
    DECLARE_CCTK_PARAMETERS

    *LoopCounter = number_of_surfaces;
}

/* Decrements the counter to loop over all radii/distances set */
void UAD_Loop(CCTK_ARGUMENTS)
{
    DECLARE_CCTK_ARGUMENTS
    DECLARE_CCTK_PARAMETERS

    (*LoopCounter)--;

}
