/* WARNING!!!! This thorn is buggy. It works only if the integration surface is
   in the outermost refinement level! */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>

#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>

#define PI 3.1415926535897932384626433832795028841971693993751058209749445923

void UAD_Surface_Local(CCTK_ARGUMENTS);


/* NOTE: At the moment the code is reliable only if the integration grid sits in
   a single refinement level!*/


int find_closest(const cGH *cctkGH, const int *cctk_lsh, int ghost,
                 CCTK_REAL *coord, CCTK_REAL coord_min, int dir)
{
  int min_i = -1;
  CCTK_REAL min = 1.e100;

  for(int i=ghost; i<cctk_lsh[dir]-ghost; i++) {
      CCTK_INT ijk = CCTK_GFINDEX3D(cctkGH, (dir==0)?i:0, (dir==1)?i:0, (dir==2)?i:0);

      if (fabs(coord[ijk] - coord_min) < min) {
          min = fabs(coord[ijk] - coord_min);
          min_i = i;
        }
    }
  return min_i;
}

void UAD_Surface_Local(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  if(compute_every <= 0 || cctk_iteration % compute_every != 0) return;

  CCTK_INT i,j,k, ijk, ierr;
  CCTK_INT x_min_i, x_max_i, y_min_j, y_max_j, z_min_k, z_max_k;

  CCTK_REAL delta[3][3];
  CCTK_REAL epsilon[3][3][3];

#pragma omp parallel for collapse(2)
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j)
      delta[i][j] = (i == j) ? 1. : 0.;

#pragma omp parallel for collapse(3)
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j)
      for (int k = 0; k < 3; ++k)
        if (i == j || j == k || k == i)
          epsilon[i][j][k] = 0.;

  epsilon[0][1][2] =  1.;
  epsilon[1][2][0] =  1.;
  epsilon[2][0][1] =  1.;
  epsilon[2][1][0] = -1.;
  epsilon[1][0][2] = -1.;
  epsilon[0][2][1] = -1.;

  CCTK_REAL physical_min[3];
  CCTK_REAL physical_max[3];
  CCTK_REAL interior_min[3];
  CCTK_REAL interior_max[3];
  CCTK_REAL exterior_min[3];
  CCTK_REAL exterior_max[3];
  CCTK_REAL spacing[3];

  /* grid-function strides for ADMMacros */
  const CCTK_INT di = 1;
  const CCTK_INT dj = cctk_lsh[0];
  const CCTK_INT dk = cctk_lsh[0]*cctk_lsh[1];

  /* denominators for derivatives */
  const CCTK_REAL OneOverTwoDX = 1.0 / (2.0 * CCTK_DELTA_SPACE(0));
  const CCTK_REAL OneOverTwoDY = 1.0 / (2.0 * CCTK_DELTA_SPACE(1));
  const CCTK_REAL OneOverTwoDZ = 1.0 / (2.0 * CCTK_DELTA_SPACE(2));

  const CCTK_REAL OneOverTwelveDX = 1.0 / (12.0 * CCTK_DELTA_SPACE(0));
  const CCTK_REAL OneOverTwelveDY = 1.0 / (12.0 * CCTK_DELTA_SPACE(1));
  const CCTK_REAL OneOverTwelveDZ = 1.0 / (12.0 * CCTK_DELTA_SPACE(2));

  const CCTK_REAL oneDX =  CCTK_DELTA_SPACE(0);
  const CCTK_REAL oneDY =  CCTK_DELTA_SPACE(1);
  const CCTK_REAL oneDZ =  CCTK_DELTA_SPACE(2);

  x_min_i = -INT_MAX;
  x_max_i =  INT_MAX;
  y_min_j = -INT_MAX;
  y_max_j =  INT_MAX;
  z_min_k = -INT_MAX;
  z_max_k =  INT_MAX;

  if (distance_from_grid_boundary[*LoopCounter] > 0.0) {
      if (!CCTK_EQUALS(CCTK_ParameterValString("type", "cartgrid3d"), "coordbase"))
        CCTK_WARN(0,"This thorn used with the distance_from_grid_boundary parameter requires to set coordinates through coordbase.");

      /* Find the physical coordinates of the boundaries */
      ierr = GetDomainSpecification(3, physical_min, physical_max,
                                     interior_min, interior_max,
                                     exterior_min, exterior_max, spacing);
      if (ierr)
        CCTK_VWarn(0, __LINE__, __FILE__, "CartGrid3D", "error returned from function GetDomainSpecification");

      *box_x_min = physical_min[0] + distance_from_grid_boundary[*LoopCounter];
      *box_x_max = physical_max[0] - distance_from_grid_boundary[*LoopCounter];
      *box_y_min = physical_min[1] + distance_from_grid_boundary[*LoopCounter];
      *box_y_max = physical_max[1] - distance_from_grid_boundary[*LoopCounter];
      *box_z_min = physical_min[2] + distance_from_grid_boundary[*LoopCounter];
      *box_z_max = physical_max[2] - distance_from_grid_boundary[*LoopCounter];
  } else if (surface_distance[*LoopCounter] > 0.0) {
      *box_x_min = x_pos[*LoopCounter] - surface_distance[*LoopCounter];
      *box_x_max = x_pos[*LoopCounter] + surface_distance[*LoopCounter];
      *box_y_min = y_pos[*LoopCounter] - surface_distance[*LoopCounter];
      *box_y_max = y_pos[*LoopCounter] + surface_distance[*LoopCounter];
      *box_z_min = z_pos[*LoopCounter] - surface_distance[*LoopCounter];
      *box_z_max = z_pos[*LoopCounter] + surface_distance[*LoopCounter];
  } else {
      *box_x_min = x_min[*LoopCounter];
      *box_x_max = x_max[*LoopCounter];
      *box_y_min = y_min[*LoopCounter];
      *box_y_max = y_max[*LoopCounter];
      *box_z_min = z_min[*LoopCounter];
      *box_z_max = z_max[*LoopCounter];
  }

  ijk = CCTK_GFINDEX3D(cctkGH, cctk_ubnd[0]-cctk_lbnd[0], cctk_ubnd[1]-cctk_lbnd[1], cctk_ubnd[2]-cctk_lbnd[2] );

  if ( (x[0] < *box_x_min) && (*box_x_min < x[ijk]) )
    x_min_i = find_closest(cctkGH, cctk_lsh, cctk_nghostzones[0], x, *box_x_min, 0);
  if ( (x[0] < *box_x_max) && (*box_x_max < x[ijk]) )
    x_max_i = find_closest(cctkGH, cctk_lsh, cctk_nghostzones[0], x, *box_x_max, 0);
  if ( (y[0] < *box_y_min) && (*box_y_min < y[ijk]) )
    y_min_j = find_closest(cctkGH, cctk_lsh, cctk_nghostzones[1], y, *box_y_min, 1);
  if ( (y[0] < *box_y_max) && (*box_y_max < y[ijk]) )
    y_max_j = find_closest(cctkGH, cctk_lsh, cctk_nghostzones[1], y, *box_y_max, 1);
  if ( (z[0] < *box_z_min) && (*box_z_min < z[ijk]) )
    z_min_k = find_closest(cctkGH, cctk_lsh, cctk_nghostzones[2], z, *box_z_min, 2);
  if ( (z[0] < *box_z_max) && (*box_z_max < z[ijk]) )
    z_max_k = find_closest(cctkGH, cctk_lsh, cctk_nghostzones[2], z, *box_z_max, 2);

#pragma omp parallel for
  for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++){
    ADMMass_Surface_GF[ijk] = 0.0;
    ADMAngularMomentum_Surface_GF_x[ijk]  = 0.0;
    ADMAngularMomentum_Surface_GF_y[ijk]  = 0.0;
    ADMAngularMomentum_Surface_GF_z[ijk]  = 0.0;
    ADMLinearMomentum_Surface_GF_x[ijk]  = 0.0;
    ADMLinearMomentum_Surface_GF_y[ijk]  = 0.0;
    ADMLinearMomentum_Surface_GF_z[ijk]  = 0.0;
    Charge_Surface_GF[ijk]  = 0.0;
  }
  /* At the moment the code works only if the integration box is all in one
     refinement level */
  if (x_min_i == -INT_MAX && x_max_i == INT_MAX &&
      y_min_j == -INT_MAX && y_max_j == INT_MAX &&
      z_min_k == -INT_MAX && z_max_k == INT_MAX) return;

#pragma omp parallel for private(i,j,k)
  for(k=cctk_nghostzones[2];k<cctk_lsh[2]-cctk_nghostzones[2];k++)
    for(j=cctk_nghostzones[1];j<cctk_lsh[1]-cctk_nghostzones[1];j++)
      for(i=cctk_nghostzones[0];i<cctk_lsh[0]-cctk_nghostzones[0];i++) {
        /* delimit the cube on whose surface we want to integrate */
        if ((i >= x_min_i) && (i <= x_max_i) &&
            (j >= y_min_j) && (j <= y_max_j) &&
            (k >= z_min_k) && (k <= z_max_k)) {

          CCTK_REAL ds[3] = {0.0, 0.0, 0.0};
          CCTK_REAL u[3][3], dg[3][3][3];

          CCTK_INT ti, tj, tk, tl;

          CCTK_INT ijk = CCTK_GFINDEX3D(cctkGH, i, j, k);

          CCTK_REAL detg = gxx[ijk] * gyy[ijk] * gzz[ijk] +
            gxy[ijk] * gyz[ijk] * gxz[ijk] +
            gxz[ijk] * gxy[ijk] * gyz[ijk] -
            gxz[ijk] * gyy[ijk] * gxz[ijk] -
            gxy[ijk] * gxy[ijk] * gzz[ijk] -
            gxx[ijk] * gyz[ijk] * gyz[ijk];

          /* Select the points on the surfaces of the requested cube */
          CCTK_INT n_bound = 0;
          if (i == x_min_i) { n_bound++;  ds[0] = -oneDY*oneDZ; }
          if (i == x_max_i) { n_bound++;  ds[0] =  oneDY*oneDZ; }
          if (j == y_min_j) { n_bound++;  ds[1] = -oneDX*oneDZ; }
          if (j == y_max_j) { n_bound++;  ds[1] =  oneDX*oneDZ; }
          if (k == z_min_k) { n_bound++;  ds[2] = -oneDX*oneDY; }
          if (k == z_max_k) { n_bound++;  ds[2] =  oneDX*oneDY; }

          /* Take care of corners and edges */
          if (n_bound == 2) for (ti=0; ti<3; ti++) ds[ti] /= 2.0;
          if (n_bound == 3) for (ti=0; ti<3; ti++) ds[ti] /= 4.0;

          if (n_bound > 0) {

            u[0][0] = (gyy[ijk] * gzz[ijk] - gyz[ijk] * gyz[ijk]) / detg;
            u[1][1] = (gxx[ijk] * gzz[ijk] - gxz[ijk] * gxz[ijk]) / detg;
            u[2][2] = (gxx[ijk] * gyy[ijk] - gxy[ijk] * gxy[ijk]) / detg;
            u[0][1] = (gxz[ijk] * gyz[ijk] - gxy[ijk] * gzz[ijk]) / detg;
            u[0][2] = (gxy[ijk] * gyz[ijk] - gxz[ijk] * gyy[ijk]) / detg;
            u[1][2] = (gxz[ijk] * gxy[ijk] - gyz[ijk] * gxx[ijk]) / detg;
            u[1][0] = u[0][1];
            u[2][0] = u[0][2];
            u[2][1] = u[1][2];

            if (derivs_order == 2){

              dg[0][0][0] = ( gxx[di+ijk] - gxx[-di+ijk] ) * OneOverTwoDX;
              dg[0][0][1] = ( gxx[dj+ijk] - gxx[-dj+ijk] ) * OneOverTwoDY;
              dg[0][0][2] = ( gxx[dk+ijk] - gxx[-dk+ijk] ) * OneOverTwoDZ;

              dg[0][1][0] = ( gxy[di+ijk] - gxy[-di+ijk] ) * OneOverTwoDX;
              dg[0][1][1] = ( gxy[dj+ijk] - gxy[-dj+ijk] ) * OneOverTwoDY;
              dg[0][1][2] = ( gxy[dk+ijk] - gxy[-dk+ijk] ) * OneOverTwoDZ;

              dg[0][2][0] = ( gxz[di+ijk] - gxz[-di+ijk] ) * OneOverTwoDX;
              dg[0][2][1] = ( gxz[dj+ijk] - gxz[-dj+ijk] ) * OneOverTwoDY;
              dg[0][2][2] = ( gxz[dk+ijk] - gxz[-dk+ijk] ) * OneOverTwoDZ;

              dg[1][0][0] = dg[0][1][0];
              dg[1][0][1] = dg[0][1][1];
              dg[1][0][2] = dg[0][1][2];

              dg[1][1][0] = ( gyy[di+ijk] - gyy[-di+ijk] ) * OneOverTwoDX;
              dg[1][1][1] = ( gyy[dj+ijk] - gyy[-dj+ijk] ) * OneOverTwoDY;
              dg[1][1][2] = ( gyy[dk+ijk] - gyy[-dk+ijk] ) * OneOverTwoDZ;

              dg[1][2][0] = ( gyz[di+ijk] - gyz[-di+ijk] ) * OneOverTwoDX;
              dg[1][2][1] = ( gyz[dj+ijk] - gyz[-dj+ijk] ) * OneOverTwoDY;
              dg[1][2][2] = ( gyz[dk+ijk] - gyz[-dk+ijk] ) * OneOverTwoDZ;

              dg[2][0][0] = dg[0][2][0];
              dg[2][0][1] = dg[0][2][1];
              dg[2][0][2] = dg[0][2][2];

              dg[2][1][0] = dg[1][2][0];
              dg[2][1][1] = dg[1][2][1];
              dg[2][1][2] = dg[1][2][2];

              dg[2][2][0] = ( gzz[di+ijk] - gzz[-di+ijk] ) * OneOverTwoDX;
              dg[2][2][1] = ( gzz[dj+ijk] - gzz[-dj+ijk] ) * OneOverTwoDY;
              dg[2][2][2] = ( gzz[dk+ijk] - gzz[-dk+ijk] ) * OneOverTwoDZ;

            }else if (derivs_order == 4){

              dg[0][0][0] = ( -gxx[2*di+ijk] + 8 * gxx[di+ijk] - 8 * gxx[-di+ijk] + gxx[-2*di+ijk] ) * OneOverTwelveDX;
              dg[0][0][1] = ( -gxx[2*dj+ijk] + 8 * gxx[dj+ijk] - 8 * gxx[-dj+ijk] + gxx[-2*dj+ijk] ) * OneOverTwelveDY;
              dg[0][0][2] = ( -gxx[2*dk+ijk] + 8 * gxx[dk+ijk] - 8 * gxx[-dk+ijk] + gxx[-2*dk+ijk] ) * OneOverTwelveDZ;

              dg[0][1][0] = ( -gxy[2*di+ijk] + 8 * gxy[di+ijk] - 8 * gxy[-di+ijk] + gxy[-2*di+ijk] ) * OneOverTwelveDX;
              dg[0][1][1] = ( -gxy[2*dj+ijk] + 8 * gxy[dj+ijk] - 8 * gxy[-dj+ijk] + gxy[-2*dj+ijk] ) * OneOverTwelveDY;
              dg[0][1][2] = ( -gxy[2*dk+ijk] + 8 * gxy[dk+ijk] - 8 * gxy[-dk+ijk] + gxy[-2*dk+ijk] ) * OneOverTwelveDZ;

              dg[0][2][0] = ( -gxz[2*di+ijk] + 8 * gxz[di+ijk] - 8 * gxz[-di+ijk] + gxz[-2*di+ijk] ) * OneOverTwelveDX;
              dg[0][2][1] = ( -gxz[2*dj+ijk] + 8 * gxz[dj+ijk] - 8 * gxz[-dj+ijk] + gxz[-2*dj+ijk] ) * OneOverTwelveDY;
              dg[0][2][2] = ( -gxz[2*dk+ijk] + 8 * gxz[dk+ijk] - 8 * gxz[-dk+ijk] + gxz[-2*dk+ijk] ) * OneOverTwelveDZ;

              dg[1][0][0] = dg[0][1][0];
              dg[1][0][1] = dg[0][1][1];
              dg[1][0][2] = dg[0][1][2];

              dg[1][1][0] = ( -gyy[2*di+ijk] + 8 * gyy[di+ijk] - 8 * gyy[-di+ijk] + gyy[-2*di+ijk] ) * OneOverTwelveDX;
              dg[1][1][1] = ( -gyy[2*dj+ijk] + 8 * gyy[dj+ijk] - 8 * gyy[-dj+ijk] + gyy[-2*dj+ijk] ) * OneOverTwelveDY;
              dg[1][1][2] = ( -gyy[2*dk+ijk] + 8 * gyy[dk+ijk] - 8 * gyy[-dk+ijk] + gyy[-2*dk+ijk] ) * OneOverTwelveDZ;

              dg[1][2][0] = ( -gyz[2*di+ijk] + 8 * gyz[di+ijk] - 8 * gyz[-di+ijk] + gyz[-2*di+ijk] ) * OneOverTwelveDX;
              dg[1][2][1] = ( -gyz[2*dj+ijk] + 8 * gyz[dj+ijk] - 8 * gyz[-dj+ijk] + gyz[-2*dj+ijk] ) * OneOverTwelveDY;
              dg[1][2][2] = ( -gyz[2*dk+ijk] + 8 * gyz[dk+ijk] - 8 * gyz[-dk+ijk] + gyz[-2*dk+ijk] ) * OneOverTwelveDZ;

              dg[2][0][0] = dg[0][2][0];
              dg[2][0][1] = dg[0][2][1];
              dg[2][0][2] = dg[0][2][2];

              dg[2][1][0] = dg[1][2][0];
              dg[2][1][1] = dg[1][2][1];
              dg[2][1][2] = dg[1][2][2];

              dg[2][2][0] = ( -gzz[2*di+ijk] + 8 * gzz[di+ijk] - 8 * gzz[-di+ijk] + gzz[-2*di+ijk] ) * OneOverTwelveDX;
              dg[2][2][1] = ( -gzz[2*dj+ijk] + 8 * gzz[dj+ijk] - 8 * gzz[-dj+ijk] + gzz[-2*dj+ijk] ) * OneOverTwelveDY;
              dg[2][2][2] = ( -gzz[2*dk+ijk] + 8 * gzz[dk+ijk] - 8 * gzz[-dk+ijk] + gzz[-2*dk+ijk] ) * OneOverTwelveDZ;

            }else{
              CCTK_WARN(0, "derivs_order non implemented!");
            }

            /* Baumgarte Shapiro (3.128) */
            for (ti = 0; ti < 3; ti++)
              for (tj = 0; tj < 3; tj++)
                for (tk = 0; tk < 3; tk++)
                  for (tl = 0; tl < 3; tl++)
                    ADMMass_Surface_GF[ijk] += u[ti][tj] * u[tk][tl] * ( dg[tl][tj][ti] - dg[ti][tj][tl] ) * ds[tk];

            ADMMass_Surface_GF[ijk] *= sqrt(detg);

            CCTK_REAL lE[3] = {Ex[ijk], Ey[ijk], Ez[ijk]};

            for (ti = 0; ti < 3; ti++)
              Charge_Surface_GF[ijk] += lE[ti] * ds[ti];

            Charge_Surface_GF[ijk] *= sqrt(detg);

            CCTK_REAL curv_ext[3][3];

            curv_ext[0][0] = kxx[ijk];
            curv_ext[0][1] = kxy[ijk];
            curv_ext[0][2] = kxz[ijk];
            curv_ext[1][0] = kxy[ijk];
            curv_ext[1][1] = kyy[ijk];
            curv_ext[1][2] = kyz[ijk];
            curv_ext[2][0] = kxz[ijk];
            curv_ext[2][1] = kyz[ijk];
            curv_ext[2][2] = kzz[ijk];

            CCTK_REAL trk = 0;

            for (ti = 0; ti < 3; ti++)
              for (tj = 0; tj < 3; tj++)
                trk += u[ti][tj] * curv_ext[ti][tj];

            CCTK_REAL xx[3] = {x[ijk], y[ijk], z[ijk]};

            for (tj = 0; tj < 3; tj++){
              ADMLinearMomentum_Surface_GF_x[ijk] += ds[tj] * (curv_ext[tj][0] - delta[tj][0] * trk);
              ADMLinearMomentum_Surface_GF_y[ijk] += ds[tj] * (curv_ext[tj][1] - delta[tj][1] * trk);
              ADMLinearMomentum_Surface_GF_z[ijk] += ds[tj] * (curv_ext[tj][2] - delta[tj][2] * trk);
            }

            /* Baumgarte Shapiro (3.191) */
            for (tj = 0; tj < 3; tj++)
              for (tk = 0; tk < 3; tk++)
                for (tl = 0; tl < 3; tl++)
                  {
                    ADMAngularMomentum_Surface_GF_x[ijk] += epsilon[0][tj][tk] * ds[tl] * xx[tj] * (curv_ext[tl][tk] - delta[tl][tk] * trk);
                    ADMAngularMomentum_Surface_GF_y[ijk] += epsilon[1][tj][tk] * ds[tl] * xx[tj] * (curv_ext[tl][tk] - delta[tl][tk] * trk);
                    ADMAngularMomentum_Surface_GF_z[ijk] += epsilon[2][tj][tk] * ds[tl] * xx[tj] * (curv_ext[tl][tk] - delta[tl][tk] * trk);
                  }

          }

        }
      }
}

void UAD_Surface_Global(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  int handle, ierr;

  handle = CCTK_ReductionHandle("sum");
  if (handle < 0)
    CCTK_VWarn (1, __LINE__, __FILE__, CCTK_THORNSTRING,
                "Invalid reduction operator '%s' with handle '%d'", "sum", handle);

  int N = 8; /* Number of integrands */
  CCTK_INT input_array[N]; /* input array void * pointers */
  CCTK_INT input_array_type_codes[N]; /* array containing types of data */
  void*  reduction_3D_value[N]; /* output data */

  /* make sure all pointers point to valid memory locations */
  reduction_3D_value[0] = &ADMMass_Surface             [*LoopCounter];
  reduction_3D_value[1] = &ADMAngularMomentum_Surface_x[*LoopCounter];
  reduction_3D_value[2] = &ADMAngularMomentum_Surface_y[*LoopCounter];
  reduction_3D_value[3] = &ADMAngularMomentum_Surface_z[*LoopCounter];
  reduction_3D_value[4] = &Charge_Surface              [*LoopCounter];
  reduction_3D_value[5] = &ADMLinearMomentum_Surface_x [*LoopCounter];
  reduction_3D_value[6] = &ADMLinearMomentum_Surface_y [*LoopCounter];
  reduction_3D_value[7] = &ADMLinearMomentum_Surface_z [*LoopCounter];

  for (int i = 0; i<N; i++) input_array_type_codes[i]  = CCTK_VARIABLE_REAL;

  /* 3D Array */
  input_array[0] = CCTK_VarIndex("UADiagnostics::ADMMass_Surface_GF");
  input_array[1] = CCTK_VarIndex("UADiagnostics::ADMAngularMomentum_Surface_GF_x");
  input_array[2] = CCTK_VarIndex("UADiagnostics::ADMAngularMomentum_Surface_GF_y");
  input_array[3] = CCTK_VarIndex("UADiagnostics::ADMAngularMomentum_Surface_GF_z");
  input_array[4] = CCTK_VarIndex("UADiagnostics::Charge_Surface_GF");
  input_array[5] = CCTK_VarIndex("UADiagnostics::ADMLinearMomentum_Surface_GF_x");
  input_array[6] = CCTK_VarIndex("UADiagnostics::ADMLinearMomentum_Surface_GF_y");
  input_array[7] = CCTK_VarIndex("UADiagnostics::ADMLinearMomentum_Surface_GF_z");

  for (int i = 0; i < N; i++) {
    ierr = CCTK_Reduce(cctkGH, -1, handle, 1, input_array_type_codes[i], reduction_3D_value[i], 1, input_array[i]);
    if (ierr) CCTK_WARN(0, "Error while performing reduction");
  }

  ADMMass_Surface             [*LoopCounter] /= 16.0*PI;
  ADMAngularMomentum_Surface_x[*LoopCounter] /=  8.0*PI;
  ADMAngularMomentum_Surface_y[*LoopCounter] /=  8.0*PI;
  ADMAngularMomentum_Surface_z[*LoopCounter] /=  8.0*PI;
  Charge_Surface              [*LoopCounter] /=  4.0*PI;
  ADMLinearMomentum_Surface_x[*LoopCounter]  /=  8.0*PI;
  ADMLinearMomentum_Surface_y[*LoopCounter]  /=  8.0*PI;
  ADMLinearMomentum_Surface_z[*LoopCounter]  /=  8.0*PI;

}
