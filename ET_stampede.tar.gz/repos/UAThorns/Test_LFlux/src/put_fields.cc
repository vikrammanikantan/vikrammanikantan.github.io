#include "cctk.h"
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

extern "C" void put_fields(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  for (int ind = 0; ind<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ind++){

    CCTK_REAL r2 = x[ind] * x[ind] + y[ind] * y[ind] + z[ind] * z[ind] + 1e-10;
    CCTK_REAL r = sqrt(r2);
    CCTK_REAL rho = sqrt(x[ind] * x[ind] + y[ind] * y[ind]);
    CCTK_REAL theta = atan2(rho, z[ind]);
    if (fabs(theta - M_PI) < 1e-1) theta = M_PI - 1e-1;
    CCTK_REAL cos_theta = cos(theta);
    CCTK_REAL sin_theta = sin(theta);
    CCTK_REAL phi = atan2(y[ind], x[ind]);
    CCTK_REAL sin_phi   = sin(phi);
    CCTK_REAL cos_phi   = cos(phi);

    CCTK_REAL omega = 1;

    CCTK_REAL Er   = 0;
    CCTK_REAL Ephi = 0;
    CCTK_REAL Etheta = - 1/r * omega * sin_theta / r;
    CCTK_REAL AAphi = 1/r * tan (theta / 2) / (r * sin_theta);
    CCTK_REAL AAtheta = - omega * sin_theta / r;
    CCTK_REAL dx_dr = x[ind] / r;
    CCTK_REAL dy_dr = y[ind] / r;
    CCTK_REAL dz_dr = z[ind] / r;
    CCTK_REAL dx_dphi = - r * sin_theta * sin_phi;
    CCTK_REAL dy_dphi =   r * sin_theta * cos_phi;
    CCTK_REAL dz_dphi = 0;
    CCTK_REAL dx_dtheta = r * cos_theta * cos_phi;
    CCTK_REAL dy_dtheta = r * cos_theta * sin_phi;
    CCTK_REAL dz_dtheta = - r * sin_theta;

    if (z[ind] > 0){
    Ex[ind] = Er * dx_dr + Ephi * dx_dphi + Etheta * dx_dtheta ;
    Ey[ind] = Er * dy_dr + Ephi * dy_dphi + Etheta * dy_dtheta ;
    Ez[ind] = Er * dz_dr + Ephi * dz_dphi + Etheta * dz_dtheta ;
    Ax[ind] = AAtheta * dx_dtheta + AAphi * dx_dphi;
    Ay[ind] = AAtheta * dy_dtheta + AAphi * dy_dphi;
    Az[ind] = AAtheta * dz_dtheta + AAphi * dz_dphi;
    Zeta[ind]  = 0;
    Aphi[ind]  = omega * cos_theta;
    }else{
    Ex[ind] = 0.;
    Ey[ind] = 0.;
    Ez[ind] = 0.;
    Ax[ind] = 0.;
    Ay[ind] = 0.;
    Az[ind] = 0.;
    Zeta[ind]  = 0;
    Aphi[ind]  = 0.;
    }


  }

    return;
}
