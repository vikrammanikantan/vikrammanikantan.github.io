#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"


#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "consts.h"
#include "equil.h"
#include "equil_util.h"
#include "rnsid_util.h"
#include "rnsid.h"
#include "hdf5_save.h"


void interp_on_xyz(double **old,
                   double *s_gp,
                   double *mu,
                   double r_e,
                   double x,
                   double y,
                   double z,
                   double *new,
                   double sign) {

int s,
    m,
    s_nearest,
    m_nearest,                /* nearest points in interpolation */
    k_s,                      /* first s point in interpolation */
    k_m;                      /* first s point in interpolation */


double r_c,                   /* r of cartesian x,y,z point */
       s_c,                   /* s of cartesian x,y,z point */
       mu_c,                  /* mu of cartesian x,y,z point */
       s_4[5],                /* s of the 4 nearest points */
       mu_4[5],               /* mu of the 4 nearest points */
       old_s[5],              /* old at 4 nearest constant s points */
       old_m[5];              /* old at 4 nearest constant mu points */



      r_c = sqrt(   SQ(x) + SQ(y) + SQ(z) );
      s_c = r_c/(r_e+r_c);

      if(r_c==0.0)
        mu_c = 0.0;
      else
        mu_c = fabs(z)/r_c;

      s_nearest = 0; m_nearest = 0;

      hunt(s_gp, SDIV, s_c, &s_nearest);
      hunt(mu, MDIV, mu_c, &m_nearest);

      k_s = IMIN(IMAX((s_nearest)-(4-1)/2,1),SDIV+1-4);
      k_m = IMIN(IMAX((m_nearest)-(4-1)/2,1),MDIV+1-4);

      for(s=1;s<=4;s++)
            s_4[s] = s_gp[k_s-1+s];

      for(m=1;m<=4;m++)
            mu_4[m] = mu[k_m-1+m];

      for(s=1;s<=4;s++) {
          for(m=1;m<=4;m++) {
                  old_s[m] = old[k_s-1+s][k_m-1+m];
          }
          old_m[s] = interp_4(mu_4, old_s, 4, mu_c);
      }

     if (z<0.0)
              (*new) = (1.0*sign)*interp_4(s_4, old_m, 4, s_c);
     else
              (*new) = interp_4(s_4, old_m, 4, s_c);
}


CCTK_REAL ** D_Wsquared=0;
CCTK_REAL ** D_enthalpy_rho_0=0;
CCTK_REAL ** D_Pressure=0;
CCTK_REAL ** D_Omega=0;
CCTK_REAL ** D_omega=0;
CCTK_REAL ** D_lapse=0;
CCTK_REAL ** D_atmo=0;
CCTK_REAL  * D_r_e=0;

void Donut_C_AllocateMemory(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  assert(D_Wsquared==0);
  assert(D_enthalpy_rho_0==0);
  assert(D_Pressure==0);
  assert(D_Omega==0);
  assert(D_omega==0);
  assert(D_lapse==0);
  assert(D_atmo==0);
  assert(D_r_e==0);

  D_Wsquared = array_allocate(1,SDIV,1,MDIV);
  D_enthalpy_rho_0 = array_allocate(1,SDIV,1,MDIV);
  D_Pressure = array_allocate(1,SDIV,1,MDIV);
  D_Omega = array_allocate(1,SDIV,1,MDIV);
  D_omega = array_allocate(1,SDIV,1,MDIV);
  D_lapse = array_allocate(1,SDIV,1,MDIV);
  D_atmo  = array_allocate(1,SDIV,1,MDIV);
  D_r_e   = malloc(sizeof(CCTK_REAL));

}

void Donut_C_FreeMemory (CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  assert(D_Wsquared!=0);
  assert(D_enthalpy_rho_0!=0);
  assert(D_Pressure!=0);
  assert(D_Omega!=0);
  assert(D_omega!=0);
  assert(D_lapse!=0);
  assert(D_atmo!=0);
  assert(D_r_e!=0);

  array_free(D_Wsquared,1,SDIV,1,MDIV);
  array_free(D_enthalpy_rho_0,1,SDIV,1,MDIV);
  array_free(D_Pressure,1,SDIV,1,MDIV);
  array_free(D_Omega,1,SDIV,1,MDIV);
  array_free(D_omega,1,SDIV,1,MDIV);
  array_free(D_lapse,1,SDIV,1,MDIV);
  array_free(D_atmo,1,SDIV,1,MDIV);
  free(D_r_e);

  D_enthalpy_rho_0=0;
  D_Wsquared=0;
  D_Pressure=0;
  D_Omega=0;
  D_omega=0;
  D_lapse=0;
  D_atmo=0;
  D_r_e=0;

}


static inline int exists_file_name(const char *fname)
{
        FILE *file;
        if (file = fopen(fname, "r"))
        {
            fclose(file);
            return 1;
        }
        return 0;
}

void compute_torus(CCTK_ARGUMENTS){
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

   /* EQUILIBRIUM VARIABLES */

 int    n_tab,                        /* Number of points in EOS file */
        a_check=0,                    /* if =200, iteration diverges */
        print_dif,                    /* if =1, monitor convergence */
        i;                            /* loop counter */


 double log_e_tab[MAX_NTAB],          /* energy dens./c^2 in tab. EOS */
        log_p_tab[MAX_NTAB],          /* pressure in tabulated EOS */
        log_h_tab[MAX_NTAB],          /* enthalpy in EOS file */
        log_n0_tab[MAX_NTAB],         /* number density in EOS file */
        Gamma_tab[MAX_NTAB],          /* Gamma in tab. EOS file */
        dens_max,                     /* maximum rest mass density */
        e_center,                     /* central energy density */
        p_center,                     /* central pressure */
        h_center,                     /* central enthalpy */
        e_surface,                    /* surface en. density */
        p_surface,                    /* surface pressure */
        s_max,                        /* s at maximum density */
        s_rmin,                       /* s at precise location of rmin */
        enthalpy_min,                 /* minimum enthalpy in EOS */
        H_max,                        /* maximum log_enthalpy */
        *s_gp,                        /* s grid points */
        *mu,                          /* \mu grid points */
      **rho_potential,                          /* potential \rho_potential */
      **gama,                         /* potential \gamma */
      **omega,                        /* potential \omega */
      **alpha,                        /* potential \alpha */
      **energy,                       /* energy density \epsilon */
      **pressure,                     /* pressure */
      **enthalpy,                     /* enthalpy */
      **velocity_sq,                  /* square of velocity */
        R_e,                          /* Circumferential radius */
        Mass,                         /* Gravitational mass */
        Mass_0,                       /* Baryon Mass */
        T,                            /* Rotational kinetic energy */
        W,                            /* Gravitational binding energy */
        Omega,                        /* Angular velocity */
        Omega_K,                      /* Ang. vel. of part. in orbit at eq.*/
        r_e,                          /* coord. radius at equator */
        Omega_e,                      /* Ang. vel. at equator, when difrot. */
      **Omega_diff,                   /* Diff. ang. vel. */
         **Wlnmut,                     /* W=ln(-ut) */
         Mbherr,                       /* error in extrapolating Mbh */
         DeltaW,                       /* difference in potential W between r_in and r_out */
      Omega_i,
      Omega_max,
         Mt,                           /* torus mass */
         M0t,                          /* torus rest mass */
         Ut,                           /* torus internal energy */
         Jt,                           /* torus angular momentum */
         Tt,                           /* torus rotational energy */
         Ma,                           /* asymptotic spacetime mass */
         Ja,                           /* asymptotic spacetime angular momentum */
         *Omega_Kepler,                /* Keplerian ang. vel. in equatorial plane */
         *l_Kepler,                    /* Keplerian spec. ang. momentum in eq. plane */
        J;                            /* Angular momentun */


 r_e = outer_edge;  /* Disk location */

 double Mbh = MBh;
 double l0 = L0;
 double omega_bh = Omega_BH;

 double eos_k, eos_ideal_fluid_gamma;

  if ( (RNS_K < 0.0) || (RNS_Gamma < 0.0)) {
    CCTK_WARN(0,"RNS_K and RNS_Gamma must be greater than 0: using 100.0 and 2!");
    eos_k                 = 100.0;
    eos_ideal_fluid_gamma = 2.0;
  } else {
    eos_k                 = RNS_K;
    eos_ideal_fluid_gamma = RNS_Gamma;
  }


 //  char eos_file[256] = "no EOS file specified",   /* EOS file name */
 //        eos_type[80]  = "poly";                    /* EOS type (poly or tab) */
 char * message;

 /* INITIAL DATA VARIABLES */

 int m,                               /* counter */
     s,                               /* counter */
     j,                               /* counter */
     k,                               /* counter */
     z_print;                         /* z where check is printed */


 double
       n_P,                           /* polytropic index */
       **nu,                          /* potential nu */
       **B,                           /* potential B */
       **rho_0,                       /* rest mass density */
       **nu_dr,                       /* r-der. in s-coord. of nu */
       **B_dr,                        /* r-der. in s-coord. of B */
       **alpha_dr,                    /* r-der. in s-coord. of alpha */
       **omega_dr,                    /* r-der. in s-coord. of omega */
       **nu_dth,                      /* theta-der. in mu-coord. of nu */
       **B_dth,                       /* theta-der. in mu-coord. of B */
       **alpha_dth,                   /* theta-der. in mu-coord. of alpha */
       **omega_dth,                   /* theta-der. in mu-coord. of omega */
       **Beta,                        /* metric function Beta in AJS solution */
       **lambda,                      /* metric function lambda in AJS solution */
       **H_raw,                       /* raw value of log_enthalpy, incl. negative values in vacuum */
       x_i,                           /* x at i */
       y_j,                           /* y at j */
       z_k,                           /* z at k */
       nu_ijk,                        /* nu at ijk point */
       exp_nu_ijk,                    /* exp(nu) at ijk point */
       B_ijk,                         /* B at ijk point */
       omega_ijk,                     /* omega at ijk point */
       alpha_ijk,                     /* alpha at ijk point */
       exp_alpha_ijk,                 /* exp(alpha) at ijk point */
       rho_0_ijk,                     /* rho_0 at ijk point */
       energy_ijk,                    /* energy at ijk point */
       pressure_ijk,                  /* pressure at ijk point */
       nu_dx,                         /* derivative of nu w.r.t. x */
       nu_dy,                         /* derivative of nu w.r.t. y */
       B_dx,                          /* derivative of B w.r.t. x */
       B_dy,                          /* derivative of B w.r.t. y */
       omega_dx,                      /* derivative of omega w.r.t. x */
       omega_dy,                      /* derivative of omega w.r.t. y */
       omega_dz,                      /* derivative of omega w.r.t. z */
       alpha_dx,                      /* derivative of alpha w.r.t. x */
       alpha_dy,                      /* derivative of alpha w.r.t. y */
       r_ijk,                         /* r at ijk point */
       r_bar_ijk,                     /* sqrt(x^2+y^2) at ijk point */
       dr_dx,                         /* dr/dx */
       dr_dy,                         /* dr/dy */
       dr_dz,                         /* dr/dz */
       dtheta_dx,                     /* dtheta/dx */
       dtheta_dy,                     /* dtheta/dy */
       dtheta_dz,                     /* dtheta/dz */
       nu_dr_ijk,                     /* dnu/dr at ijk */
       B_dr_ijk,                      /* dB/dr at ijk */
       alpha_dr_ijk,                  /* dalpha/dr at ijk */
       omega_dr_ijk,                  /* domega/dr at ijk */
       nu_dtheta_ijk,                 /* dnu/dtheta at ijk */
       B_dtheta_ijk,                  /* dB/dtheta at ijk */
       alpha_dtheta_ijk,              /* dalpha/dtheta at ijk */
       omega_dtheta_ijk,              /* domega/dtheta at ijk */
       gamma_ijk,                     /* gamma = det(3g) */
       W_ijk,                         /* Lorentz factor */
       h_ijk,                         /* h = 1 + eps + P/rho_potential */
       distance_ijk =0,               /* Signed distance to surface */
       e_atm,                         /* energy density of atmosphere */
       p_atm,                         /* pressure of atmosphere */
       rho_0_atm,                     /* rest mass density of atmosphere */
       dens_atm,                      /* D of atmosphere */
       tau_atm,                       /* tau of atmosphere */
       h0_h,                          /* location of BH horizon in units of r_e */
       temp_a,                        /* temporary variables */
       temp_o,
       temp_g,
       temp_r,
       temp_e,
       temp_p,
       temp_h,
       temp_v,
       Omega_ijk;

 FILE *file_2D;

 int nx=cctkGH->cctk_lsh[0]; int ny=cctkGH->cctk_lsh[1]; int nz=cctkGH->cctk_lsh[2];
 int s0,                           /* integer index of BH horizon */
     n_nearest_max,                /* nearest grid point to maximum density */
     n_it;                        /* number of iterations */

 CCTK_REAL rho0_center;

 /*

 HISTORICAL NOTE ON NAMES OF VARIABLES:

 old name               new name (from version 1.25 on)

 pert_amp               pert_amplitude (now a parameter)
 Gamma_P                eos_ideal_fluid_gamma (now a parameter)
 r_ratio                axes_ratio (now a parameter)
 rho                    rho_potential

 */


      /* COMPUTE POLYTROPIC INDEX AND CENTRAL ENERGY DENSITY */
      n_P=1.0/(eos_ideal_fluid_gamma-1.0);
      e_center = (eos_k*pow(rho_central,eos_ideal_fluid_gamma)/(eos_ideal_fluid_gamma-1.0)+rho_central);

      /* TABULATED EOS OPTION */
      if(strcmp(eos_type,"tab")==0) {
        /* --V0-- load_eos( eos_file, log_e_tab, log_p_tab, log_h_tab, log_n0_tab, Gamma_tab, &n_tab ); */
        int n_nearest;
        double n0;
        /* ==================================================== */
        /* printf(" TAB eos from file: %s\n",eos_file); */
        message = (char *)malloc(200*sizeof(char));
        sprintf(message," TAB eos from file: %s",eos_file);
        CCTK_INFO(message);
        free(message);
        /* ==================================================== */
        load_eos( eos_file, log_e_tab, log_p_tab, log_h_tab, log_n0_tab, &n_tab );
        n_nearest = 50;
        n0 = rho_central/(MB*cactusM);
        e_center = pow(10.0,interp(log_n0_tab, log_e_tab, n_tab,log10(n0), &n_nearest));
      }


      /* SET UP GRID */
      s_gp=malloc((SDIV+1)*sizeof(double));
      mu=malloc((MDIV+1)*sizeof(double));

      Omega_Kepler=malloc((SDIV+1)*sizeof(double));
      l_Kepler=malloc((SDIV+1)*sizeof(double));

      make_grid(s_gp, mu);

      /* ALLLOCATE MEMORY */

      rho_potential = array_allocate(1,SDIV,1,MDIV);
      gama = array_allocate(1,SDIV,1,MDIV);
      alpha = array_allocate(1,SDIV,1,MDIV);
      omega = array_allocate(1,SDIV,1,MDIV);
      energy = array_allocate(1,SDIV,1,MDIV);
      pressure = array_allocate(1,SDIV,1,MDIV);
      enthalpy = array_allocate(1,SDIV,1,MDIV);
      velocity_sq = array_allocate(1,SDIV,1,MDIV);
      Omega_diff = array_allocate(1,SDIV,1,MDIV);
      lambda = array_allocate(1,SDIV,1,MDIV);
      Wlnmut = array_allocate(1, SDIV, 1, MDIV);
      Beta = array_allocate(1,SDIV,1,MDIV);
      H_raw = array_allocate(1,SDIV,1,MDIV);

      nu = array_allocate(1,SDIV,1,MDIV);
      B = array_allocate(1,SDIV,1,MDIV);
      rho_0 = array_allocate(1,SDIV,1,MDIV);

      /* INITIALIZE VARIABLES WITH ZERO */

      #pragma omp parallel for
      for(s=1;s<=SDIV;s++)
        for(m=1;m<=MDIV;m++) {
          rho_potential[s][m] = 0.0e0;
          gama[s][m] = 0.0e0;
          alpha[s][m] = 0.0e0;
          omega[s][m] = 0.0e0;
          energy[s][m] = 0.0e0;
          pressure[s][m] = 0.0e0;
          enthalpy[s][m] = 0.0e0;
          velocity_sq[s][m] = 0.0e0;
          Omega_diff[s][m] = 0.0e0;
        }



      /* SET DEFAULT EQUILIBRIUM PARAMETERS */

      if(strcmp(eos_type,"tab")==0) {
        e_surface=7.8e-15;
        p_surface=1.12379e-28;
        enthalpy_min=1.0/(C*C);
      }
      else {
            e_surface=0.0;
            p_surface=0.0;
            enthalpy_min=0.0;
      }

      Omega_e=0.0; /* initialize ang. vel. at equator for diff. rot. */

      print_dif=1;


      z_print = nz/4;


      /* CHANGE e_center TO POLYTROPIC DIMENSIONLESS UNITS */
      /*      e_center /= ( 1.0/pow(eos_k, n_P) ); */

      /* MAKE e_center DIMENSIONLESS FOR TAB. EOS */
      //
      // if(strcmp(eos_type,"tab")==0)
      //   e_center *= (C*C*KSCALE);


      /* COMPUTE DIMENSIONLESS CENTRAL PRESSURE AND ENTHALPY */

      /*-V0-- make_center( e_center, log_e_tab, log_p_tab, log_h_tab, n_tab,      */
      /*-V0--             eos_type, eos_ideal_fluid_gamma, &p_center, &h_center); */
      make_center( e_center, log_e_tab, log_p_tab, log_h_tab, n_tab,
                   eos_type, eos_k,eos_ideal_fluid_gamma, &p_center, &h_center);

      rho0_center =  (e_center+p_center)*exp(-h_center);



      if(print_dif==1){
        /* ====================================================================
        printf(" ****************************************************\n");
        printf(" ****************************************************\n");
        printf(" **              HYDRO - RNSID                     **\n");
        printf(" **      ROTATING NEUTRON STAR INITIAL DATA        **\n");
        printf(" ****************************************************\n");
        printf(" ****************************************************\n");
        if( strcmp(recover_2Dmodel, "no")==0)
          printf(" Iterating equilibrium model\n");
          ======================================================================*/
        CCTK_INFO(" ****************************************************");
        CCTK_INFO(" ****************************************************");
        CCTK_INFO(" **                   DONUT                        **");
        CCTK_INFO(" **      SELF-GRAVITATING DISK INITIAL DATA        **");
        CCTK_INFO(" ****************************************************");
        CCTK_INFO(" ****************************************************");
        if( strcmp(recover_2Dmodel, "no")==0)
          CCTK_INFO(" Iterating equilibrium model");
      }


      /* EITHER COMPUTE THE MODEL AND PROCEED OR COMPUTE IT AND SAVE IT
         IN A FILE */

      int recovered_from_2d = 0;
      double r_ratio;  /* Here it is found */
      if(  strcmp(recover_2Dmodel, "yes")==0 && exists_file_name(model2D_file)==1) {

             /* RECOVER FROM 2D FILE */
             /* ==================================================== */
             /* printf(" Recovering 2D model form file %s\n",model2D_file); */
             message = (char *)malloc(200*sizeof(char));
             sprintf(message," Recovering 2D model form file %s",model2D_file);
             CCTK_INFO(message);
             free(message);
             /* ==================================================== */
             int sdiv,mdiv;
             hdf5_read_var(&sdiv,&mdiv,model2D_file,
                           eos_type,eos_file,&eos_k,&eos_ideal_fluid_gamma,rotation_type,
                           &A_diff,&r_ratio,&rho0_center,&r_e,
                           s_gp,mu,rho_potential, gama, alpha, omega, energy, pressure, enthalpy, velocity_sq, &Omega,&Omega_e,Omega_diff,
                           rho_0, lambda, Beta, Wlnmut, &h0_h,
                           &l0, &omega_bh, &Omega_i, &Omega_max,
                           &s_max, &s0, &Mbh, &Mt, &M0t, &Ut, &Jt, &Tt,
                           &Ma, &Ja, &Mbherr, &s_rmin, &DeltaW,&dens_max, &H_max
                           );
             printf("DENS_MAX: %g, HMAX %g\n", dens_max, H_max);
             recovered_from_2d = 1;
      } /* END RECOVER FROM 2D FILE, so also end of finding the equil state */
      else {

    /* Compute a first guess */

    guess_AJS( s_gp, mu, eos_type, &dens_max, eos_ideal_fluid_gamma, eos_k,
               log_e_tab, log_p_tab, log_h_tab, n_tab, Mbh, l0, &r_e,
               lambda, Beta, alpha, omega, &r_ratio, rho_0, energy,
               pressure, enthalpy, H_raw, velocity_sq, Omega_diff,
               &h0_h, &s0, &n_nearest_max);

    /* Main iteration routine */

    /* vac = 1 wouldn't solve for the torus. This is a compatibility parameter
     * for the old RNS */
    int vac = 0;

    iterate_torus( s_gp, mu, eos_ideal_fluid_gamma, eos_k, r_ratio, &dens_max, &H_max,
                   accuracy, print_dif, cf, &r_e,
                   lambda, Beta, alpha, omega, rho_0, energy,
                   pressure, enthalpy, H_raw, velocity_sq, Omega_diff,
                   &h0_h, l0, omega_bh, &Omega_i, &Omega_e, &Omega_max,
                   &s_max, &s_rmin, &n_nearest_max, s0, vac, n_it, RNS_lmax);


      }

    int vac = 0;

    /* Compute equilibrium quantities */

    comp_bh_torus( s_gp, mu, eos_ideal_fluid_gamma, eos_k, r_ratio, &dens_max, &r_e,
                   lambda, Beta, alpha, omega, rho_0, energy,
                   pressure, enthalpy, H_raw, velocity_sq, Omega_diff, Wlnmut,
                   &h0_h, l0, omega_bh, &Omega_i, &Omega_e, &Omega_max,
                   &s_max, s0,  vac,  &Mbh, &Mt, &M0t, &Ut, &Jt, &Tt,
                   &Ma, &Ja, &Mbherr, Omega_Kepler, l_Kepler, s_rmin, &DeltaW, RNS_lmax);

    print_torus( n_P, eos_ideal_fluid_gamma, eos_k, s_gp, mu, s0, r_e, s_rmin, s_max,
                 dens_max, Mt, Ma, Mbh, M0t, Ut, Tt, Jt, Ja, l0,
                 Omega_Kepler, l_Kepler, Wlnmut, velocity_sq, Omega_diff,
                 rho_0, pressure, lambda, Beta, alpha, omega, DeltaW);

    /* Unfortunately, MBh is not too reliable, the error is easily of order
     * 1% */
    *donut_black_hole_mass = Mbh;

      if( strcmp(save_2Dmodel, "yes")==0 && recovered_from_2d == 0 ) {

        /* SAVE 2D FILE */
        int sdiv,mdiv;
        sdiv=SDIV;
        mdiv=MDIV;
        /* Only the root process saves */
        if (CCTK_MyProc(cctkGH) == 0) {
          hdf5_save_var(&sdiv,&mdiv,model2D_file,
                        eos_type,eos_file,&eos_k,&eos_ideal_fluid_gamma,rotation_type,
                        &A_diff,&axes_ratio,&rho0_center,&r_e,
                        s_gp,mu,rho_potential, gama, alpha, omega, energy, pressure, enthalpy,
                        velocity_sq, &Omega,&Omega_e,Omega_diff,
                        rho_0, lambda, Beta, Wlnmut, &h0_h,
                        &l0, &omega_bh, &Omega_i, &Omega_max,
                        &s_max, &s0, &Mbh, &Mt, &M0t, &Ut, &Jt, &Tt,
                        &Ma, &Ja, &Mbherr, &s_rmin, &DeltaW,&dens_max, &H_max
                        );
        }

        if (exists_file_name(model2D_file) == 0) {
          message = (char *)malloc(200*sizeof(char));
          sprintf(message,"File %s could not be written!",model2D_file);
          CCTK_WARN(CCTK_WARN_PICKY, message);
          free(message);
        }
      }  /* END SAVE 2D FILE */

      *D_r_e = r_e;

      for(s=1;s<=SDIV;s++)
        for(m=1;m<=MDIV;m++) {
          /* Flag atmosphere */
          if (rho_0[s][m] > (1 + RNS_atmo_tolerance) * RNS_rho_min){
            D_atmo[s][m] = 1;
          }else{
            D_atmo[s][m] = 0;
          }

          double W_squared = 1.0/(1.0-velocity_sq[s][m]);

          double metric_3_determinant = exp(4 * alpha[s][m]) * Beta[s][m] * Beta[s][m] / (lambda[s][m] * lambda[s][m] + 1e-10);

          double conformal_factor = pow(metric_3_determinant, 1.0/12.0);
          double conformal_factor_squared = pow(metric_3_determinant, 1.0/6.0);
          /* psi = (gamma)^1/12, psi^8 = gamma^8/12 = gamma^2/3 */
          double conformal_factor_eigth = pow(metric_3_determinant, 2.0/3.0);

          /* Baumgarte-Shapiro (5.33), (5.34) */

          D_lapse[s][m] = D_atmo[s][m] * lambda[s][m];
          /* These quantities are scaled with psi^8 */
          D_Pressure[s][m] = D_atmo[s][m] * pressure[s][m] * conformal_factor_eigth;
          D_Wsquared[s][m] = D_atmo[s][m] * W_squared; /* W_squared = \bar(W_squared) */
          D_enthalpy_rho_0[s][m] = D_atmo[s][m] * (energy[s][m] * conformal_factor_eigth + pressure[s][m]);

          /* The velocity scales with psi^2, so we multiply times psi^2 here */
          D_Omega[s][m] = D_atmo[s][m] * Omega_diff[s][m] * conformal_factor_squared;
          D_omega[s][m] = D_atmo[s][m] * omega[s][m] * conformal_factor_squared;
        }

}


CCTK_INT D_Set_Rho_ADM(CCTK_POINTER_TO_CONST cctkGH,
                         CCTK_INT  size,
                         CCTK_REAL *source,
                         const CCTK_REAL *x,
                         const CCTK_REAL *y,
                         const CCTK_REAL *z )
{
  DECLARE_CCTK_PARAMETERS

  assert(D_Wsquared!=0);
  assert(D_enthalpy_rho_0!=0);
  assert(D_Pressure!=0);
  assert(D_Omega!=0);
  assert(D_omega!=0);
  assert(D_lapse!=0);
  assert(D_atmo!=0);
  assert(D_r_e!=0);

  double *mu, *s_gp;

  s_gp=malloc((SDIV+1)*sizeof(double));
  mu=malloc((MDIV+1)*sizeof(double));

  make_grid(s_gp, mu);

  #pragma omp parallel for
  for (CCTK_INT i=0; i<size; i++)
  {
    double x_i = x[i];
    double y_j = y[i];
    double z_k = z[i];

    double pressure_interpolated;
    double enthalpy_rho_0_interpolated;
    double Wsquared_interpolated;

    interp_on_xyz( D_Pressure, s_gp, mu, *D_r_e, x[i], y[i], z[i], &pressure_interpolated, 1);
    interp_on_xyz( D_enthalpy_rho_0, s_gp, mu, *D_r_e, x[i], y[i], z[i], &enthalpy_rho_0_interpolated, 1);
    interp_on_xyz( D_Wsquared, s_gp, mu, *D_r_e, x[i], y[i], z[i], &Wsquared_interpolated, 1);

    source[i] = Wsquared_interpolated * enthalpy_rho_0_interpolated - pressure_interpolated;

  }

  free(s_gp);
  free(mu);

  return 1;
}

CCTK_INT D_Set_S_ADM(CCTK_POINTER_TO_CONST cctkGH,
                         CCTK_INT  direction,  // 0, 1 or 2
                         CCTK_INT  size,
                         CCTK_REAL *source,
                         const CCTK_REAL *x,
                         const CCTK_REAL *y,
                         const CCTK_REAL *z )
{
  DECLARE_CCTK_PARAMETERS

  assert(D_Wsquared!=0);
  assert(D_enthalpy_rho_0!=0);
  assert(D_Pressure!=0);
  assert(D_Omega!=0);
  assert(D_omega!=0);
  assert(D_lapse!=0);
  assert(D_atmo!=0);
  assert(D_r_e!=0);

  if (direction == 2){
    #pragma omp parallel for
    for (CCTK_INT i=0; i<size; i++)
      source[i] = 0.0;
    return 1;
  }

  double *mu, *s_gp;

  s_gp=malloc((SDIV+1)*sizeof(double));
  mu=malloc((MDIV+1)*sizeof(double));

  make_grid(s_gp, mu);

  #pragma omp parallel for
  for (CCTK_INT i=0; i<size; i++)
  {
    double x_i = x[i];
    double y_j = y[i];
    double z_k = z[i];

    double local_vel;

    double omega_interpolated;
    double Omega_interpolated;
    double lapse_interpolated;
    double enthalpy_rho_0_interpolated;
    double Wsquared_interpolated;

    interp_on_xyz( D_omega, s_gp, mu, *D_r_e, x[i], y[i], z[i], &omega_interpolated, 1);
    interp_on_xyz( D_Omega, s_gp, mu, *D_r_e, x[i], y[i], z[i], &Omega_interpolated, 1);
    interp_on_xyz( D_lapse, s_gp, mu, *D_r_e, x[i], y[i], z[i], &lapse_interpolated, 1);
    interp_on_xyz( D_enthalpy_rho_0, s_gp, mu, *D_r_e, x[i], y[i], z[i], &enthalpy_rho_0_interpolated, 1);
    interp_on_xyz( D_Wsquared, s_gp, mu, *D_r_e, x[i], y[i], z[i], &Wsquared_interpolated, 1);

    if (direction == 0){
      local_vel = (omega_interpolated-Omega_interpolated)*y_j/(lapse_interpolated + 1e-10);
    }else if(direction == 1){
      local_vel = -(omega_interpolated-Omega_interpolated)*x_i/(lapse_interpolated + 1e-10);
    }else if(direction == 2){
      local_vel = 0;
    }

    source[i] = Wsquared_interpolated * enthalpy_rho_0_interpolated * local_vel;

  }

  free(s_gp);

  free(mu);

  return 1;
}

void Test_RHO_S(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

 int nx=cctkGH->cctk_lsh[0]; int ny=cctkGH->cctk_lsh[1]; int nz=cctkGH->cctk_lsh[2];
 int i,j,k;

 printf("Putting sources inside debug_stuff\n");

 for(i=1;i<=nx;i++)
   for(j=1;j<=ny;j++)
     for(k=1;k<=nz;k++) {
       CCTK_REAL rho_test;
       CCTK_REAL Sx_test;
       CCTK_REAL Sy_test;
       CCTK_REAL Sz_test;

       int index = i-1+nx*(j-1+ny*(k-1));

       D_Set_Rho_ADM(cctkGH, 1, &rho_test, &(x[index]), &(y[index]), &(z[index]) );
       D_Set_S_ADM(cctkGH, 0, 1, &Sx_test, &(x[index]), &(y[index]), &(z[index]) );
       D_Set_S_ADM(cctkGH, 1, 1, &Sy_test, &(x[index]), &(y[index]), &(z[index]) );
       D_Set_S_ADM(cctkGH, 2, 1, &Sz_test, &(x[index]), &(y[index]), &(z[index]) );

       debug_rho[index] = rho_test;
       debug_Sx[index] = Sx_test;
       debug_Sy[index] = Sy_test;
       debug_Sz[index] = Sz_test;
     }
}
