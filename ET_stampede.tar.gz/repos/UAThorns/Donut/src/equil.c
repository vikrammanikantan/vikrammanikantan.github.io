/****************************************************************************
equil.c		PROCEDURES USED TO COMPUTE THE EQUILIBRIUM STAR
		make_grid(): Sets up the computational grid.
		load_eos(): Loads EOS file.
		e_at_p() etc.: Returns energy density given pressure, etc.
		make_center(): Computes the central pressure and enthalpy
		comp_values(): Given the metric of an equilibrium star,
			computes the mass (M), baryon mass (M_0), kinetic (T)
			 and potential (W) energies, limiting angular velocity
			(Omega_K) and equatorial radius (R_e).
		dm_dr_is() etc.: Isotropic radial derivative of the
			mass function, etc.
		integrate(): Integrate the TOV equations
		guess(): Converts the solution of the TOV equations to the
			right coordinates and uses the spherical solution
			as the first guess for the rotating solution.
		iterate(): The "spin" cycle; iterates the initial guess
			until the field equations are satisfied.
			*****************************************************/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "consts.h"
#include "equil.h"
#include "equil_util.h"
#include "rnsid_util.h"

#ifndef RNS_SEQ_COMPILATION
#include <cctk.h>
#else
#define CCTK_VERROR(...) do {fprintf(stderr, __VA_ARGS__); exit(1);} while(0)
#endif

/*******************************************************************/
/* Create computational grid.                                      */
/* Points in the mu-direction are stored in the array mu[i].       */
/* Points in the s-direction are stored in the array s_pg[j].      */
/*******************************************************************/
void make_grid(double s_gp[SDIV+1],
               double mu[MDIV+1])
{
  int m, s;                         /* counters */

      for(s=1;s<=SDIV;s++)
         s_gp[s] = SMAX*(s-1.0)/(SDIV-1.0);

      for(m=1;m<=MDIV;m++)
         mu[m] = (m-1.0)/(MDIV-1.0);
}



/*************************************************************************/
/* Load EOS file.                                                        */
/*************************************************************************/
void load_eos( char eos_file[],
               double log_e_table[MAX_NTAB],
               double log_p_table[MAX_NTAB],
               double log_h_table[MAX_NTAB],
               double log_n0_table[MAX_NTAB],
               int *n_tab)
{
 int i;                    /* counter */

 double p,                 /* pressure */
        rho,               /* density */
        h,                 /* enthalpy */
        n0;                /* number density */

 FILE *f_eos;              /* pointer to eos_file */


    /* OPEN FILE TO READ */

    if((f_eos=fopen(eos_file,"r")) == NULL ) {
       CCTK_VERROR("cannot open file:  %s\n",eos_file);
    }

    /* READ NUMBER OF TABULATED POINTS */

    fscanf(f_eos,"%d\n",n_tab);


    /* READ ENERGY DENSITY, P, H, N0 AND CONVERT TO CACTUS UNITS */

    for(i=1;i<=(*n_tab);i++) {
       fscanf(f_eos,"%lf %lf %lf %lf \n",&rho,&p,&h,&n0) ;
       log_e_table[i]=log10(rho*cactusM*cactusV);     /* multiply by C^2 to get energy density */
       log_p_table[i]=log10(p*cactusM/(cactusL*cactusT*cactusT));
       log_h_table[i]=log10(h*cactusL*cactusL/(cactusT*cactusT));
       log_n0_table[i]=log10(n0*cactusV);
    }
}



/*******************************************************************/
double e_of_rho0(double rho0, double Gamma_P, double eos_k)
{
 return(eos_k*pow(rho0,Gamma_P)/(Gamma_P-1.0)+rho0);
}


/*C*/
/*******************************************************************/
double e_at_p(double pp,
              double log_e_tab[MAX_NTAB],
              double log_p_tab[MAX_NTAB],
              int    n_tab,
              int    *n_nearest_pt,
              char eos_type[],
	      double eos_k,
              double Gamma_P)
{
 if(strcmp(eos_type,"tab")==0)
   return pow(10.0,interp(log_p_tab,log_e_tab,n_tab,log10(pp), n_nearest_pt));
 else
   return pp/(Gamma_P-1.0) + pow(pp/eos_k,1.0/Gamma_P);
}

/*C*/
/*******************************************************************/
double p_at_e(double ee,
              double log_p_tab[MAX_NTAB],
              double log_e_tab[MAX_NTAB],
              int    n_tab,
              int    *n_nearest_pt)
{
 return pow(10.0,interp(log_e_tab,log_p_tab,n_tab,log10(ee), n_nearest_pt));
}

/*C*/
/*******************************************************************/
double p_at_h(double hh,
              double log_p_tab[MAX_NTAB],
              double log_h_tab[MAX_NTAB],
              int    n_tab,
              int    *n_nearest_pt)
{
 return pow(10.0,interp(log_h_tab,log_p_tab,n_tab,log10(hh), n_nearest_pt));
}

/*C*/
/*******************************************************************/
double h_at_p(double pp,
              double log_h_tab[MAX_NTAB],
              double log_p_tab[MAX_NTAB],
              int    n_tab,
              int    *n_nearest_pt)
{
 return pow(10.0,interp(log_p_tab,log_h_tab,n_tab,log10(pp), n_nearest_pt));
}

/*C*/
/*******************************************************************/
double n0_at_e(double ee,
               double log_n0_tab[MAX_NTAB],
               double log_e_tab[MAX_NTAB],
               int    n_tab,
               int    *n_nearest_pt)
{
 return pow(10.0,interp(log_e_tab,log_n0_tab,n_tab,log10(ee), n_nearest_pt));
}
/*C*/
/***************************************************************/
double e_at_n0(double nn0,
               double log_e_tab[MAX_NTAB],
               double log_n0_tab[MAX_NTAB],
               int    n_tab,
               int    *n_nearest_pt)
{
 return pow(10.0,interp(log_n0_tab,log_e_tab,n_tab,log10(nn0), n_nearest_pt));
}
/*C*/
/***************************************************************/
void make_center(double e_center,
                 double log_e_tab[MAX_NTAB],
                 double log_p_tab[MAX_NTAB],
                 double log_h_tab[MAX_NTAB],
                 int n_tab,
                 char eos_type[],
		 double eos_k,
                 double Gamma_P,
                 double *p_center,
                 double *h_center)
{
 int n_nearest;

 double rho0_center;

 n_nearest=n_tab/2;

 if(strcmp(eos_type,"tab")==0) {
   (*p_center) = p_at_e( e_center, log_p_tab, log_e_tab, n_tab, &n_nearest);
   (*h_center) = h_at_p( (*p_center), log_h_tab, log_p_tab, n_tab, &n_nearest);
 }
 else {
       rho0_center = rtsec_G( e_of_rho0, Gamma_P, 0.0,e_center,DBL_EPSILON,
                              e_center, eos_k );
       (*p_center) = eos_k*pow(rho0_center,Gamma_P);
       (*h_center) = log((e_center+(*p_center))/rho0_center);
 }


}

/*C*/
/********************************************************************/
/* Compute various quantities.                                      */
/********************************************************************/
void comp_values(double s_gp[SDIV+1],
                 double mu[MDIV+1],
                 double r_ratio,
                 double e_surface,
                 double r_e,
                 char   eos_type[],
                 double log_e_tab[MAX_NTAB],
                 double log_n0_tab[MAX_NTAB],
                 int    n_tab,
                 double Omega,
                 double **rho,
                 double **gama,
                 double **alpha,
                 double **omega,
                 double **energy,
                 double **pressure,
                 double **enthalpy,
                 double **velocity_sq,
                 double *Mass,
                 double *Mass_0,
                 double *T,
                 double *W,
                 double *Omega_K,
                 double *R_e,
                 char   rotation_type[],
		 double **Omega_diff,
		 double *J)
{
 int s,
     m,
     n_nearest;


 double **velocity,                /* velocity */
        **rho_0,                   /* rest mass density */
        gama_equator,              /* gama at equator */
        rho_equator,               /* rho at equator */
        omega_equator,             /* omega at equator */
        D_m[SDIV+1],               /* int. quantity for M */
        D_m_0[SDIV+1],             /* int. quantity for M_0 */
        D_m_p[SDIV+1],             /* int. quantity for M_p */
        D_J[SDIV+1],               /* int. quantity for J */
        d_o_e[SDIV+1],
        d_g_e[SDIV+1],
        d_r_e[SDIV+1],
        doe,
        dge,
        dre,
        vek,
        s_e,
        gama_mu_0[SDIV+1],
        rho_mu_0[SDIV+1],
        omega_mu_0[SDIV+1],
        Mass_p,
        T_diff,
        D_T[SDIV+1];               /* int. quantity for J */


   s_e=0.5;

   velocity = array_allocate(1,SDIV,1,MDIV);
   rho_0 = array_allocate(1,SDIV,1,MDIV);

   for(s=1;s<=SDIV;s++)
    for(m=1;m<=MDIV;m++)
     velocity[s][m]=sqrt(velocity_sq[s][m]);

   for(s=1;s<=SDIV;s++) {
      gama_mu_0[s]=gama[s][1];
      rho_mu_0[s]=rho[s][1];
      omega_mu_0[s]=omega[s][1];
   }

   n_nearest= SDIV/2;
   gama_equator=interp(s_gp,gama_mu_0,SDIV,s_e, &n_nearest);
   rho_equator=interp(s_gp,rho_mu_0,SDIV,s_e, &n_nearest);

   if(r_ratio==1.0) {
    omega_equator=0.0;
   }
   else {
    omega_equator=interp(s_gp,omega_mu_0,SDIV,s_e, &n_nearest);
   }

/* Circumferential radius */

   if(strcmp(eos_type,"tab")==0)
       (*R_e) = r_e*exp((gama_equator-rho_equator)/2.0);
/*       (*R_e) = sqrt(KAPPA)*r_e*exp((gama_equator-rho_equator)/2.0); */ /*conversion*/
   else
     (*R_e) = r_e*exp((gama_equator-rho_equator)/2.0);

 /* Masses and angular momentum */

   (*Mass) = 0.0;              /* initialize */
   (*Mass_0) = 0.0;
   Mass_p = 0.0;
   (*J)=0.0;
   T_diff = 0.0;

 if(strcmp(eos_type,"tab")==0) {
   n_nearest=n_tab/2;
   for(s=1;s<=SDIV;s++)
      for(m=1;m<=MDIV;m++) {
           if(energy[s][m]>e_surface)
/*             rho_0[s][m]=n0_at_e(energy[s][m], log_n0_tab, log_e_tab, n_tab,
                                             &n_nearest)*MB*KSCALE*SQ(C); */
             /*this conversion factor should be MB*cactusM*/
	     rho_0[s][m]=n0_at_e(energy[s][m], log_n0_tab, log_e_tab, n_tab,
				 &n_nearest)*MB*cactusM;
           else
             rho_0[s][m]=0.0;
      }
 }else {
        for(s=1;s<=SDIV;s++)
           for(m=1;m<=MDIV;m++)
                rho_0[s][m]=(energy[s][m]+pressure[s][m])*exp(-enthalpy[s][m]);
  }


   for(s=1;s<=SDIV;s++) {
    D_m[s]=0.0;           /* initialize */
    D_m_0[s]=0.0;
    D_m_p[s]=0.0;
    D_J[s]=0.0;
    D_T[s]=0.0;

    for(m=1;m<=MDIV-2;m+=2) {
     D_m[s] += (1.0/(3.0*(MDIV-1)))*( exp(2.0*alpha[s][m]+gama[s][m])*
              (((energy[s][m]+pressure[s][m])/(1.0-velocity_sq[s][m]))*
              (1.0+velocity_sq[s][m]+(2.0*s_gp[s]*sqrt(velocity_sq[s][m])/
              (1.0-s_gp[s]))*sqrt(1.0-mu[m]*mu[m])*r_e*omega[s][m]*
              exp(-rho[s][m])) + 2.0*pressure[s][m])

            + 4.0*exp(2.0*alpha[s][m+1]+gama[s][m+1])*
              (((energy[s][m+1]+pressure[s][m+1])/(1.0-velocity_sq[s][m+1]))*
              (1.0+velocity_sq[s][m+1]+(2.0*s_gp[s]*sqrt(velocity_sq[s][m+1])/
              (1.0-s_gp[s]))*sqrt(1.0-mu[m+1]*mu[m+1])*r_e*omega[s][m+1]*
              exp(-rho[s][m+1])) + 2.0*pressure[s][m+1])

            + exp(2.0*alpha[s][m+2]+gama[s][m+2])*
              (((energy[s][m+2]+pressure[s][m+2])/(1.0-velocity_sq[s][m+2]))*
              (1.0+velocity_sq[s][m+2]+(2.0*s_gp[s]*sqrt(velocity_sq[s][m+2])/
              (1.0-s_gp[s]))*sqrt(1.0-mu[m+2]*mu[m+2])*r_e*omega[s][m+2]*
              exp(-rho[s][m+2])) + 2.0*pressure[s][m+2]));

     D_m_0[s] += (1.0/(3.0*(MDIV-1)))*( exp(2.0*alpha[s][m]+(gama[s][m]
              -rho[s][m])/2.0)*rho_0[s][m]/sqrt(1.0-velocity_sq[s][m])

             + 4.0* exp(2.0*alpha[s][m+1]+(gama[s][m+1]
             -rho[s][m+1])/2.0)*rho_0[s][m+1]/sqrt(1.0-velocity_sq[s][m+1])

             + exp(2.0*alpha[s][m+2]+(gama[s][m+2]
             -rho[s][m+2])/2.0)*rho_0[s][m+2]/sqrt(1.0-velocity_sq[s][m+2]));

     D_m_p[s] += (1.0/(3.0*(MDIV-1)))*( exp(2.0*alpha[s][m]+(gama[s][m]
              -rho[s][m])/2.0)*energy[s][m]/sqrt(1.0-velocity_sq[s][m])

              + 4.0* exp(2.0*alpha[s][m+1]+(gama[s][m+1]
              -rho[s][m+1])/2.0)*energy[s][m+1]/sqrt(1.0-velocity_sq[s][m+1])

             + exp(2.0*alpha[s][m+2]+(gama[s][m+2]
             -rho[s][m+2])/2.0)*energy[s][m+2]/sqrt(1.0-velocity_sq[s][m+2]));

     D_J[s] += (1.0/(3.0*(MDIV-1)))*( sqrt(1.0-mu[m]*mu[m])*
              exp(2.0*alpha[s][m]+gama[s][m]-rho[s][m])*(energy[s][m]
              +pressure[s][m])*sqrt(velocity_sq[s][m])/(1.0-velocity_sq[s][m])

              +4.0*sqrt(1.0-mu[m+1]*mu[m+1])*
              exp(2.0*alpha[s][m+1]+gama[s][m+1]-rho[s][m+1])*(energy[s][m+1]
              +pressure[s][m+1])*sqrt(velocity_sq[s][m+1])/
              (1.0-velocity_sq[s][m+1])

              + sqrt(1.0-mu[m+2]*mu[m+2])*
              exp(2.0*alpha[s][m+2]+gama[s][m+2]-rho[s][m+2])*(energy[s][m+2]
              +pressure[s][m+2])*sqrt(velocity_sq[s][m+2])/
              (1.0-velocity_sq[s][m+2]));

     D_T[s] += (1.0/(3.0*(MDIV-1)))*( sqrt(1.0-mu[m]*mu[m])*
              exp(2.0*alpha[s][m]+gama[s][m]-rho[s][m])*(energy[s][m]
              +pressure[s][m])*sqrt(velocity_sq[s][m])*Omega_diff[s][m]/
              (1.0-velocity_sq[s][m])

              +4.0*sqrt(1.0-mu[m+1]*mu[m+1])*
              exp(2.0*alpha[s][m+1]+gama[s][m+1]-rho[s][m+1])*(energy[s][m+1]
              +pressure[s][m+1])*sqrt(velocity_sq[s][m+1])*Omega_diff[s][m+1]/
              (1.0-velocity_sq[s][m+1])

              + sqrt(1.0-mu[m+2]*mu[m+2])*
              exp(2.0*alpha[s][m+2]+gama[s][m+2]-rho[s][m+2])*(energy[s][m+2]
              +pressure[s][m+2])*sqrt(velocity_sq[s][m+2])*Omega_diff[s][m+2]/
              (1.0-velocity_sq[s][m+2]));
    }
   }

    for(s=1;s<=SDIV-4;s+=2) {
     (*Mass) += (SMAX/(3.0*(SDIV-1)))*(pow(sqrt(s_gp[s])/(1.0-s_gp[s]),4.0)*
          D_m[s]+4.0*pow(sqrt(s_gp[s+1])/(1.0-s_gp[s+1]),4.0)*D_m[s+1]
          +pow(sqrt(s_gp[s+2])/(1.0-s_gp[s+2]),4.0)*D_m[s+2]);

     (*Mass_0) += (SMAX/(3.0*(SDIV-1)))*(pow(sqrt(s_gp[s])/(1.0-s_gp[s]),4.0)*
          D_m_0[s]+4.0*pow(sqrt(s_gp[s+1])/(1.0-s_gp[s+1]),4.0)*D_m_0[s+1]
          +pow(sqrt(s_gp[s+2])/(1.0-s_gp[s+2]),4.0)*D_m_0[s+2]);

     Mass_p += (SMAX/(3.0*(SDIV-1)))*(pow(sqrt(s_gp[s])/(1.0-s_gp[s]),4.0)*
          D_m_p[s]+4.0*pow(sqrt(s_gp[s+1])/(1.0-s_gp[s+1]),4.0)*D_m_p[s+1]
          +pow(sqrt(s_gp[s+2])/(1.0-s_gp[s+2]),4.0)*D_m_p[s+2]);

     (*J) += (SMAX/(3.0*(SDIV-1)))*((pow(s_gp[s],3.0)/pow(1.0-s_gp[s],5.0))*
          D_J[s]+ 4.0*(pow(s_gp[s+1],3.0)/pow(1.0-s_gp[s+1],5.0))*
          D_J[s+1] + (pow(s_gp[s+2],3.0)/pow(1.0-s_gp[s+2],5.0))*
          D_J[s+2]);

     T_diff += (SMAX/(3.0*(SDIV-1)))*((pow(s_gp[s],3.0)/pow(1.0-s_gp[s],5.0))*
          D_T[s]+ 4.0*(pow(s_gp[s+1],3.0)/pow(1.0-s_gp[s+1],5.0))*
          D_T[s+1] + (pow(s_gp[s+2],3.0)/pow(1.0-s_gp[s+2],5.0))*
          D_T[s+2]);
    }

    if(strcmp(eos_type,"tab")==0) {
/*	(*Mass) *= 4*PI*sqrt(KAPPA)*C*C*pow(r_e,3.0)/G; conversions
	(*Mass_0) *= 4*PI*sqrt(KAPPA)*C*C*pow(r_e,3.0)/G;
	Mass_p *= 4*PI*sqrt(KAPPA)*C*C*pow(r_e,3.0)/G;*/
	(*Mass) *= 4*PI*pow(r_e,3.0);
	(*Mass_0) *= 4*PI*pow(r_e,3.0);
	Mass_p *= 4*PI*pow(r_e,3.0);
    }
    else {
          (*Mass) *= 4*PI*pow(r_e,3.0);
          (*Mass_0) *= 4*PI*pow(r_e,3.0);
          Mass_p *= 4*PI*pow(r_e,3.0);
    }

    if(r_ratio==1.0)
         (*J)=0.0;
    else {
          if(strcmp(eos_type,"tab")==0) {
/*              (*J) *= 4*PI*KAPPA*C*C*C*pow(r_e,4.0)/G;  conversions
              T_diff *= 2.0*PI*sqrt(KAPPA)*C*C*C*C*pow(r_e,4.0)/G;*/
              (*J) *= 4*PI*pow(r_e,4.0);
              T_diff *= 2.0*PI*pow(r_e,4.0);
          }
          else {
              (*J) *= 4*PI*pow(r_e,4.0);
              T_diff *= 2.0*PI*pow(r_e,4.0);
          }
    }
    if(strcmp(rotation_type,"uniform")==0)
        (*T)=0.5*(*J)*Omega;
    else
        (*T)= T_diff;


    if(strcmp(eos_type,"tab")==0)
/*	(*W) = Mass_p*C*C - (*Mass)*C*C + (*T); */ /* conversions*/
	(*W) = Mass_p - (*Mass) + (*T);
    else
      (*W) = Mass_p - (*Mass) + (*T);


/* Kepler angular velocity */

/* MODIFY FOR DIFF. ROTATION */

   for(s=1;s<=SDIV;s++) {
     d_o_e[s]=deriv_s(omega,s,1);
     d_g_e[s]=deriv_s(gama,s,1);
     d_r_e[s]=deriv_s(rho,s,1);
   }

   n_nearest=SDIV/2;
   doe=interp(s_gp,d_o_e,SDIV,s_e, &n_nearest);
   dge=interp(s_gp,d_g_e,SDIV,s_e, &n_nearest);
   dre=interp(s_gp,d_r_e,SDIV,s_e, &n_nearest);

  vek=(doe/(8.0+dge-dre))*r_e*exp(-rho_equator) + sqrt(((dge+dre)/(8.0+dge
        -dre)) + pow((doe/(8.0+dge-dre))*r_e*exp(-rho_equator),2.0));

  if(strcmp(eos_type,"tab")==0)
/*      (*Omega_K) = (C/sqrt(KAPPA))*(omega_equator+vek*exp(rho_equator)/r_e); */ /*conversions*/
      (*Omega_K) = (omega_equator+vek*exp(rho_equator)/r_e);
  else
    (*Omega_K) = omega_equator + vek*exp(rho_equator)/r_e;


   array_free(velocity,1,SDIV,1,MDIV);
   array_free(rho_0,1,SDIV,1,MDIV);

}

/*C*/
/**************************************************************************/
double dm_dr_is(double r_is,
                double r,
                double m,
                double p,
                double e_center,
                double p_surface,
                double log_e_tab[MAX_NTAB],   /* was [SDIV+1], corrected by niksterg on 16.10.14 */
                double log_p_tab[MAX_NTAB],   /* was [SDIV+1], corrected by niksterg on 16.10.14 */
                int    n_tab,
                int    *n_nearest_pt,
                char eos_type[],
		double eos_k,
                double Gamma_P)
{
 double dmdr,
        e_d;

 if(p<p_surface)
    e_d=0.0;
 else
   e_d = e_at_p(p, log_e_tab, log_p_tab, n_tab, n_nearest_pt, eos_type, eos_k, Gamma_P);

 if(r_is<RMIN)
    dmdr=4.0*PI*e_center*r*r*(1.0+4.0*PI*e_center*r*r/3.0);
 else
    dmdr=4.0*PI*e_d*r*r*r*sqrt(1.0-2.0*m/r)/r_is;

return dmdr;
}

/*C*/
/**************************************************************************/
double dp_dr_is(double r_is,
                double r,
                double m,
                double p,
                double e_center,
                double p_surface,
                double log_e_tab[MAX_NTAB],   /* was [SDIV+1], corrected by niksterg on 160016.10.14 */
                double log_p_tab[MAX_NTAB],   /* was [SDIV+1], corrected by niksterg on 160016.10.14 */
                int    n_tab,
                int    *n_nearest_pt,
                char eos_type[],
		double eos_k,
                double Gamma_P)
{ double dpdr,
         e_d;

  if(p<p_surface) e_d=0.0;
  else
    e_d=e_at_p(p, log_e_tab, log_p_tab, n_tab, n_nearest_pt, eos_type, eos_k, Gamma_P);

  if(r_is<RMIN) dpdr = -4.0*PI*(e_center+p)*(e_center+3.0*p)*r*(1.0
                     +4.0*e_center*r*r/3.0)/3.0;

  else
   dpdr = -(e_d+p)*(m+4.0*PI*r*r*r*p)/(r*r_is*sqrt(1.0-2.0*m/r));

 return dpdr;
}


/**************************************************************************/
double dr_dr_is(double r_is, double r, double m)
{
 double drdris;

 if(r_is<RMIN) drdris=1.0;
  else
   drdris=(r/r_is)*sqrt(1.0-2.0*m/r);

 return drdris;
}

/*C*/
/************************************************************************/
void integrate(int    i_check,
               char   eos_type[],
	       double eos_k,
               double e_center,
               double p_center,
               double p_surface,
               double e_surface,
               double Gamma_P,
               double log_e_tab[MAX_NTAB],
               double log_p_tab[MAX_NTAB],
               double log_h_tab[MAX_NTAB],
               int    n_tab,
               double r_is_gp[RDIV+1],
               double lambda_gp[RDIV+1],
               double nu_gp[RDIV+1],
               double *r_is_final,
               double *r_final,
               double *m_final)
{
  int i=2,
      n_nearest;

  double r,                           /* radius */
         r_is,                        /* isotropic radial coordinate */
         r_is_est,                    /* estimate on final isotr. radius */
         r_is_check,                  /*                      */
         dr_is_save,                  /* r_is saving interval */
         rho0,
         e_d,                         /* density */
         p,                           /* pressure */
         h,                           /* stepsize during integration */
         m,                           /* mass   */
         nu_s,
         hh,
         a1,a2,a3,a4,b1,b2,b3,b4,     /* coeff. in Runge-Kutta equations */
         c1,c2,c3,c4,
         k_rescale,
         r_gp[RDIV+1],
         e_d_gp[RDIV+1];


    if(i_check==1) {
      if(strcmp(eos_type,"tab")==0)
	  r_is_est=1.5e6/sqrt(KAPPA);/*is this a conversion or not?*/
      else
        r_is_est=2.0*sqrt(Gamma_P/(4.0*PI*(Gamma_P-1.0)))*
                            pow(e_center,(Gamma_P-2.0)/2.0);

      h=r_is_est/100;
    }
    else {
          r_is_est= (*r_is_final);
          h=r_is_est/10000;
	 }

    dr_is_save = (*r_is_final)/RDIV;
    r_is_check = dr_is_save;
    r_is=0.0;                            /* initial isotropic radius */
    r=0.0;                               /* initial radius */
    m=0.0;                               /* initial mass */
    p=p_center;                          /* initial pressure */

    r_is_gp[1]=0.0;
    r_gp[1]=0.0;
    lambda_gp[1]=0.0;
    e_d_gp[1] = e_center;

    n_nearest = n_tab/2;

    while (p>=p_surface) {

      e_d = e_at_p(p, log_e_tab, log_p_tab, n_tab, &n_nearest, eos_type, eos_k, Gamma_P);

     if((i_check==3) && (r_is>r_is_check) && (i<=RDIV)) {
      r_is_gp[i]=r_is;
      r_gp[i]=r;
      e_d_gp[i]=e_d;
      i++;
      r_is_check += dr_is_save;
     }

     (*r_is_final)=r_is;
     (*r_final)=r;
     (*m_final)=m;



     a1=dr_dr_is(r_is,r,m);

     b1=dm_dr_is(r_is,r,m,p, e_center, p_surface, log_e_tab, log_p_tab, n_tab,
                                                &n_nearest, eos_type, eos_k, Gamma_P);
     c1=dp_dr_is(r_is,r,m,p, e_center, p_surface, log_e_tab, log_p_tab, n_tab,
                                                &n_nearest, eos_type, eos_k, Gamma_P);



     a2=dr_dr_is(r_is+h/2.0, r+h*a1/2.0, m+h*b1/2.0);

     b2=dm_dr_is(r_is+h/2.0, r+h*a1/2.0, m+h*b1/2.0, p+h*c1/2.0, e_center,
                          p_surface, log_e_tab, log_p_tab, n_tab,&n_nearest,
                          eos_type, eos_k, Gamma_P);

     c2=dp_dr_is(r_is+h/2.0, r+h*a1/2.0, m+h*b1/2.0, p+h*c1/2.0, e_center,
                          p_surface, log_e_tab, log_p_tab, n_tab,&n_nearest,
                          eos_type, eos_k, Gamma_P);



     a3=dr_dr_is(r_is+h/2.0, r+h*a2/2.0, m+h*b2/2.0);

     b3=dm_dr_is(r_is+h/2.0, r+h*a2/2.0, m+h*b2/2.0, p+h*c2/2.0, e_center,
                          p_surface, log_e_tab, log_p_tab, n_tab,&n_nearest,
                          eos_type, eos_k, Gamma_P);

     c3=dp_dr_is(r_is+h/2.0, r+h*a2/2.0, m+h*b2/2.0, p+h*c2/2.0, e_center,
                          p_surface, log_e_tab, log_p_tab, n_tab,&n_nearest,
                          eos_type, eos_k, Gamma_P);



     a4=dr_dr_is(r_is+h, r+h*a3, m+h*b3);

     b4=dm_dr_is(r_is+h, r+h*a3, m+h*b3, p+h*c3, e_center, p_surface,
                                log_e_tab, log_p_tab, n_tab,&n_nearest,
                                eos_type, eos_k, Gamma_P);

     c4=dp_dr_is(r_is+h, r+h*a3, m+h*b3, p+h*c3, e_center, p_surface,
                                log_e_tab, log_p_tab, n_tab,&n_nearest,
                                eos_type, eos_k, Gamma_P);



     r += (h/6.0)*(a1+2*a2+2*a3+a4);
     m += (h/6.0)*(b1+2*b2+2*b3+b4);
     p += (h/6.0)*(c1+2*c2+2*c3+c4);

     r_is += h;

    }

    r_is_gp[RDIV]=(*r_is_final);
    r_gp[RDIV]=(*r_final);


/* Rescale r_is and compute lambda */

   if(i_check==3) {
      k_rescale=0.5*((*r_final)/(*r_is_final))*(1.0-(*m_final)/(*r_final)+
                sqrt(1.0-2.0*(*m_final)/(*r_final)));

      (*r_is_final) *= k_rescale;

      nu_s = log((1.0-(*m_final)/(2.0*(*r_is_final)))/(1.0+(*m_final)/
               (2.0*(*r_is_final))));

      for(i=1;i<=RDIV;i++) {
         r_is_gp[i] *= k_rescale;

         if(i==1) lambda_gp[1]= log(1.0/k_rescale);
           else
               lambda_gp[i]=log(r_gp[i]/r_is_gp[i]);

         if(e_d_gp[i]<e_surface)

           hh=0.0;

         else { if(strcmp(eos_type,"tab")==0) {
                  p=p_at_e(e_d_gp[i], log_p_tab, log_e_tab, n_tab, &n_nearest);
                  hh=h_at_p(p, log_h_tab, log_p_tab, n_tab, &n_nearest);
                }
                else {
                     rho0=rtsec_G(e_of_rho0,Gamma_P,0.0,e_d_gp[i],DBL_EPSILON,
				  e_d_gp[i], eos_k);
                      p=eos_k*pow(rho0,Gamma_P);
                      hh=log((e_d_gp[i]+p)/rho0);
                }
              }

         nu_gp[i]=nu_s-hh;
      }
      nu_gp[RDIV]=nu_s;
   }
}

/*C*/
/*************************************************************************/
void guess(double s_gp[SDIV+1],
           char   eos_type[],
	   double eos_k,
           double e_center,
           double p_center,
           double p_surface,
           double e_surface,
           double Gamma_P,
           double log_e_tab[MAX_NTAB],
           double log_p_tab[MAX_NTAB],
           double log_h_tab[MAX_NTAB],
           int    n_tab,
           double **rho,
           double **gama,
           double **alpha,
           double **omega,
           double *r_e)
{
 int s,
     m,
     n_nearest;

 double r_is_s,
        r_is_final=0.0,
        r_final,
        m_final,
        lambda_s,
        nu_s,
        r_is_gp[RDIV+1],
        lambda_gp[RDIV+1],
        nu_gp[RDIV+1],
        gama_mu_0[SDIV+1],
        rho_mu_0[SDIV+1],
        gama_eq,
        rho_eq,
        s_e=0.5;


 integrate(1, eos_type, eos_k, e_center, p_center, p_surface, e_surface, Gamma_P,
              log_e_tab, log_p_tab, log_h_tab, n_tab, r_is_gp, lambda_gp,
              nu_gp, &r_is_final, &r_final, &m_final);

 integrate(2, eos_type, eos_k, e_center, p_center, p_surface, e_surface, Gamma_P,
              log_e_tab, log_p_tab, log_h_tab, n_tab, r_is_gp, lambda_gp,
              nu_gp, &r_is_final, &r_final, &m_final);

 integrate(3, eos_type, eos_k, e_center, p_center, p_surface, e_surface, Gamma_P,
              log_e_tab, log_p_tab, log_h_tab, n_tab, r_is_gp, lambda_gp,
              nu_gp, &r_is_final, &r_final, &m_final);


 n_nearest=RDIV/2;
 for(s=1;s<=SDIV;s++) {
    r_is_s=r_is_final*(s_gp[s]/(1.0-s_gp[s]));

    if(r_is_s<r_is_final) {
      lambda_s=interp(r_is_gp,lambda_gp,RDIV,r_is_s,&n_nearest);
      nu_s=interp(r_is_gp,nu_gp,RDIV,r_is_s,&n_nearest);
    }
    else {
      lambda_s=2.0*log(1.0+m_final/(2.0*r_is_s));
      nu_s=log((1.0-m_final/(2.0*r_is_s))/(1.0+m_final/(2*r_is_s)));
    }

    gama[s][1]=nu_s+lambda_s;
    rho[s][1]=nu_s-lambda_s;

    for(m=1;m<=MDIV;m++) {
        gama[s][m]=gama[s][1];
        rho[s][m]=rho[s][1];
        alpha[s][m]=(gama[s][1]-rho[s][1])/2.0;
        omega[s][m]=0.0;
    }

    gama_mu_0[s]=gama[s][1];                   /* gama at \mu=0 */
    rho_mu_0[s]=rho[s][1];                     /* rho at \mu=0 */

 }

   n_nearest=SDIV/2;
   gama_eq = interp(s_gp,gama_mu_0,SDIV,s_e,&n_nearest); /* gama at equator */
   rho_eq = interp(s_gp,rho_mu_0,SDIV,s_e,&n_nearest);   /* rho at equator */

   (*r_e)= r_final*exp(0.5*(rho_eq-gama_eq));

}


/*C*/
/*************************************************************************/
/* Main iteration cycle.                                                 */
/*************************************************************************/
void iterate(double s_gp[SDIV+1],
             double mu[MDIV+1],
             char   eos_type[],
	     double eos_k,
             double log_e_tab[MAX_NTAB],
             double log_p_tab[MAX_NTAB],
             double log_h_tab[MAX_NTAB],
             int    n_tab,
             double Gamma_P,
             double r_ratio,
             double h_center,
             double enthalpy_min,
             int    a_check,
             double accuracy,
             int    print_dif,
             double cf,
             double *r_e_new,
             double **rho,
             double **gama,
             double **alpha,
             double **omega,
             double **energy,
             double **pressure,
             double **enthalpy,
             double **velocity_sq,
             double *Omega,
             char   rotation_type[],
             double A_diff,
             double *Omega_e,
             double **Omega_diff,
             int RNS_lmax)
 {
 int m,                      /* counter */
     s,                      /* counter */
     n,                      /* counter */
     k,                      /* counter */
     n_of_it=0,              /* number of iterations */
     n_nearest,
     i,
     j;

 /* ------------------------------
    iteration counter: it stop
    when  MAX_ITERATION  = 200;
    is reached. It is definined
    in const.h
    ---------------------------- */
int     ITERATION_COUNT= 0;

double  ***f_rho,
        ***f_gama;


double   sum_rho=0.0,         /* intermediate sum in eqn for rho */
	 sum_gama=0.0,        /* intermediate sum in eqn for gama */
	 sum_omega=0.0,       /* intermediate sum in eqn for omega */
         r_e_old,             /* equatorial radius in previus cycle */
   	 dif,                 /* difference | r_e_old - r_e | */
         d_gama_s,            /* derivative of gama w.r.t. s */
         d_gama_m,            /* derivative of gama w.r.t. m */
         d_rho_s,             /* derivative of rho w.r.t. s */
         d_rho_m,             /* derivative of rho w.r.t. m */
         d_omega_s,           /* derivative of omega w.r.t. s */
         d_omega_m,           /* derivative of omega w.r.t. m */
         d_gama_ss,           /* 2nd derivative of gama w.r.t. s */
         d_gama_mm,           /* 2nd derivative of gama w.r.t. m */
         d_gama_sm,           /* derivative of gama w.r.t. m and s */
         temp1,                /* temporary term in da_dm */
         temp2,
         temp3,
         temp4,
         temp5,
         temp6,
         temp7,
         temp8,
         m1,
         s1,
         s2,
         ea,
         rsm,
         gsm,
         omsm,
         esm,
         psm,
         v2sm,
         mum,
         sgp,
         s_1,
         e_gsm,
         e_rsm,
         rho0sm,
         term_in_Omega_h,
         r_p,
         s_p,
         gama_pole_h,                  /* gama^hat at pole */
         gama_center_h,                /* gama^hat at center */
         gama_equator_h,               /* gama^hat at equator */
         rho_pole_h,                   /* rho^hat at pole */
         rho_center_h,                 /* rho^hat at center */
         rho_equator_h,                /* rho^hat at equator */
         omega_equator_h,              /* omega^hat at equator */
         gama_mu_1[SDIV+1],            /* gama at \mu=1 */
         gama_mu_0[SDIV+1],            /* gama at \mu=0 */
         rho_mu_1[SDIV+1],             /* rho at \mu=1 */
         rho_mu_0[SDIV+1],             /* rho at \mu=0 */
         omega_mu_0[SDIV+1],           /* omega at \mu=0 */
         s_e=0.5,
       **da_dm,
       **dgds,
       **dgdm,
       **D1_rho,
       **D1_gama,
       **D1_omega,
       **D2_rho,
       **D2_gama,
       **D2_omega,
       **S_gama,
       **S_rho,
       **S_omega,
       **f2n,
       **P_2n,
       **P1_2n_1,
         Omega_h,
         sin_theta[MDIV+1],
         theta[MDIV+1],
         sk,
         sj,
         sk1,
         sj1,
         r_e,
         d_e_ds_mu_0[SDIV/2],
         s_max,
         Omega_lower_bracket,
         Omega_upper_bracket,
         Omega_e_lower_bracket,
         Omega_e_upper_bracket,
         Omega_c,
         tol;

    const int is_uniform_rotation = strcmp(rotation_type,"uniform")==0;

    f2n = array_allocate(1,RNS_lmax+1,1,SDIV);
    f_rho = tensor_allocate(1,SDIV,1,RNS_lmax+1,1,SDIV);
    f_gama = tensor_allocate(1,SDIV,1,RNS_lmax+1,1,SDIV);

    P_2n = array_allocate(1,MDIV,1,RNS_lmax+1);
    P1_2n_1 = array_allocate(1,MDIV,1,RNS_lmax+1);


    for(n=0;n<=RNS_lmax;n++)
       for(i=2;i<=SDIV;i++) f2n[n+1][i] = pow((1.0-s_gp[i])/s_gp[i],2.0*n);

    if(SMAX!=1.0) {

     for(j=2;j<=SDIV;j++)
        for(n=1;n<=RNS_lmax;n++)
           for(k=2;k<=SDIV;k++) {
                 sk=s_gp[k];
                 sj=s_gp[j];
                 sk1=1.0-sk;
                 sj1=1.0-sj;

                 if(k<j) {
                          f_rho[j][n+1][k] = f2n[n+1][j]*sj1/(sj*
                                  f2n[n+1][k]*sk1*sk1);
                          f_gama[j][n+1][k] = f2n[n+1][j]/(f2n[n+1][k]*sk*sk1);
	                 }else {
                          f_rho[j][n+1][k] = f2n[n+1][k]/(f2n[n+1][j]*sk*sk1);
                          f_gama[j][n+1][k] = f2n[n+1][k]*sj1*sj1*sk/(sj*sj
                                            *f2n[n+1][j]*sk1*sk1*sk1);
                 }
	    }
     j=1;

       n=0;
       for(k=2;k<=SDIV;k++) {
          sk=s_gp[k];
          f_rho[j][n+1][k]=1.0/(sk*(1.0-sk));
       }

       n=1;
       for(k=2;k<=SDIV;k++) {
          sk=s_gp[k];
          sk1=1.0-sk;
          f_rho[j][n+1][k]=0.0;
          f_gama[j][n+1][k]=1.0/(sk*sk1);
       }

       for(n=2;n<=RNS_lmax;n++)
          for(k=1;k<=SDIV;k++) {
             f_rho[j][n+1][k]=0.0;
             f_gama[j][n+1][k]=0.0;
          }


     k=1;

       n=0;
       for(j=1;j<=SDIV;j++)
          f_rho[j][n+1][k]=0.0;

       for(j=1;j<=SDIV;j++)
          for(n=1;n<=RNS_lmax;n++) {
             f_rho[j][n+1][k]=0.0;
             f_gama[j][n+1][k]=0.0;
          }


     n=0;
     for(j=2;j<=SDIV;j++)
        for(k=2;k<=SDIV;k++) {
               sk=s_gp[k];
               sj=s_gp[j];
               sk1=1.0-sk;
               sj1=1.0-sj;

               if(k<j)
                 f_rho[j][n+1][k] = sj1/(sj*sk1*sk1);
               else
                 f_rho[j][n+1][k] = 1.0/(sk*sk1);
      }

   }
   else{
        for(j=2;j<=SDIV-1;j++)
           for(n=1;n<=RNS_lmax;n++)
              for(k=2;k<=SDIV-1;k++) {
                 sk=s_gp[k];
                 sj=s_gp[j];
                 sk1=1.0-sk;
                 sj1=1.0-sj;

                 if(k<j) {
                          f_rho[j][n+1][k] = f2n[n+1][j]*sj1/(sj*
                                           f2n[n+1][k]*sk1*sk1);
                          f_gama[j][n+1][k] = f2n[n+1][j]/(f2n[n+1][k]*sk*sk1);
                 }else {
                          f_rho[j][n+1][k] = f2n[n+1][k]/(f2n[n+1][j]*sk*sk1);

                          f_gama[j][n+1][k] = f2n[n+1][k]*sj1*sj1*sk/(sj*sj
                                            *f2n[n+1][j]*sk1*sk1*sk1);
                 }
	      }

        j=1;

          n=0;
          for(k=2;k<=SDIV-1;k++) {
             sk=s_gp[k];
             f_rho[j][n+1][k]=1.0/(sk*(1.0-sk));
          }

          n=1;
          for(k=2;k<=SDIV-1;k++) {
             sk=s_gp[k];
             sk1=1.0-sk;
             f_rho[j][n+1][k]=0.0;
             f_gama[j][n+1][k]=1.0/(sk*sk1);
          }

          for(n=2;n<=RNS_lmax;n++)
             for(k=1;k<=SDIV-1;k++) {
                f_rho[j][n+1][k]=0.0;
                f_gama[j][n+1][k]=0.0;
             }

        k=1;

          n=0;
          for(j=1;j<=SDIV-1;j++)
             f_rho[j][n+1][k]=0.0;

          for(j=1;j<=SDIV-1;j++)
             for(n=1;n<=RNS_lmax;n++) {
                f_rho[j][n+1][k]=0.0;
                f_gama[j][n+1][k]=0.0;
             }


        n=0;
          for(j=2;j<=SDIV-1;j++)
             for(k=2;k<=SDIV-1;k++) {
                sk=s_gp[k];
                sj=s_gp[j];
                sk1=1.0-sk;
                sj1=1.0-sj;

                if(k<j)
                  f_rho[j][n+1][k] = sj1/(sj*sk1*sk1);
                else
                  f_rho[j][n+1][k] = 1.0/(sk*sk1);
             }

        j=SDIV;
          for(n=1;n<=RNS_lmax;n++)
             for(k=1;k<=SDIV;k++) {
                f_rho[j][n+1][k] = 0.0;
                f_gama[j][n+1][k] = 0.0;
             }

        k=SDIV;
          for(j=1;j<=SDIV;j++)
              for(n=1;n<=RNS_lmax;n++) {
                 f_rho[j][n+1][k] = 0.0;
                 f_gama[j][n+1][k] = 0.0;
              }
   }

  n=0;
   for(i=1;i<=MDIV;i++)
      P_2n[i][n+1]=legendre(2*n,mu[i]);

   for(i=1;i<=MDIV;i++)
     for(n=1;n<=RNS_lmax;n++) {
      P_2n[i][n+1]    = legendre(2*n,mu[i]);
      P1_2n_1[i][n+1] = plgndr(2*n-1 ,1,mu[i]);
    }

  array_free(f2n,1,RNS_lmax+1,1,SDIV);


  for(m=1;m<=MDIV;m++) {
     sin_theta[m] = sqrt(1.0-mu[m]*mu[m]);
     theta[m] = asin(sin_theta[m]);
     /* try alternative: theta[m] = acos(mu[m]); */
  }

  r_e = (*r_e_new);

  /* RESCALE Omega_e */

  (*Omega_e) *= r_e;


  /* START MAIN ITERATIVE LOOP */

  do {
      ITERATION_COUNT += 1;
      if ( ITERATION_COUNT > MAX_ITERATION ) {
          CCTK_VERROR("Max number of iteration %d reached ! Exiting.", MAX_ITERATION);
	  }


      /* Rescale potentials and construct arrays with the potentials along
       | the equatorial and polar directions.
      */

      for(s=1;s<=SDIV;s++) {
         for(m=1;m<=MDIV;m++) {
            rho[s][m] /= SQ(r_e);
            gama[s][m] /= SQ(r_e);
            alpha[s][m] /= SQ(r_e);
            omega[s][m] *= r_e;
         }
         rho_mu_0[s]=rho[s][1];
         gama_mu_0[s]=gama[s][1];
         omega_mu_0[s]=omega[s][1];
         rho_mu_1[s]=rho[s][MDIV];
         gama_mu_1[s]=gama[s][MDIV];
      }


      /* Find location of maximum energy density */

      if( is_uniform_rotation) {

	if(energy[1][1]==0.0) {  /* AT FIRST ITERATION SET s_max AT CENTER */
          s_max=0.0;
        }else{
	      for(s=1;s<=SDIV/2-1;s++) {
                 d_e_ds_mu_0[s] = deriv_s(energy,s,1);
              }

              n_nearest = SDIV/4;
              s_max = interp(d_e_ds_mu_0, s_gp, SDIV/2-1, 0.0, &n_nearest);

	}

        if(s_max<0.0)
          s_max=0.0;
      }


      /* Compute new r_e. */

      r_e_old=r_e;
      r_p=r_ratio*r_e;
      s_p=r_p/(r_p+r_e);

      n_nearest= SDIV/2;
      gama_pole_h=interp(s_gp,gama_mu_1,SDIV,s_p,&n_nearest);
      gama_equator_h=interp(s_gp,gama_mu_0,SDIV,s_e,&n_nearest);
      gama_center_h=gama[1][1];

      rho_pole_h=interp(s_gp,rho_mu_1,SDIV,s_p,&n_nearest);
      rho_equator_h=interp(s_gp,rho_mu_0,SDIV,s_e,&n_nearest);
      rho_center_h=rho[1][1];

      r_e=sqrt(2*h_center/(gama_pole_h+rho_pole_h-gama_center_h-rho_center_h));


      /* Compute angular velocity Omega */

      if( is_uniform_rotation) {

        if(r_ratio==1.0) {
          Omega_h=0.0;
          omega_equator_h=0.0;
        }
        else {
              omega_equator_h=interp(s_gp,omega_mu_0,SDIV,s_e, &n_nearest);
              term_in_Omega_h=1.0-exp(SQ(r_e)*(gama_pole_h+rho_pole_h
                                               -gama_equator_h-rho_equator_h));
              if(term_in_Omega_h>=0.0)
                 Omega_h = omega_equator_h + exp(SQ(r_e)*rho_equator_h)
                                            *sqrt(term_in_Omega_h);
              else {
                    Omega_h=0.0;
                    printf("sqrt in Omega_h imaginary\n");
	      }
        }

	for(s=1;s<=2*SDIV/3;s++)
	  for(m=1;m<=MDIV;m++)
	    Omega_diff[s][m] = Omega_h;

        /* this pacifies the compiler. The variable is not used in the uniform
         * case. */
        Omega_c = atof("nan");
      }
      else {
              omega_equator_h=interp(s_gp,omega_mu_0,SDIV,s_e, &n_nearest);

	          if(n_of_it==0) {
                     Omega_h = omega_equator_h + exp(SQ(r_e)*rho_equator_h)
                               *sqrt(1.0-exp(SQ(r_e)*(gama_pole_h+rho_pole_h
                               -gama_equator_h-rho_equator_h)));

                     Omega_e_lower_bracket = 0.0;
                     Omega_e_upper_bracket = 1.0*Omega_h;
                  }
                  else {
                       Omega_e_lower_bracket = (*Omega_e)/2.0;

                       if(A_diff<(0.7/r_e)) {
                         Omega_e_upper_bracket = 2.0*(*Omega_e);
                       }
                       else {
			     if(A_diff<(0.8/r_e)) {
                               Omega_e_upper_bracket = 1.75*(*Omega_e);
                             }
                             else {
                               Omega_e_upper_bracket = 1.5*(*Omega_e);
                             }
		            }
                  }

		  tol = DBL_EPSILON;

                  (*Omega_e) = zbrent_diff( diff_rotation, r_e, rho_equator_h,
                                   gama_equator_h, omega_equator_h, rho_pole_h,
                                   gama_pole_h,
                                   Omega_e_lower_bracket,
                                   Omega_e_upper_bracket, tol, A_diff);

  		  Omega_c = (*Omega_e) + SQ(1.0/A_diff)*( (*Omega_e)
                              -omega_equator_h)
                              *exp(-2.0*SQ(r_e)*rho_equator_h)/( 1.0 -
                              SQ(( (*Omega_e) -omega_equator_h)*exp(-SQ(r_e)
                              *rho_equator_h)) );


                  Omega_h =  omega_equator_h + exp(SQ(r_e)*rho_equator_h)
                               *sqrt(1.0-exp(SQ(r_e)*(gama_pole_h+rho_pole_h
                               -gama_equator_h-rho_equator_h)));

                  s=1;
 	          for(m=1;m<=MDIV-1;m++)
                          Omega_diff[s][m] = Omega_c;

                  m=MDIV;
                  for(s=1;s<=2*SDIV/3;s++)
                          Omega_diff[s][m] = Omega_c;



                  for(s=2;s<=2*SDIV/3;s++)
                     for(m=1;m<=MDIV-1;m++) {

                       Omega_lower_bracket = 0.0;

                       Omega_upper_bracket = 1.2*Omega_diff[s-1][m];


                         tol = DBL_EPSILON;

                         Omega_diff[s][m] = zbrent_rot( rotation_law, r_e,
                                                       rho[s][m], omega[s][m],
                                                       s_gp[s],mu[m], Omega_c,
                                                       Omega_lower_bracket,
                                                       Omega_upper_bracket,
                                                       tol, A_diff);
                     }
      }


      /* Compute velocity, energy density and pressure. */

      n_nearest=n_tab/2;

      if( is_uniform_rotation) {

	/* uniform rotation */

        for(s=1;s<=SDIV;s++) {
           sgp=s_gp[s];

           for(m=1;m<=MDIV;m++) {
              rsm=rho[s][m];

              if(r_ratio==1.0 || s > (SDIV/2+2) )
                    velocity_sq[s][m]=0.0;
              else {
                    velocity_sq[s][m]=SQ((Omega_h-omega[s][m])*(sgp/(1.0-sgp))
                                      *sin_theta[m]*exp(-rsm*SQ(r_e)));
	      }
              if(velocity_sq[s][m]>=1.0)
                velocity_sq[s][m]=0.0;
           }
	}

	/* differential rotation */

      } else {
            for(s=1;s<=SDIV;s++) {
	      sgp=s_gp[s];

	      for(m=1;m<=MDIV;m++) {
		rsm=rho[s][m];

		if(r_ratio==1.0 || s > (SDIV/2+2) )
		  velocity_sq[s][m]=0.0;
		else
		  velocity_sq[s][m]=SQ( (Omega_diff[s][m]-omega[s][m])
					*(sgp/(1.0-sgp))*sin_theta[m]
					*exp(-rsm*SQ(r_e)) );

		if(velocity_sq[s][m]>=1.0)
		  velocity_sq[s][m]=0.0;
	      }
	    }
      }


      for(s=1;s<=SDIV;s++) {
         sgp=s_gp[s];

         for(m=1;m<=MDIV;m++) {
            rsm=rho[s][m];

            if( is_uniform_rotation)
              enthalpy[s][m] = enthalpy_min + 0.5*(SQ(r_e)*(gama_pole_h
				+rho_pole_h-gama[s][m]-rsm)
                               -log(1.0-velocity_sq[s][m]));
            else
              enthalpy[s][m] = enthalpy_min + 0.5*(SQ(r_e)*(gama_pole_h
                               +rho_pole_h-gama[s][m]-rsm)-log(1.0
                               -velocity_sq[s][m])+SQ(A_diff*(Omega_diff[s][m]
                               -Omega_c)) );

            if((enthalpy[s][m]<=enthalpy_min) || (sgp>s_e)) {
                  pressure[s][m]=0.0;
                  energy[s][m]=0.0;
	    }
	    else { if(strcmp(eos_type,"tab")==0) {

	      pressure[s][m]=p_at_h(enthalpy[s][m], log_p_tab,
				    log_h_tab, n_tab, &n_nearest);
	      energy[s][m]=e_at_p(pressure[s][m], log_e_tab,
				  log_p_tab, n_tab, &n_nearest, eos_type, eos_k,
				  Gamma_P);

	    }
	    else { if(strcmp(eos_type,"poly")==0) {
		rho0sm=pow(((Gamma_P-1.0)/(Gamma_P*eos_k))
			 *(exp(enthalpy[s][m])-1.0),1.0/(Gamma_P-1.0));

	      pressure[s][m]=eos_k*pow(rho0sm,Gamma_P);

	      energy[s][m]=pressure[s][m]/(Gamma_P-1.0)+rho0sm;
	    }
	    else { /* uniform density - activate later */
	      /*
		pressure[s][m]=exp(enthalpy[s][m])-1.0;
		energy[s][m]=e_center;
	      */
	      printf(" NO NO NO NO NO OTHER EOS ");

	    }
	    }


	    }

            /* Rescale back metric potentials (except omega) */

            rho[s][m] *= SQ(r_e);
            gama[s][m] *= SQ(r_e);
            alpha[s][m] *= SQ(r_e);
	 }
      }


      /* Compute metric potentials */

      S_gama = array_allocate(1,SDIV,1,MDIV);
      S_rho = array_allocate(1,SDIV,1,MDIV);
      S_omega = array_allocate(1,SDIV,1,MDIV);


      if( is_uniform_rotation) {

       for(s=1;s<=SDIV;s++)
         for(m=1;m<=MDIV;m++) {
            rsm=rho[s][m];
            gsm=gama[s][m];
            omsm=omega[s][m];
            esm=energy[s][m];
            psm=pressure[s][m];
            e_gsm=exp(0.5*gsm);
            e_rsm=exp(-rsm);
            v2sm=velocity_sq[s][m];
            mum=mu[m];
            m1=1.0-SQ(mum);
            sgp=s_gp[s];
            s_1=1.0-sgp;
            s1=sgp*s_1;
            s2=SQ(sgp/s_1);

            ea=16.0*PI*exp(2.0*alpha[s][m])*SQ(r_e);

            if(s==1) {
              d_gama_s=0.0;
              d_gama_m=0.0;
              d_rho_s=0.0;
              d_rho_m=0.0;
              d_omega_s=0.0;
              d_omega_m=0.0;
            }else{
                 d_gama_s=deriv_s(gama,s,m);
                 d_gama_m=deriv_m(gama,s,m);
                 d_rho_s=deriv_s(rho,s,m);
                 d_rho_m=deriv_m(rho,s,m);
                 d_omega_s=deriv_s(omega,s,m);
                 d_omega_m=deriv_m(omega,s,m);
	     }

            S_rho[s][m] = e_gsm*(0.5*ea*(esm + psm)*s2*(1.0+v2sm)/(1.0-v2sm)

                          + s2*m1*SQ(e_rsm)*(SQ(s1*d_omega_s)

                          + m1*SQ(d_omega_m))

                          + s1*d_gama_s - mum*d_gama_m + 0.5*rsm*(ea*psm*s2

                          - s1*d_gama_s*(0.5*s1*d_gama_s+1.0)

                          - d_gama_m*(0.5*m1*d_gama_m-mum)));

            S_gama[s][m] = e_gsm*(ea*psm*s2 + 0.5*gsm*(ea*psm*s2 - 0.5*SQ(s1

                           *d_gama_s) - 0.5*m1*SQ(d_gama_m)));

            S_omega[s][m]=e_gsm*e_rsm*( -ea*(Omega_h-omsm)*(esm+psm)

                          *s2/(1.0-v2sm) + omsm*( -0.5*ea*(((1.0+v2sm)*esm

                          + 2.0*v2sm*psm)/(1.0-v2sm))*s2

                          - s1*(2*d_rho_s+0.5*d_gama_s)

                          + mum*(2*d_rho_m+0.5*d_gama_m) + 0.25*SQ(s1)*(4

                          *SQ(d_rho_s)-SQ(d_gama_s)) + 0.25*m1*(4*SQ(d_rho_m)

                          - SQ(d_gama_m)) - m1*SQ(e_rsm)*(SQ(SQ(sgp)*d_omega_s)

                          + s2*m1*SQ(d_omega_m))));
	 }
     }
     else{


       for(s=1;s<=SDIV;s++)
         for(m=1;m<=MDIV;m++) {
            rsm=rho[s][m];
            gsm=gama[s][m];
            omsm=omega[s][m];
            esm=energy[s][m];
            psm=pressure[s][m];
            e_gsm=exp(0.5*gsm);
            e_rsm=exp(-rsm);
            v2sm=velocity_sq[s][m];
            mum=mu[m];
            m1=1.0-SQ(mum);
            sgp=s_gp[s];
            s_1=1.0-sgp;
            s1=sgp*s_1;
            s2=SQ(sgp/s_1);

            ea=16.0*PI*exp(2.0*alpha[s][m])*SQ(r_e);

            if(s==1) {
              d_gama_s=0.0;
              d_gama_m=0.0;
              d_rho_s=0.0;
              d_rho_m=0.0;
              d_omega_s=0.0;
              d_omega_m=0.0;
            }else{
                 d_gama_s=deriv_s(gama,s,m);
                 d_gama_m=deriv_m(gama,s,m);
                 d_rho_s=deriv_s(rho,s,m);
                 d_rho_m=deriv_m(rho,s,m);
                 d_omega_s=deriv_s(omega,s,m);
                 d_omega_m=deriv_m(omega,s,m);
	     }

            S_rho[s][m] = e_gsm*(0.5*ea*(esm + psm)*s2*(1.0+v2sm)/(1.0-v2sm)

                          + s2*m1*SQ(e_rsm)*(SQ(s1*d_omega_s) + m1*SQ(d_omega_m))

                          + s1*d_gama_s - mum*d_gama_m + 0.5*rsm*(ea*psm*s2

                          - s1*d_gama_s*(0.5*s1*d_gama_s+1.0)

                          - d_gama_m*(0.5*m1*d_gama_m-mum)));

            S_gama[s][m] = e_gsm*(ea*psm*s2 + 0.5*gsm*(ea*psm*s2 - 0.5*SQ(s1

                           *d_gama_s) - 0.5*m1*SQ(d_gama_m)));

            S_omega[s][m]=e_gsm*e_rsm*( -ea*(Omega_diff[s][m]-omsm)*(esm+psm)

                          *s2/(1.0-v2sm) + omsm*( -0.5*ea*(((1.0+v2sm)*esm + 2.0

                          *v2sm*psm)/(1.0-v2sm))*s2 - s1*(2*d_rho_s+0.5*d_gama_s)

                          + mum*(2*d_rho_m+0.5*d_gama_m) + 0.25*SQ(s1)*(4

                          *SQ(d_rho_s)-SQ(d_gama_s)) + 0.25*m1*(4*SQ(d_rho_m)

                          - SQ(d_gama_m)) - m1*SQ(e_rsm)*(SQ(SQ(sgp)*d_omega_s)

                          + s2*m1*SQ(d_omega_m))));
	 }
     }



      /* ANGULAR INTEGRATION */

      D1_rho = array_allocate(1,RNS_lmax+1,1,SDIV);
      D1_gama = array_allocate(1,RNS_lmax+1,1,SDIV);
      D1_omega = array_allocate(1,RNS_lmax+1,1,SDIV);

      n=0;
      for(k=1;k<=SDIV;k++) {

         for(m=1;m<=MDIV-2;m+=2) {
               sum_rho += (DM/3.0)*(P_2n[m][n+1]*S_rho[k][m]
                          + 4.0*P_2n[m+1][n+1]*S_rho[k][m+1]
                          + P_2n[m+2][n+1]*S_rho[k][m+2]);
	 }

         D1_rho[n+1][k]=sum_rho;
         D1_gama[n+1][k]=0.0;
         D1_omega[n+1][k]=0.0;
         sum_rho=0.0;

      }

      for(n=1;n<=RNS_lmax;n++)
         for(k=1;k<=SDIV;k++) {
            for(m=1;m<=MDIV-2;m+=2) {

               sum_rho += (DM/3.0)*(P_2n[m][n+1]*S_rho[k][m]
                          + 4.0*P_2n[m+1][n+1]*S_rho[k][m+1]
                          + P_2n[m+2][n+1]*S_rho[k][m+2]);

               sum_gama += (DM/3.0)*(sin((2.0*n-1.0)*theta[m])*S_gama[k][m]
                           +4.0*sin((2.0*n-1.0)*theta[m+1])*S_gama[k][m+1]
                           +sin((2.0*n-1.0)*theta[m+2])*S_gama[k][m+2]);

               sum_omega += (DM/3.0)*(sin_theta[m]*P1_2n_1[m][n+1]*S_omega[k][m]
                            +4.0*sin_theta[m+1]*P1_2n_1[m+1][n+1]*S_omega[k][m+1]
                            +sin_theta[m+2]*P1_2n_1[m+2][n+1]*S_omega[k][m+2]);
	    }
            D1_rho[n+1][k]=sum_rho;
            D1_gama[n+1][k]=sum_gama;
            D1_omega[n+1][k]=sum_omega;
            sum_rho=0.0;
            sum_gama=0.0;
            sum_omega=0.0;
	}


      array_free(S_gama,1,SDIV,1,MDIV);
      array_free(S_rho,1,SDIV,1,MDIV);
      array_free(S_omega,1,SDIV,1,MDIV);



      /* RADIAL INTEGRATION */



      D2_rho = array_allocate(1,SDIV,1,RNS_lmax+1);
      D2_gama = array_allocate(1,SDIV,1,RNS_lmax+1);
      D2_omega = array_allocate(1,SDIV,1,RNS_lmax+1);


      n=0;
      for(s=1;s<=SDIV;s++) {
            for(k=1;k<=SDIV-2;k+=2) {
               sum_rho += (DS/3.0)*( f_rho[s][n+1][k]*D1_rho[n+1][k]
                          + 4.0*f_rho[s][n+1][k+1]*D1_rho[n+1][k+1]
                          + f_rho[s][n+1][k+2]*D1_rho[n+1][k+2]);
 	    }
	    D2_rho[s][n+1]=sum_rho;
	    D2_gama[s][n+1]=0.0;
	    D2_omega[s][n+1]=0.0;
            sum_rho=0.0;
	 }


      for(s=1;s<=SDIV;s++)
         for(n=1;n<=RNS_lmax;n++) {
            for(k=1;k<=SDIV-2;k+=2) {
               sum_rho += (DS/3.0)*( f_rho[s][n+1][k]*D1_rho[n+1][k]
                          + 4.0*f_rho[s][n+1][k+1]*D1_rho[n+1][k+1]
                          + f_rho[s][n+1][k+2]*D1_rho[n+1][k+2]);

               sum_gama += (DS/3.0)*( f_gama[s][n+1][k]*D1_gama[n+1][k]
                           + 4.0*f_gama[s][n+1][k+1]*D1_gama[n+1][k+1]
                           + f_gama[s][n+1][k+2]*D1_gama[n+1][k+2]);

               if(k<s && k+2<=s)
                 sum_omega += (DS/3.0)*( f_rho[s][n+1][k]*D1_omega[n+1][k]
                              + 4.0*f_rho[s][n+1][k+1]*D1_omega[n+1][k+1]
                              + f_rho[s][n+1][k+2]*D1_omega[n+1][k+2]);
               else {
                 if(k>=s)
                   sum_omega += (DS/3.0)*( f_gama[s][n+1][k]*D1_omega[n+1][k]
                                + 4.0*f_gama[s][n+1][k+1]*D1_omega[n+1][k+1]
                                + f_gama[s][n+1][k+2]*D1_omega[n+1][k+2]);
                 else
                   sum_omega += (DS/3.0)*( f_rho[s][n+1][k]*D1_omega[n+1][k]
                                + 4.0*f_rho[s][n+1][k+1]*D1_omega[n+1][k+1]
                                + f_gama[s][n+1][k+2]*D1_omega[n+1][k+2]);
               }
	    }
	    D2_rho[s][n+1]=sum_rho;
	    D2_gama[s][n+1]=sum_gama;
	    D2_omega[s][n+1]=sum_omega;
            sum_rho=0.0;
            sum_gama=0.0;
            sum_omega=0.0;
	 }

      array_free(D1_rho,1,RNS_lmax+1,1,SDIV);
      array_free(D1_gama,1,RNS_lmax+1,1,SDIV);
      array_free(D1_omega,1,RNS_lmax+1,1,SDIV);


      /* SUMMATION OF COEFFICIENTS */

      for(s=1;s<=SDIV;s++)
         for(m=1;m<=MDIV;m++) {

            gsm=gama[s][m];
            rsm=rho[s][m];
            omsm=omega[s][m];
            e_gsm=exp(-0.5*gsm);
            e_rsm=exp(rsm);
            temp1=sin_theta[m];

            sum_rho += -e_gsm*P_2n[m][0+1]*D2_rho[s][0+1];

            for(n=1;n<=RNS_lmax;n++) {

               sum_rho += -e_gsm*P_2n[m][n+1]*D2_rho[s][n+1];

               if(m==MDIV) {
                 sum_omega += 0.5*e_rsm*e_gsm*D2_omega[s][n+1];
                 sum_gama += -(2.0/PI)*e_gsm*D2_gama[s][n+1];
	       }
               else {
                     sum_omega += -e_rsm*e_gsm*(P1_2n_1[m][n+1]/(2.0*n
                                  *(2.0*n-1.0)*temp1))*D2_omega[s][n+1];

                     sum_gama += -(2.0/PI)*e_gsm*(sin((2.0*n-1.0)*theta[m])
                                 /((2.0*n-1.0)*temp1))*D2_gama[s][n+1];
	       }
	    }

            rho[s][m]=rsm + cf*(sum_rho-rsm);
            gama[s][m]=gsm + cf*(sum_gama-gsm);
            omega[s][m]=omsm + cf*(sum_omega-omsm);

            sum_omega=0.0;
            sum_rho=0.0;
            sum_gama=0.0;
	  }

      array_free(D2_rho,1,SDIV,1,RNS_lmax+1);
      array_free(D2_gama,1,SDIV,1,RNS_lmax+1);
      array_free(D2_omega,1,SDIV,1,RNS_lmax+1);


      /* CHECK FOR DIVERGENCE */

      if(fabs(omega[2][1])>100.0 || fabs(rho[2][1])>100.0
         || fabs(gama[2][1])>300.0) {
         a_check=200;
         break;
      }


      /* TREAT SPHERICAL CASE */

      if(r_ratio==1.0) {
        for(s=1;s<=SDIV;s++)
           for(m=1;m<=MDIV;m++) {
              rho[s][m]=rho[s][1];
              gama[s][m]=gama[s][1];
              omega[s][m]=0.0;
	   }
      }


      /* TREAT INFINITY WHEN SMAX=1.0 */

      if(SMAX==1.0) {
         for(m=1;m<=MDIV;m++) {
            rho[SDIV][m]=0.0;
            gama[SDIV][m]=0.0;
            omega[SDIV][m]=0.0;
	 }
      }


      /* COMPUTE FIRST ORDER DERIVATIVES OF GAMA */


      da_dm = array_allocate(1,SDIV,1,MDIV);
      dgds = array_allocate(1,SDIV,1,MDIV);
      dgdm = array_allocate(1,SDIV,1,MDIV);

      for(s=1;s<=SDIV;s++)
         for(m=1;m<=MDIV;m++) {
            dgds[s][m]=deriv_s(gama,s,m);
            dgdm[s][m]=deriv_m(gama,s,m);
	 }



      /* ALPHA */

      if(r_ratio==1.0) {
        for(s=1;s<=SDIV;s++)
           for(m=1;m<=MDIV;m++)
              da_dm[s][m]=0.0;
      }
      else {
            for(s=2;s<=SDIV;s++)
               for(m=1;m<=MDIV;m++) {

                  da_dm[1][m]=0.0;

                  sgp=s_gp[s];
                  s1=sgp*(1.0-sgp);
                  mum=mu[m];
                  m1=1.0-SQ(mum);

                  d_gama_s=dgds[s][m];
                  d_gama_m=dgdm[s][m];
                  d_rho_s=deriv_s(rho,s,m);
                  d_rho_m=deriv_m(rho,s,m);
                  d_omega_s=deriv_s(omega,s,m);
                  d_omega_m=deriv_m(omega,s,m);
                  d_gama_ss=s1*deriv_s(dgds,s,m)+(1.0-2.0*sgp)
                                               *d_gama_s;
                  d_gama_mm=m1*deriv_m(dgdm,s,m)-2.0*mum*d_gama_m;
                  d_gama_sm=deriv_sm(gama,s,m);

           temp1=2.0*SQ(sgp)*(sgp/(1.0-sgp))*m1*d_omega_s*d_omega_m

                *(1.0+s1*d_gama_s) - (SQ(SQ(sgp)*d_omega_s) -

                SQ(sgp*d_omega_m/(1.0-sgp))*m1)*(-mum+m1*d_gama_m);

           temp2=1.0/(m1 *SQ(1.0+s1*d_gama_s) + SQ(-mum+m1*d_gama_m));

           temp3=s1*d_gama_ss + SQ(s1*d_gama_s);

           temp4=d_gama_m*(-mum+m1*d_gama_m);

           temp5=(SQ(s1*(d_rho_s+d_gama_s)) - m1*SQ(d_rho_m+d_gama_m))

                 *(-mum+m1*d_gama_m);

           temp6=s1*m1*(0.5*(d_rho_s+d_gama_s)* (d_rho_m+d_gama_m)

                + d_gama_sm + d_gama_s*d_gama_m)*(1.0 + s1*d_gama_s);

           temp7=s1*mum*d_gama_s*(1.0+s1*d_gama_s);

           temp8=m1*exp(-2*rho[s][m]);

          da_dm[s][m] = -0.5*(d_rho_m+d_gama_m) - temp2*(0.5*(temp3 -

            d_gama_mm - temp4)*(-mum+m1*d_gama_m) + 0.25*temp5

            - temp6 +temp7 + 0.25*temp8*temp1);
       }
   }

      for(s=1;s<=SDIV;s++) {
         alpha[s][1]=0.0;
         for(m=1;m<=MDIV-1;m++)
            alpha[s][m+1]=alpha[s][m]+0.5*DM*(da_dm[s][m+1]+
                          da_dm[s][m]);
      }


   array_free(da_dm,1,SDIV,1,MDIV);
   array_free(dgds,1,SDIV,1,MDIV);
   array_free(dgdm,1,SDIV,1,MDIV);


      for(s=1;s<=SDIV;s++)
         for(m=1;m<=MDIV;m++) {
            alpha[s][m] += -alpha[s][MDIV]+0.5*(gama[s][MDIV]-rho[s][MDIV]);

            if(alpha[s][m]>=300.0) {
              a_check=200;
              break;
            }
            omega[s][m] /= r_e;
         }

      if(SMAX==1.0) {
         for(m=1;m<=MDIV;m++)
            alpha[SDIV][m] = 0.0;
      }

      if(a_check==200)
        break;

      dif=fabs(r_e_old-r_e)/r_e;
      n_of_it++;

      if(print_dif!=0)
         printf(" %4.3e\n",dif);

  } while(dif> accuracy || n_of_it<=2);   /* end do */



  /* COMPUTE OMEGA */

  if(strcmp(eos_type,"tab")==0)
/*      (*Omega) = Omega_h*C/(r_e*sqrt(KAPPA)); */ /*this should be a conversion*/
      (*Omega) = Omega_h/r_e;
  else
    (*Omega) = Omega_h/r_e;


    /* Rescale back Omega_diff[s][m] */

     /*
    if( strcmp(rotation_type,"diff")==0) {
     */
         for(s=1; s<=2*SDIV/3; s++)
	    for(m=1; m<=MDIV; m++) {
               Omega_diff[s][m] /= r_e;
            }
	 /*
    }
	 */

    /* RESCALE BACK Omega_e */

    (*Omega_e) /= r_e;


    /* UPDATE r_e_new */

    (*r_e_new) = r_e;


    tensor_free(f_rho, 1,SDIV,1,RNS_lmax+1,1,SDIV);
    tensor_free(f_gama,1,SDIV,1,RNS_lmax+1,1,SDIV);
    array_free(P_2n,   1,MDIV,1,RNS_lmax+1);
    array_free(P1_2n_1,1,MDIV,1,RNS_lmax+1);
}


void guess_AJS(double *s_gp,
               double *mu,
               char   eos_type[],
	  	         double *dens_max,
		           double Gamma_P,
		           double eos_K,
               double log_e_tab[10001],
               double log_p_tab[10001],
               double log_H_tab[10001],
               int    n_tab,
		           double Mbh,
		           double l0,
		           double *r_e,
               double **lambda,
               double **Beta,
               double **alpha,
               double **omega,
		           double *r_ratio,
		           double **density,
		           double **energy,
	             double **pressure,
		           double **H,
               double **H_raw,
               double **velocity_sq,
		           double **Omega_diff,
		           double *h0_h,
		           int *s0,
               int *n_nearest_max)
{
  int s,
      s_in,
      s_min,
      m,
      n_nearest,
      *n_nearest_pt,
      s_max_temp,
      s_Hmin;

  double r_gp,
		     ut_out,                     /* u_t at r_out=r_e */
		     Om_out,
		     gtt_out,
		     gtp_out,
		     gpp_out,
		     ut,                         /*u_t */
         gtt,
         gtp,
		     gpp,
		     dens_temp,
	       r_in,
		     *density_mu_0,
		     *dens_temp_mu_0,
		     *H_mu_0,
		     *d_density_ds_mu_0,
		     s_max,
		     H_max,
		     s_gp_in,
		     s0_tmp,
         Omega_diff_temp,
         r_horizon,
         h0_h_tmp,
         r_e_tmp;

FILE *AJS_dens_file,
     *AJS_H_file,
     *AJS_Omega_file,
     *AJS_test_file,
     *AJS_v2_file;


 /* ALLLOCATE MEMORY FOR VECTORS */

  density_mu_0 = dvector(1, SDIV/2);
  dens_temp_mu_0 = dvector(1, SDIV/2);
  H_mu_0 = dvector(1, SDIV/2);
  d_density_ds_mu_0 = dvector(1, SDIV/2);


   /********************************************************************
   / STEP 1: Adjust r_e, so that BH horizon is on nearest grid point !
   /         (this slightly changes the mass of the BH)
    *******************************************************************/

   /* define initial outer equatorial radius */

   r_e_tmp = (*r_e);

   /* Define radius at horizon of isolated BH */

   r_horizon = Mbh/2.0;  /* For Schw. BH in isotropic coordinates !!! */

   /* compute dimensionless radius at horizon */

   h0_h_tmp = r_horizon/r_e_tmp;

   /* compute s at h0_h */

   s0_tmp = h0_h_tmp/(1.0+(h0_h_tmp));

   /* find nearest grid point to horizon */

   n_nearest = 1;
   hunt(s_gp,SDIV,s0_tmp, &n_nearest);
   (*s0) = n_nearest;

   /* Adjust value of r_e so that horizon is on a grid point */

   (*r_e) = r_horizon*(1.0-s_gp[(*s0)])/s_gp[(*s0)];

   /* compute adjusted dimensionless radius at horizon */

   (*h0_h) = r_horizon/(*r_e);

   /* printf out info */


   printf("\n");
   printf("************************************************************************\n");
   printf("**********************   AJS INITIAL GUESS  ****************************\n");
   printf("************************************************************************\n");
   printf("\n");
   printf("Step 1: ADJUST r_e SO THAT BH HORIZON IS ON A GRID POINT\n");
   printf("------------------------------------------------------------------------\n");
   printf("\n");
   printf("Horizon: h0=%6.5e, s0=%6.5e, nearest grid point = %d.  \n",r_horizon, s0_tmp, (*s0));
   printf("Initial outer radius:  r_e=%6.5e\n",r_e_tmp);
   printf("Adjusted outer radius: r_e=%16.15e\n",(*r_e));
   printf("\n");


   /********************************************************************
   / STEP 2: COMPUTE METRIC AND FLUID DISTRIBUTION
    *******************************************************************/

   /* This is for a Scw. BH only !!! */

   /* compute metric, angular velocity and u^t at outer radius */

   gtt_out = - SQ( (1.0-Mbh/(2.0*(*r_e)))/(1.0+Mbh/(2.0*(*r_e))) );
   gtp_out = 0.0;
   gpp_out = pow(1.0+Mbh/(2.0*(*r_e)),4.0)*SQ((*r_e));
   Om_out = - (gtp_out+l0*gtt_out)/(gpp_out+l0*gtp_out);
   ut_out = -1.0/sqrt(-(gpp_out+2.0*l0*gtp_out+SQ(l0)*gtt_out)
                           /(gtt_out*gpp_out-SQ(gtp_out)));

   printf("Step 2: COMPUTE METRIC AND FLUID DISTRIBUTION\n");
   printf("------------------------------------------------------------------------\n");
   printf("\n");
   printf("At r_e:\n");
   printf("g_tt=%6.5e, g_tp=%6.5e, g_pp=%6.5e\n",gtt_out,gtp_out,gpp_out);
   printf("Omega=%6.5e, u_t=%6.5e\n",Om_out,ut_out);
   printf("\n");

   /* definine s_min at half-horizon */

   s_min = (*s0)/2;

   /* main loop */

   for(m=1;m<=MDIV;m++)
      for(s=1;s<=SDIV;s++) {

          r_gp=(*r_e)*s_gp[s]/(1.0-s_gp[s]);
          if(s>=s_min) {
             lambda[s][m] = (1.0-Mbh/(2.0*r_gp))/(1.0+Mbh/(2.0*r_gp));
             Beta[s][m] = (1.0-Mbh/(2.0*r_gp))*(1.0+Mbh/(2.0*r_gp));
             alpha[s][m] = 2.0*log( 1.0+Mbh/(2.0*r_gp));
             omega[s][m] = 0.0; 		/* Scw. only !!! */


             gtt = - SQ(( (1.0-Mbh/(2.0*r_gp))/(1.0+Mbh/(2.0*r_gp)) ));


             gtp = 0.0;                         /* Scw. only !!! */
             gpp = pow(1.0+Mbh/(2.0*r_gp),4.0)*SQ(r_gp)*(1.0-SQ(mu[m]));

             if(s>(*s0)) {
               Omega_diff[s][m] = - (gtp+l0*gtt)/(gpp+l0*gtp);
               ut = -1.0/sqrt(-(gpp+2.0*l0*gtp+SQ(l0)*gtt)
                           /(gtt*gpp-SQ(gtp)));

               H[s][m] = log(ut_out/ut);
               H_raw[s][m] = H[s][m];
             }
             else {
                   H[s][m] = 0.0;
                   H_raw[s][m] = 0.0;
                   Omega_diff[s][m] = 0.0;
                   ut=0.0;
             }

             if(H[s][m] >0.0) {
               density[s][m] = pow( (Gamma_P-1.0)/(eos_K*Gamma_P)
                                 *(exp(H[s][m])-1.0), 1.0/(Gamma_P-1.0));
                                                         /* homentropic only */
               pressure[s][m] = eos_K*pow(density[s][m],Gamma_P);
               energy[s][m] = density[s][m] + pressure[s][m]/(Gamma_P-1);
               velocity_sq[s][m] = SQ( pow(1.0+Mbh/(2.0*r_gp),3.0)
                                       /(1.0 - Mbh/(2.0*r_gp))*r_gp
                                        * Omega_diff[s][m] ) *(1.0-SQ(mu[m]));

                                                          /* Scw. only !!! */
             }else {
                    density[s][m] = 0.0;
                    pressure[s][m] = 0.0;
                    energy[s][m] = 0.0;
                    Omega_diff[s][m] = 0.0;
                    velocity_sq[s][m] = 0.0;
             }
          }
          else {
                lambda[s][m] = 0.0;
                Beta[s][m] = 0.0;
                alpha[s][m] = 0.0;
                omega[s][m] = 0.0;
                density[s][m] = 0.0;
                pressure[s][m] = 0.0;
                energy[s][m] = 0.0;
                Omega_diff[s][m] = 0.0;
                velocity_sq[s][m] = 0.0;
          }

     }


   /********************************************************************
   / STEP 3: FIND INNER RADIUS AND r_ratio
    *******************************************************************/

   /* CREATE Output_torus DIRECTORY IF IT DOES NOT EXIST ALREADY */

   struct stat st = {0};

   if(stat("./Output_torus", &st) == -1) {
     mkdir("./Output_torus", 0777);
   }

   /* construct 1D arrays in equatorial plane */

   AJS_test_file = fopen("Output_torus/AJS_test.dat","w");

   for(s=1;s<=SDIV/2-1;s++) {
       density_mu_0[s] = density[s][1];
       H_mu_0[s] = H[s][1];
       fprintf(AJS_test_file,"%6.5e %6.5e\n", s_gp[s], H_mu_0[s]);
   }

    /* find approximate location of minimum log_enthalpy */

    s_Hmin=SDIV/2-1;

    for(s=SDIV/2-2;s>(*s0);s--) {
      if(H_mu_0[s] < H_mu_0[s+1]) s_Hmin = s;
    }

    printf("Step 3: FIND r_in AND r_ratio=r_in/r_e\n");
    printf("------------------------------------------------------------------------\n");
    printf("\n");
    printf("H_min=%6.5e at r=%6.5e\n", H_mu_0[s_Hmin],
                                   (*r_e)*s_gp[s_Hmin]/(1.0-s_gp[s_Hmin]));
/*
    if(H_mu_0[s_Hmin]>0) {
      printf("No AJS model exists for this configuration\n");
      exit(0);
    }
*/
    /* find approximate location of s_in */
if(H_mu_0[s_Hmin]>0) {
    s_gp_in = s_gp[s_Hmin];
    printf("Warning: No AJS model exists for this configuration\n");
}else{
    s_in=SDIV/2-1;

    for(s=SDIV/2-2;s>(*s0);s--)
      if( (H_mu_0[s] < H_mu_0[s+1]) && H_mu_0[s]>0) s_in = s;

    /* interpolate enthalpy to find precise location of r_in */

    n_nearest = s_in;

    s_gp_in = interp(H_mu_0, s_gp, SDIV/2-1, 0.0, &n_nearest);
}
    printf("s_gp_in=%4.3e\n",s_gp_in);

    r_in = (*r_e)*s_gp_in/(1.0-s_gp_in);

    /* compute r_ratio */

    (*r_ratio) = r_in/(*r_e);

   /* Reset fluid near horizon to zero and keep only torus */

   for(m=1;m<=MDIV;m++)
       for(s=1;s<=SDIV;s++) {
	       if(s_gp[s]<s_gp_in) {
                   density[s][m] = 0.0;
                   energy[s][m] = 0.0;
                   pressure[s][m] = 0.0;
                   Omega_diff[s][m] = 0.0;
                   velocity_sq[s][m] = 0.0;
	       }
	  }

   /* print out info */

   printf("r_in=%6.5e, r_ratio=%6.5e\n",  r_in, (*r_ratio));
   printf("\n");


   /********************************************************************
   / STEP 4: FIND LOCATION OF MAXIMUM DENSITY AND LOG_ENTHALPY
    *******************************************************************/
/*
   AJS_test_file = fopen("Output_torus/AJS_test.dat","w");
*/
   /* compute radial derivate of density */

   for(s=1;s<=SDIV/2-1;s++) {
       d_density_ds_mu_0[s] = deriv_s(density,s,1);
 /*      fprintf(AJS_test_file,"%6.5e %6.5e\n", s_gp[s], d_density_ds_mu_0[s]); */
   }

   /* find approximate location of dens_max */

   s_max_temp=SDIV/2-2;
   while(density_mu_0[s_max_temp]>density_mu_0[s_max_temp+1]) s_max_temp--;

   /* interpolate radial derivative of density = 0 to find s_max */

   n_nearest = s_max_temp;
   s_max = interp(d_density_ds_mu_0, s_gp, SDIV/2-1, 0.0, &n_nearest);
   (*n_nearest_max) = n_nearest;

   /* interpolate density to find dens__max */

   (*dens_max) =  interp(s_gp, density_mu_0, SDIV/2-1, s_max, &n_nearest);

   /* interpolate log_enthalpy to find log_enthalpy_max */

   H_max =  interp(s_gp, H_mu_0, SDIV/2-1, s_max, &n_nearest);


   /* Reset log_enthalpy near horizon to zero and keep only torus */

   for(m=1;m<=MDIV;m++)
       for(s=1;s<=SDIV;s++) {
	       if(s_gp[s]<s_gp_in) {
                   H[s][m] = 0.0;
	       }
	  }

   /* print out info */

   printf("Step 4: FIND r_max, dens_max AND H_max\n");
   printf("------------------------------------------------------------------------\n");
   printf("\n");
   printf("r_max=%6.5e, dens_max=%6.5e, H_max=%6.5e\n", (*r_e)*s_max/(1.0-s_max),(*dens_max),H_max);
   printf("\n");


   /********************************************************************
   / SUMMARY OF AJS INITIAL GUESS
    *******************************************************************/

   printf("SUMMARY OF AJS INITIAL GUESS\n");
   printf("------------------------------------------------------------------------\n");
   printf("\n");
   printf("Set parameters: h0=%6.5e, l=%6.5e, r_e= %6.5e, K=%6.5e, Gamma_P=%6.5e\n", r_horizon,
          l0, (*r_e), eos_K, Gamma_P);
   printf("Derived parameters: r_in=%6.5e, r_max=%6.5e, dens_max=%6.5e\n",
          r_in, (*r_e)*s_max/(1.0-s_max), (*dens_max) );
   printf("r_in/r_e=%6.5e, r_in/r_max=%6.5e, r_in/h0=%6.5e, r_max/h0=%6.5e, r_e/h0=%6.5e\n",
            r_in/(*r_e), r_in/((*r_e)*s_max/(1.0-s_max)), r_in/r_horizon,
            ((*r_e)*s_max/(1.0-s_max))/r_horizon, (*r_e)/r_horizon ) ;
   printf("\n");

   /* print out 1D data  */

   AJS_H_file = fopen("Output_torus/AJS_H.dat","w");
   AJS_dens_file = fopen("Output_torus/AJS_density.dat","w");
   AJS_Omega_file = fopen("Output_torus/AJS_Omega.dat","w");
   AJS_v2_file = fopen("Output_torus/AJS_velocity_sq.dat","w");

   for(s=1;s<=SDIV/2+1;s++) {
      fprintf(AJS_dens_file,"%6.5e %6.5e\n", s_gp[s], density[s][1]);
      fprintf(AJS_H_file,"%6.5e %6.5e\n", s_gp[s], H[s][1]);
      fprintf(AJS_Omega_file,"%6.5e %6.5e\n", s_gp[s], Omega_diff[s][1]);
      fprintf(AJS_v2_file,"%6.5e %6.5e\n", s_gp[s], velocity_sq[s][1]);
    }

  /* FREE MEMORY FOR VECTORS */

  free_dvector(density_mu_0, 1, SDIV/2);
  free_dvector(dens_temp_mu_0, 1, SDIV/2);
  free_dvector(H_mu_0, 1, SDIV/2);
  free_dvector(d_density_ds_mu_0, 1, SDIV/2);
}

/*************************************************************************/
/* Main iteration cycle for torus                                        */
/*************************************************************************/
void iterate_torus(double *s_gp,
                 double *mu,
                 double Gamma_P,
                 double eos_K,
                 double r_ratio,
                 double *dens_max,
                 double *H_max,
                 double accuracy,
                 int    print_dif,
                 double cf,
                 double *r_e_new,
                 double **lambda,
                 double **Beta,
                 double **alpha,
                 double **omega,
                 double **density,
                 double **energy,
                 double **pressure,
                 double **H,
                 double **H_raw,
                 double **velocity_sq,
                 double **Omega_diff,
                 double *h0_h,
                 double l0,
                 double omega_bh,
                 double *Omega_i,
                 double *Omega_e,
                 double *Omega_max,
                 double *s_max,
                 double *s_rmin,
                 int *n_nearest_max,
                 int    s0,
                 int    vac,
                 int    n_it,
                 int RNS_lmax)
{
 int m,                      /* counter */
     s,                      /* counter */
	 s_temp,
	 k_max,
     n,                      /* counter */
     k,                      /* counter */
     n_of_it=0,              /* number of iterations */
     n_nearest,              /* guess for nearest integer in interpolation */
     i,                      /* counter */
     j,                      /* counter */
     s_in,                   /* s at inner radius (last positive density) */
     s_Hmin,                 /* s at Hmin */
     a_check=0;              /* when it reaches 200, iteration diverges */

double dif=1.0,
       **nu_h,
       **gamma_h,
		   **rho_h,
	     r_e,
		   r_e_old,             /* equatorial radius in previus cycle */
		   r_gp,
	     *density_mu_0,
	     *d_density_ds_mu_0,
	     *Omega_mu_0,
		   *omega_mu_0,
	     *v2_mu_0,
	     *nu_mu_0,
		   *gamma_mu_0,
		   p_max,
	     e_max,
		   s0_tmp,
		   lsm,
		   Bsm,
		   omsm,
       esm,
       psm,
       v2sm,
	   	 e_2a,
   		 sum_lambda,
		   sum_Beta,
		   sum_omega,
       **P_2n,
       **P1_2n_1,
	     **Pi1_2n_1,
	     **Pi2_n,
       **D1_lambda,
       **D1_Beta,
       **D1_omega,
       **D2_lambda,
       **D2_Beta,
       **D2_omega,
       **S_lambda,
       **S_Beta,
       **S_omega,
       d_gamma_h_s,            /* derivative of gama w.r.t. s */
       d_gamma_h_m,            /* derivative of gama w.r.t. m */
       d_nu_h_s,              /* derivative of nu w.r.t. s */
       d_nu_h_m,              /* derivative of nu w.r.t. m */
		   d_lambda_s,             /* derivative of rho w.r.t. s */
       d_lambda_m,             /* derivative of rho w.r.t. m */
       d_omega_s,           /* derivative of omega w.r.t. s */
       d_omega_m,           /* derivative of omega w.r.t. m */
       d_alpha_s,
       **fn,
       sk,
       sj,
       sk1,
       sj1,
       sgp0,
       sgp01,
       *sin_theta,
       *theta,
  		 Omega_out,
		   omega_out,
		   v2_out,
		   nu_out,
		   gamma_out,
		   v2_max,
		   nu_max,
  		 m1,
	  	 mum,
		   s1,
  		 s2,
	  	 s_1,
		   sgp,
		   d_gama_ss,
       d_gama_mm,
       d_gama_sm,
       temp1,
       temp2,
       temp3,
       temp4,
       temp5,
       temp6,
       temp7,
       temp8,
       **da_dm,
	     **dgds,
	     **dgdm,
	     d_gama_s,
		   d_rho_s,
		   d_gama_m,
		   d_rho_m,
		   s_gp_in,
		   *S_lambda_m,
		   *S_Beta_m,
		   *S_omega_m,
       *alpha_m,
       H_test,
		   densmax_temp,
	     smax_temp,
	     MbhS,
	     *MC_temp,
	     MC3,
       re2_tmp;

float  ***f_lambda,
       ***f_Beta,
		   ***f_omega,
		   ***f_temp;

FILE *Hraw_tempfile,
     *H_tempfile,
     *e_tempfile,
     *d_tempfile,
     *p_tempfile,
     *v2_tempfile,
     *Om_tempfile,
     *lambda_tempfile,
	   *Beta_tempfile,
	   *omega_tempfile,
	   *alpha_tempfile,
	   *S_lambda_tempfile,
	   *S_Beta_tempfile,
     *S_omega_tempfile,
     *alpha_mu_tempfile,
	   *alpha_pole_tempfile;


/* ALLLOCATE MEMORY FOR VECTORS */

density_mu_0 = dvector(1, SDIV);
d_density_ds_mu_0 = dvector(1, SDIV);
Omega_mu_0 = dvector(1, SDIV);
omega_mu_0 = dvector(1, SDIV);
v2_mu_0 = dvector(1, SDIV);
nu_mu_0 = dvector(1, SDIV);
gamma_mu_0 = dvector(1, SDIV);

S_lambda_m = dvector(1, SDIV);
S_Beta_m = dvector(1, SDIV);
S_omega_m = dvector(1, SDIV);
alpha_m = dvector(1, SDIV);
MC_temp = dvector(1, SDIV);

sin_theta = dvector(1, MDIV);
theta = dvector(1, MDIV);

fn = dmatrix(1,2*RNS_lmax+1,1,SDIV);
f_lambda = f3tensor(1,SDIV,1,RNS_lmax+1,1,SDIV);
f_Beta = f3tensor(1,SDIV,1,RNS_lmax+1,1,SDIV);
f_omega = f3tensor(1,SDIV,1,RNS_lmax+1,1,SDIV);
f_temp = f3tensor(1,SDIV,1,RNS_lmax+1,1,SDIV);


/* INITIALIZE ARRAYS THAT ARE ONLY PARTIALLY SET LATER */

for(s=1;s<=SDIV;s++) {
   density_mu_0[s] = 0.0;
   d_density_ds_mu_0[s] = 0.0;
   Omega_mu_0[s] = 0.0;
   omega_mu_0[s] = 0.0;
   v2_mu_0[s] = 0.0;
   nu_mu_0[s] = 0.0;
   gamma_mu_0[s] = 0.0;
   MC_temp[s] = 0.0;
}


  /* Set r_e to value from previous model */

  r_e = (*r_e_new);

  /* rescale omega_bh */

  omega_bh *= r_e;

    for(n=0;n<=2*RNS_lmax;n++)
       for(i=2;i<=SDIV;i++) fn[n+1][i] = pow((1.0-s_gp[i])/s_gp[i],n);


    if(SMAX==1.0) {

      printf("Not fully implemented, yet.\n");
	  exit(0);

    }
    else{
         sgp0 = s_gp[s0];
         sgp01 = sgp0/(1.0-sgp0);

         for(j=2;j<=SDIV;j++)
            for(n=0;n<=RNS_lmax;n++)
               for(k=2;k<=SDIV;k++) {
                  sk=s_gp[k];
                  sj=s_gp[j];

                  sk1=1.0-sk;
                  sj1=1.0-sj;

                  if(k<=j) {
                    f_lambda[j][n+1][k] =  (1.0/SQ(sk1))*fn[2*n+1][j]*(sj1/sj)*
                                         ( 1.0/fn[2*n+1][k] - pow(sgp01,4*n+1)*
                                           fn[2*n+1][k]*sk1/sk );
                  }else {
                    f_lambda[j][n+1][k] =  (1.0/SQ(sk1))*fn[2*n+1][k]*(sk1/sk)*
                                         ( 1.0/fn[2*n+1][j] - pow(sgp01,4*n+1)*
                                           fn[2*n+1][j]*sj1/sj );
                  }

	       }


         for(j=2;j<=SDIV-1;j++)
            for(n=1;n<=RNS_lmax;n++)
               for(k=2;k<=SDIV-1;k++) {
                  sk=s_gp[k];
                  sj=s_gp[j];

                  sk1=1.0-sk;
                  sj1=1.0-sj;

                  if(k<j) {

                    f_Beta[j][n+1][k] =  SQ(sk)/pow(sk1,4.0)*(sj1/sj)*fn[2*n-1+1][j]*
                                          ( 1.0/fn[2*n-1+1][k] - pow(sgp01,2*(2*n-1))*
                                            fn[2*n-1+1][k] );

                  }else {

                         f_Beta[j][n+1][k] =   SQ(sk)/pow(sk1,4.0)*(sj1/sj)*fn[2*n-1+1][k]*
                                              ( 1.0/fn[2*n-1+1][j] - pow(sgp01,2*(2*n-1))*
                                                fn[2*n-1+1][j] );
                  }
	       }


         for(j=2;j<=SDIV;j++)
            for(n=1;n<=RNS_lmax;n++)
               for(k=2;k<=SDIV;k++) {
                  sk=s_gp[k];
                  sj=s_gp[j];

                  sk1=1.0-sk;
                  sj1=1.0-sj;

                  if(k<=j) {
                    f_temp[j][n+1][k] =  (1.0/SQ(sk1))*fn[2*n-1+1][j]*(sj1/sj)*
                                         ( 1.0/fn[2*n-1+1][k] - pow(sgp01,2*(2*n-1)+1)*
                                           fn[2*n-1+1][k]*sk1/sk );
                  }else {
                         f_temp[j][n+1][k] =  (1.0/SQ(sk1))*fn[2*n-1+1][k]*(sk1/sk)*
                                            ( 1.0/fn[2*n-1+1][j] - pow(sgp01,2*(2*n-1)+1)*
                                              fn[2*n-1+1][j]*sj1/sj );
                  }

                  f_omega[j][n+1][k] = pow(sk/sk1,3.0)*(sj1/sj)*f_temp[j][n+1][k];

	       }

        }



  free_dmatrix(fn,1,2*RNS_lmax+1,1,SDIV);
  free_f3tensor(f_temp, 1,SDIV,1,RNS_lmax+1,1,SDIV);



/* Compute Legendre etc. */

   P_2n = dmatrix(1,MDIV,1,RNS_lmax+1);
   P1_2n_1 = dmatrix(1,MDIV,1,RNS_lmax+1);
   Pi1_2n_1 = dmatrix(1,MDIV,1,RNS_lmax+1);
   Pi2_n = dmatrix(1,MDIV,1,RNS_lmax+1);

   n=0;
   for(i=1;i<=MDIV;i++)
       P_2n[i][n+1]=legendre(2*n,mu[i]);

   for(i=1;i<=MDIV;i++)
     for(n=1;n<=RNS_lmax;n++) {
         P_2n[i][n+1]=legendre(2*n,mu[i]);
         P1_2n_1[i][n+1] = plgndr(2*n-1 ,1,mu[i]);
    }

   for(m=1;m<=MDIV;m++) {
       sin_theta[m] = sqrt(1.0-mu[m]*mu[m]);
       theta[m] = asin(sin_theta[m]);
   }

   for(m=1;m<=MDIV-1;m++)
      for(n=1;n<=RNS_lmax;n++) {
          Pi1_2n_1[m][n+1] = sin( (2*n-1)*theta[m])/((2*n-1)*sin_theta[m]);
          Pi2_n[m][n+1] = P1_2n_1[m][n+1]/(2.0*n*(2*n-1)*sin_theta[m]);
      }

   m=MDIV;
   for(n=1;n<=RNS_lmax;n++) {
      Pi1_2n_1[m][n+1] = 1.0;
      Pi2_n[m][n+1] = -0.5;
   }



  /*****************************************************
  * TO BE FIXED: CASE SMAX=1.0 NOT FULLY IMPLEMENTED ????
  * see same place in rns3.1 where it is.
  ******************************************************/

  if(SMAX==1.0) s_temp=SDIV-1;
  else
       s_temp=SDIV;


  /*****************************************************
  * MAIN LOOP
  ******************************************************/



/* for vacuum BH, set matter to zero */

  if(vac==1) {
     for(s=1;s<=SDIV;s++)
        for(m=1;m<=MDIV;m++) {
           H[s][m] = 0.0;
           Omega_diff[s][m] = 0.0;
           velocity_sq[s][m] = 0.0;
           density[s][m] = 0.0;
           pressure[s][m] = 0.0;
           energy[s][m] = 0.0;
        }
  }

/* First, rescale Omega_diff, omega to hat  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

   for(s=s0; s<=SDIV; s++)            /* !!!!!!!!!!!!!!!!!!! */
      for(m=1; m<=MDIV; m++) {
          Omega_diff[s][m] *= r_e;
          omega[s][m] *= r_e;
      }

   /* CREATE Output_torus DIRECTORY IF IT DOES NOT EXIST ALREADY */

   struct stat st = {0};

   if(stat("./Output_torus", &st) == -1) {
     mkdir("./Output_torus", 0777);
   }

    Hraw_tempfile = fopen("Output_torus/Hraw_temp.dat","w");
    H_tempfile = fopen("Output_torus/H_temp.dat","w");
    d_tempfile = fopen("Output_torus/d_temp.dat","w");
    e_tempfile = fopen("Output_torus/e_temp.dat","w");
    p_tempfile = fopen("Output_torus/p_temp.dat","w");
    v2_tempfile = fopen("Output_torus/v2_temp.dat","w");
    Om_tempfile = fopen("Output_torus/Om_temp.dat","w");
    lambda_tempfile = fopen("Output_torus/lambda_temp.dat","w");
    Beta_tempfile = fopen("Output_torus/Beta_temp.dat","w");
    omega_tempfile = fopen("Output_torus/omega_temp.dat","w");
    alpha_tempfile = fopen("Output_torus/alpha_temp.dat","w");
    S_lambda_tempfile = fopen("Output_torus/S_lambda_temp.dat","w");
    S_Beta_tempfile = fopen("Output_torus/S_Beta_temp.dat","w");
    S_omega_tempfile = fopen("Output_torus/S_omega_temp.dat","w");
    alpha_mu_tempfile = fopen("Output_torus/alpha_mu_temp.dat","w");
    alpha_pole_tempfile = fopen("Output_torus/alpha_pole_temp.dat","w");

   for(s=1;s<=SDIV;s++) {
      fprintf(Hraw_tempfile,"%8.7e %8.7e\n",s_gp[s],H_raw[s][1]);
   }
   fprintf(Hraw_tempfile," \n");

   for(s=1;s<=SDIV;s++) {
      fprintf(H_tempfile,"%8.7e %8.7e\n",s_gp[s],H[s][1]);
   }
   fprintf(H_tempfile," \n");

   for(s=1;s<=SDIV;s++) {
      fprintf(d_tempfile,"%8.7e %8.7e\n",s_gp[s],density[s][1]);
   }
   fprintf(d_tempfile," \n");

   for(s=1;s<=SDIV;s++) {
      fprintf(e_tempfile,"%8.7e %8.7e\n",s_gp[s],energy[s][1]);
   }
   fprintf(e_tempfile," \n");

   for(s=1;s<=SDIV;s++) {
      fprintf(p_tempfile,"%8.7e %8.7e\n",s_gp[s],pressure[s][1]);
   }
   fprintf(H_tempfile," \n");


for(s=s0;s<=SDIV;s++) {

        fprintf(v2_tempfile,"%8.7e %8.7e\n",s_gp[s],velocity_sq[s][1]);

}
fprintf(v2_tempfile," \n");

for(s=s0;s<=SDIV;s++) {

        fprintf(Om_tempfile,"%8.7e %8.7e\n",s_gp[s],Omega_diff[s][1]/r_e);

}
fprintf(Om_tempfile," \n");

for(s=s0;s<=SDIV;s++) {

        fprintf(lambda_tempfile,"%8.7e %8.7e\n",s_gp[s],lambda[s][1]);

}
fprintf(lambda_tempfile," \n");

for(s=s0;s<=SDIV;s++) {

        fprintf(Beta_tempfile,"%8.7e %8.7e\n",s_gp[s],Beta[s][1]);

}
fprintf(Beta_tempfile," \n");

for(s=s0;s<=SDIV;s++) {

        fprintf(omega_tempfile,"%8.7e %8.7e\n",s_gp[s],omega[s][1]/r_e);

}
fprintf(omega_tempfile," \n");

for(s=s0;s<=SDIV;s++) {

        fprintf(alpha_tempfile,"%8.7e %8.7e\n",s_gp[s],alpha[s][1]);

}
fprintf(alpha_tempfile," \n");

for(m=1;m<=MDIV;m++) {

        fprintf(alpha_mu_tempfile,"%8.7e %8.7e\n",mu[m],alpha[s0][m]);

}
fprintf(alpha_mu_tempfile," \n");

for(s=s0;s<=SDIV;s++) {
        fprintf(alpha_pole_tempfile,"%8.7e %8.7e\n",s_gp[s],alpha[s][MDIV]);
}
fprintf(alpha_pole_tempfile," \n");


/* compute fixed H_max */

        p_max = eos_K*pow((*dens_max), Gamma_P);     /* polytropic EOS ! */
        e_max = (*dens_max) + p_max/(Gamma_P-1);
     (*H_max) = log((e_max+p_max)/(*dens_max));      /* homentropic flow ! */

  while( (vac==1 && n_of_it<n_it) || (vac!=1 && (dif> accuracy || n_of_it<4)) ) {    /* fixed second & to && 1/4/2016 */

        if(print_dif!=0)
           printf("n_of_it=%d, diff=%4.3e, ",n_of_it,dif);

  if(vac!=1) {

 	/* next find approximate location of s_in */

	for(s=SDIV/2-1-8;s>=1;s--) {
		if(energy[s][1] >0.0) s_in = s;
	   	  else
		     break;
        }

  }


 /*****************************************************
  * STEP 1
  ******************************************************/

  /* Construct nu_h, gamma_h (outside horizon only) */

        nu_h = dmatrix(1,SDIV,1,MDIV);
        gamma_h = dmatrix(1,SDIV,1,MDIV);

        /* special treatment at horizon */

        for(m=1; m<=MDIV; m++) {
            nu_h[s0][m] = log(lambda[s0+1][m])/SQ(r_e);
            gamma_h[s0][m] = log(Beta[s0+1][m])/SQ(r_e);
		    }

        for(s=s0+1; s<=SDIV; s++)
           for(m=1; m<=MDIV; m++) {

                  nu_h[s][m] = log(lambda[s][m])/SQ(r_e);
                  gamma_h[s][m] = log(Beta[s][m])/SQ(r_e);
               }


  /*****************************************************
  * STEP 2
  ******************************************************/

  /* Find s_max */

  if(vac!=1) {

        for(s=s0;s<=SDIV;s++) {
            density_mu_0[s] = density[s][1];
            d_density_ds_mu_0[s] = deriv_s(density,s,1);
	          Omega_mu_0[s] = Omega_diff[s][1];
            omega_mu_0[s] = omega[s][1];
	          v2_mu_0[s] = velocity_sq[s][1];
	          nu_mu_0[s] = nu_h[s][1];
            gamma_mu_0[s] = gamma_h[s][1];
        }
              /*
        n_nearest = 3*SDIV/8;
        n_nearest = SDIV/2-10; */
        n_nearest = (*n_nearest_max);
        (*s_max) = interp(d_density_ds_mu_0, s_gp, SDIV, 0.0, &n_nearest);
        (*n_nearest_max)=n_nearest;

        printf("s_max=%4.3e\n",(*s_max));


  /* Find Omega_out, v2_out, nu_out, Omega_max, v2_max, nu_max */

        (*Omega_max) =  interp(s_gp, Omega_mu_0, SDIV, (*s_max), &n_nearest);
        v2_max =  interp(s_gp, v2_mu_0, SDIV, (*s_max), &n_nearest);
        nu_max =  interp(s_gp, nu_mu_0, SDIV, (*s_max), &n_nearest);

                n_nearest = SDIV/2;
		nu_out =  interp(s_gp, nu_mu_0, SDIV, 0.5, &n_nearest);
		gamma_out =  interp(s_gp, gamma_mu_0, SDIV, 0.5, &n_nearest);
		omega_out = interp(s_gp, omega_mu_0, SDIV, 0.5, &n_nearest);

		Omega_out = ( omega_out + (l0/r_e)*(  SQ((1.0-0.5)/0.5)*
			 exp( SQ(r_e)*(4.0*nu_out-
                              2.0*gamma_out) ) - SQ(omega_out) ) ) /
					(1.0-omega_out*(l0/r_e)) ;

		v2_out = SQ(Omega_out-omega_out)*exp(
		        SQ(r_e)*(2.0*gamma_out-4.0*nu_out))*SQ(0.5/(1.0-0.5) );


 printf("v2_out=%4.3e Omega_out=%4.3e v2_max=%4.3e Omega_max=%4.3e\n",v2_out, Omega_out, v2_max, (*Omega_max));

 /*****************************************************
  * STEP 3
  ******************************************************/

        /* Compute new r_e. */

        r_e_old=r_e;

          /*  re2_tmp = ((*H_max) + 0.5*log( ( (1.0-v2_max)*SQ(1.0-(l0/r_e)*Omega_out))/
	                ((1.0-v2_out)*SQ(1.0-(l0/r_e)*(*Omega_max))) ) )/(nu_out-nu_max);
*//*
        re2_tmp = log( ( (1.0-v2_max)*SQ(1.0-(l0/r_e)*Omega_out))/
	                ((1.0-v2_out)*SQ(1.0-(l0/r_e)*(*Omega_max))));
*/
        re2_tmp =  ( (1.0-v2_max)*SQ(1.0-(l0/r_e)*Omega_out))/
	                ((1.0-v2_out)*SQ(1.0-(l0/r_e)*(*Omega_max)));

	    r_e = sqrt( ( (*H_max) + 0.5*log( ( (1.0-v2_max)*SQ(1.0-(l0/r_e)*Omega_out))/
	                ((1.0-v2_out)*SQ(1.0-(l0/r_e)*(*Omega_max))) ) )/(nu_out-nu_max));

      /* UPDATE BLACK HOLE MASS USED ONLY IN ANALYTIC APPROXIMATION SINCE r_e HAS CHANGED */

      MbhS = 2.0*r_e*s_gp[s0]/(1.0-s_gp[s0]);
                                                 /* Only for Schw !!! */

   for(s=s0+1;s<=SDIV/2;s++) {

		MC_temp[s] = 0.5*(*h0_h)*r_e*(Beta[s][1]/lambda[s][1]);

	}

	MC3= extrap3(s_gp,MC_temp,SDIV,s_gp[s0],s0+1);


	  printf("Omega_out=%4.3e re2=%4.3e r_e=%4.3e Mbh=%4.3e, MC3=%4.3e, dens_max = %4.3e\n",Omega_out,re2_tmp, r_e,MbhS, MC3,(*dens_max));

/*
	  MbhS = MC3;
 */
  /*****************************************************
  * STEP 4, 5, 6, 7
  ******************************************************/

  /* Compute new Omega_diff and v^2 */

/*     for(s=s_in-5;s<=SDIV/2+1;s++)*/
       for(s=s0+1;s<=SDIV;s++)
        for(m=1;m<=MDIV-1;m++) {

	    Omega_diff[s][m] = ( omega[s][m]
                                + (l0/r_e)
                                  *(
                                    ( SQ((1.0-s_gp[s])/s_gp[s])/(1.0-SQ(mu[m])) )
                                    *exp( SQ(r_e)*(4.0*nu_h[s][m]-2.0*gamma_h[s][m]) )
                                    - SQ(omega[s][m])
                                   )
                               ) / (1.0-omega[s][m]*(l0/r_e)) ;

	    velocity_sq[s][m] = SQ(Omega_diff[s][m]-omega[s][m])*exp(
		                   SQ(r_e)*(2.0*gamma_h[s][m]-4.0*nu_h[s][m]))
				   *SQ(s_gp[s]/(1.0-s_gp[s]))*(1.0-SQ(mu[m]));
        }


  /* Compute new Omega_max and v2_max */

		for(s=s_in-5;s<=SDIV/2+1;s++) {
	        Omega_mu_0[s] = Omega_diff[s][1];
	        v2_mu_0[s] = velocity_sq[s][1];
        }

        n_nearest = (*n_nearest_max);
        (*Omega_max) =  interp(s_gp, Omega_mu_0, SDIV/2-1, (*s_max), &n_nearest);
        v2_max =  interp(s_gp, v2_mu_0, SDIV/2-1, (*s_max), &n_nearest);
        printf("MAX LORENTZ: %g\n", sqrt(1/(1 - v2_max)));

  /* Compute new H, density, pressure and energy */

           for(s=s0;s<=SDIV;s++)
             for(m=1;m<=MDIV-1;m++) {

                  H_test =   ( (1-v2_max)*SQ(1-(l0/r_e)*Omega_diff[s][m]))/
                      ( (1-velocity_sq[s][m])*SQ(1-(l0/r_e)*(*Omega_max)));

                  if(H_test>0.0) {
		              H_raw[s][m] = (*H_max) + SQ(r_e)*(nu_max - nu_h[s][m]) + 0.5*
			                           log(  ( (1-v2_max)*SQ(1-(l0/r_e)
			                                                      *Omega_diff[s][m]))/
			                           ( (1-velocity_sq[s][m])*SQ(1-(l0/r_e)
			                                                      *(*Omega_max)) ));
                  }else{
                      H_raw[s][m] =0.0;
                  }
             }




           for(s=s_in;s>(s0+s_in)/2;s--)
               if(H_raw[s][1]<H_raw[s+1][1]) s_Hmin=s;

                   printf("h[min-1]= %6.5e h[min] = %6.5e h[min+1] = %6.5e\n",
                           H_raw[s_Hmin-1][1],H_raw[s_Hmin][1],H_raw[s_Hmin+1][1]);

           for(s=s0;s<=SDIV;s++)
             for(m=1;m<=MDIV-1;m++) {

                 if(s>=s_Hmin) {
                   H_test =   ( (1-v2_max)*SQ(1-(l0/r_e)*Omega_diff[s][m]))/
                      ( (1-velocity_sq[s][m])*SQ(1-(l0/r_e)*(*Omega_max)));

                    if(H_test>0.0) {
		              H[s][m] = (*H_max) + SQ(r_e)*(nu_max - nu_h[s][m]) + 0.5*
			                           log(  ( (1-v2_max)*SQ(1-(l0/r_e)
			                                                      *Omega_diff[s][m]))/
			                           ( (1-velocity_sq[s][m])*SQ(1-(l0/r_e)
			                                                      *(*Omega_max)) ));
                    }else{
                      H[s][m] =0.0;
                    }

                   }



                    if(H[s][m]<=0.0 || s>SDIV/2+1)  {
					   H[s][m] = 0.0;
					   Omega_diff[s][m] = 0.0;
					   velocity_sq[s][m] = 0.0;
					   density[s][m] = 0.0;
					   pressure[s][m] = 0.0;
                                           energy[s][m] = 0.0;
	            }
                    else {  /*polytropic EOS only */

                           density[s][m] = pow( ((Gamma_P-1.0)/(eos_K*Gamma_P))
                                  *(exp(H[s][m])-1.0),1.0/(Gamma_P-1.0));

                           pressure[s][m]=eos_K*pow(density[s][m],Gamma_P);

                           energy[s][m]=density[s][m] + pressure[s][m]/(Gamma_P-1.0);

                    }
	       }

           /* Set hydrodynamical variables to zero on axis */

           for(s=1;s<SDIV;s++) {
                m=MDIV;
                H[s][m] = 0.0;
                Omega_diff[s][m] = 0.0;
	        velocity_sq[s][m] = 0.0;
	        density[s][m] = 0.0;
	        pressure[s][m] = 0.0;
                energy[s][m] = 0.0;
           }

           /* Set hydrodynamical variables to zero inside the BH */

           for(s=1;s<s0;s++)
             for(m=1;m<=MDIV;m++) {
                H[s][m] = 0.0;
                Omega_diff[s][m] = 0.0;
	        velocity_sq[s][m] = 0.0;
	        density[s][m] = 0.0;
	        pressure[s][m] = 0.0;
                energy[s][m] = 0.0;
             }


           /* find again approximate location of s_in */

	   for(s=SDIV/2-1-8;s>=1;s--) {
		if(energy[s][1] >0.0) s_in = s;
	   	  else
		     break;
           }

           /* find precise location of r_in with linear interpolation (higher interpolation won't
              work near cusp, as there two places where H turns sign near inner surface */

           if(H_raw[s_in-1][1]<0.0)
             (*s_rmin) = s_gp[s_in] - H_raw[s_in][1]*(s_gp[s_in]-s_gp[s_in-1])/
                                         (H_raw[s_in][1]-H_raw[s_in-1][1]);
           else
               (*s_rmin) =s_gp[s_in];

           /* reset hydro to zero between BH and s_in */
           /*
           for(s=s0;s<=s_in-2;s++)
             for(m=1;m<=MDIV-1;m++) {
                density[s][m] = 0.0;

                pressure[s][m]= 0.0;

                energy[s][m]= 0.0;
             }

       for(s=s0;s<=SDIV;s++) {

            d_density_ds_mu_0[s] = deriv_s(density,s,1);
            density_mu_0[s] = density[s][1];
        }

        n_nearest = (*n_nearest_max);
        smax_temp = interp(d_density_ds_mu_0, s_gp, SDIV, 0.0, &n_nearest);
	densmax_temp =  interp(s_gp, density_mu_0, SDIV/2-1, smax_temp, &n_nearest);
*/
	/********* 8/7/10 NEW METHOD: UPDATING smax, densmax etc. during iteration *******/


/*
	(*s_max) = smax_temp;
	(*dens_max) = densmax_temp;
	p_max = eos_K*pow((*dens_max), Gamma_P);
        e_max = (*dens_max) + p_max/(Gamma_P-1);
        (*H_max) = log((e_max+p_max)/(*dens_max));
*/


	/*******************/

}


/* Print diagnostics */

for(s=s0;s<=SDIV;s++) {

		fprintf(H_tempfile,"%8.7e %8.7e\n",s_gp[s],H[s][1]);
}
       fprintf(H_tempfile," \n");

        for(s=s0;s<=SDIV;s++) {

		fprintf(Hraw_tempfile,"%8.7e %8.7e\n",s_gp[s],H_raw[s][1]);
}
       fprintf(Hraw_tempfile," \n");

	   for(s=1;s<=SDIV;s++) {
		fprintf(d_tempfile,"%8.7e %8.7e\n",s_gp[s],density[s][1]);
}
       fprintf(d_tempfile," \n");

	   for(s=1;s<=SDIV;s++) {
		fprintf(e_tempfile,"%8.7e %8.7e\n",s_gp[s],energy[s][1]);
}
       fprintf(e_tempfile," \n");

	   for(s=1;s<=SDIV;s++) {
		fprintf(p_tempfile,"%8.7e %8.7e\n",s_gp[s],pressure[s][1]);
}
       fprintf(p_tempfile," \n");


for(s=s0;s<=SDIV;s++) {
        fprintf(v2_tempfile,"%8.7e %8.7e\n",s_gp[s],velocity_sq[s][1]);
}
fprintf(v2_tempfile," \n");

for(s=s0;s<=SDIV;s++) {
        fprintf(Om_tempfile,"%8.7e %8.7e\n",s_gp[s],Omega_diff[s][1]/r_e);
}
fprintf(Om_tempfile," \n");

for(s=s0;s<=SDIV;s++) {
        fprintf(lambda_tempfile,"%8.7e %8.7e\n",s_gp[s],lambda[s][1]);
}
fprintf(lambda_tempfile," \n");

for(s=s0;s<=SDIV;s++) {
        fprintf(Beta_tempfile,"%8.7e %8.7e\n",s_gp[s],Beta[s][1]);
}
fprintf(Beta_tempfile," \n");

for(s=s0;s<=SDIV;s++) {
        fprintf(omega_tempfile,"%8.7e %8.7e\n",s_gp[s],omega[s][1]/r_e);
}
fprintf(omega_tempfile," \n");

for(s=s0;s<=SDIV;s++) {
        fprintf(alpha_tempfile,"%8.7e %8.7e\n",s_gp[s],alpha[s][1]);
}
fprintf(alpha_tempfile," \n");

for(m=1;m<=MDIV;m++) {
        fprintf(alpha_mu_tempfile,"%8.7e %8.7e\n",mu[m],alpha[s0][m]);
}
fprintf(alpha_mu_tempfile," \n");

for(s=s0;s<=SDIV;s++) {
        fprintf(alpha_pole_tempfile,"%8.7e %8.7e\n",s_gp[s],alpha[s][MDIV]);
}
fprintf(alpha_pole_tempfile," \n");


  /*****************************************************
  * STEP 8
  ******************************************************/

  /* Compute metric potentials */

  S_lambda = dmatrix(1,SDIV,1,MDIV);
  S_Beta = dmatrix(1,SDIV,1,MDIV);
  S_omega = dmatrix(1,SDIV,1,MDIV);

  if(SMAX==1.0) {
    s=SDIV;
    for(m=1;m<=MDIV;m++) {
       S_lambda[s][m] = 0.0;
       S_Beta[s][m]=0.0;
       S_omega[s][m]=0.0;
    }
  }

  /* first compute source for s>=s0+2 */


 for(s=s0+2;s<=s_temp;s++)

    for(m=1;m<=MDIV;m++) {
        lsm=lambda[s][m];
        Bsm=Beta[s][m];
        omsm=omega[s][m];
        esm=energy[s][m];
        psm=pressure[s][m];
        e_2a=exp(2.0*alpha[s][m]);
        v2sm=velocity_sq[s][m];
        mum=mu[m];
        m1=1.0-SQ(mum);
        sgp=s_gp[s];
        s_1=1.0-sgp;
        s1=sgp*s_1;
        s2=SQ(sgp/s_1);

        /* 4th order finite differencing in radial direction
           2nd order in angular direction */

        d_gamma_h_s=deriv_s0_4(gamma_h,s,m,s0);
        d_gamma_h_m=deriv_m(gamma_h,s,m);
        d_nu_h_s=deriv_s0_4(nu_h,s,m,s0);
        d_nu_h_m=deriv_m(nu_h,s,m);
        d_lambda_s=deriv_s0_4(lambda,s,m,s0);
        d_lambda_m=deriv_m(lambda,s,m);
        d_omega_s=deriv_s0_4(omega,s,m,s0);
        d_omega_m=deriv_m(omega,s,m);
        d_alpha_s=deriv_s0_4(alpha,s,m,s0);
/*

        d_gamma_h_s=deriv_s0_4(gamma_h,s,m,s0);
        d_gamma_h_m=deriv_m_4(gamma_h,s,m);
        d_nu_h_s=deriv_s0_4(nu_h,s,m,s0);
        d_nu_h_m=deriv_m_4(nu_h,s,m);
        d_lambda_s=deriv_s0_4(lambda,s,m,s0);
        d_lambda_m=deriv_m_4(lambda,s,m);
        d_omega_s=deriv_s0_4(omega,s,m,s0);
        d_omega_m=deriv_m_4(omega,s,m);
        d_alpha_s=deriv_s0_4(alpha,s,m,s0);
*/
        if(s<=s0+3)   /* or s0+2 */

           /* At first few grid points, use the analytic Schwarzshild value
           for  (d_gamma_h_s-d_nu_h_s)*d_lambda_s in S_lambda !!*/


          S_lambda[s][m] = SQ(r_e*sgp/s_1)*(

              4.0*PI*lsm*e_2a*( (esm+psm)*(1.0+v2sm)/(1.0-v2sm)+2.0*psm)

              +0.5*m1*(SQ(Bsm/r_e)/pow(lsm,3.0))*( SQ(s1*d_omega_s)

              +m1*SQ(d_omega_m) )

               - SQ(s_1)*( SQ(s_1)*(8*SQ(MbhS)/r_e)/
                                    ( sgp*pow(MbhS*(sgp-1)-2*sgp*r_e,3.0))

              -m1/SQ(sgp)*(d_gamma_h_m-d_nu_h_m)*d_lambda_m ) );

        else
            S_lambda[s][m] =   SQ(r_e*sgp/s_1)*(

              4.0*PI*lsm*e_2a*( (esm+psm)*(1.0+v2sm)/(1.0-v2sm)+2.0*psm)

              +0.5*m1*(SQ(Bsm/r_e)/pow(lsm,3.0))*( SQ(s1*d_omega_s)

              +m1*SQ(d_omega_m) )

              - SQ(s_1)*( SQ(s_1)*(d_gamma_h_s-d_nu_h_s)*d_lambda_s

              -m1/SQ(sgp)*(d_gamma_h_m-d_nu_h_m)*d_lambda_m ) );


        S_Beta[s][m] = 16.0*PI*psm*Bsm*e_2a;

        S_omega[s][m] = SQ(s_1)*( SQ(s_1)*(4.0*d_nu_h_s-3.0*d_gamma_h_s)*d_omega_s

                        +(m1/SQ(sgp))*(4.0*d_nu_h_m-3.0*d_gamma_h_m)*d_omega_m )

                        -16.0*PI*e_2a*(esm+psm)*(Omega_diff[s][m]-omsm)/(1.0-v2sm);
        }

 /* Next, interpolate/extrapolate sources to s0 and s0+1 */


    for(m=1;m<=MDIV;m++) {
         for(s=1;s<=SDIV;s++) {
             S_lambda_m[s] = S_lambda[s][m];
             S_Beta_m[s] = S_Beta[s][m];
             S_omega_m[s] = S_omega[s][m];
         }

         sgp=s_gp[s0];
         s_1=1.0-sgp;

         /* take Schwarzschild value for S_lambda on horizon
         S_lambda[s0][m] =

              SQ(r_e*sgp/s_1)*( - SQ(s_1)*( SQ(s_1)*(8*SQ((*Mbh))/r_e)/
                                    ( sgp*pow((*Mbh)*(sgp-1)-2*sgp*r_e,3.0))));
*/
		/* this limiting value comes from u_r = 1/h0 (see Ansorg et al.) */

		S_lambda[s0][m] =  sgp*s_1*deriv_s0_4(lambda,s0,1,s0);

		/*
         S_lambda[s0][m] = -2/SQ((*Mbh)); */

        /* for lambda interpolate */

		S_lambda[s0+1][m] = (3.0/8.0)*S_lambda[s0][m] +(3.0/4.0)*S_lambda[s0+2][m]
                                       -(1.0/8.0)*S_lambda[s0+4][m];

        /* for Beta extrapolate (although it is 0 in vacuum near horizon!!) */

        S_Beta[s0+1][m] = extrap(s_gp,S_Beta_m,SDIV,s_gp[s0+1],s0+2);
        S_Beta[s0][m] = extrap(s_gp,S_Beta_m,SDIV,s_gp[s0],s0+2);

        /* for omega interpolate */

        S_omega[s0][m] = 0.0;
        S_omega[s0+1][m] = (3.0/8.0)*S_omega[s0][m] +(3.0/4.0)*S_omega[s0+2][m]
                                       -(1.0/8.0)*S_omega[s0+4][m];

    }


    /* Print diagnostics for sources */

    for(s=s0;s<=SDIV;s++) {
            fprintf(S_lambda_tempfile,"%8.7e %8.7e\n",s_gp[s],S_lambda[s][1]);
    }
    fprintf(S_lambda_tempfile," \n");

    for(s=s0;s<=SDIV;s++) {
            fprintf(S_Beta_tempfile,"%8.7e %8.7e\n",s_gp[s],S_Beta[s][1]);
    }
    fprintf(S_Beta_tempfile," \n");

    for(s=s0;s<=SDIV;s++) {
            fprintf(S_omega_tempfile,"%8.7e %8.7e\n",s_gp[s],S_omega[s][1]);
    }
    fprintf(S_omega_tempfile," \n");



      /* ANGULAR INTEGRATION */

      D1_lambda = dmatrix(1,RNS_lmax+1,1,SDIV);
      D1_Beta = dmatrix(1,RNS_lmax+1,1,SDIV);
      D1_omega = dmatrix(1,RNS_lmax+1,1,SDIV);

      n=0;
      for(k=s0;k<=SDIV;k++) {
         for(m=1;m<=MDIV-2;m+=2) {
               sum_lambda += (DM/3.0)*(P_2n[m][n+1]*S_lambda[k][m]
                          + 4.0*P_2n[m+1][n+1]*S_lambda[k][m+1]
                          + P_2n[m+2][n+1]*S_lambda[k][m+2]);
	     }

         D1_lambda[n+1][k]=sum_lambda;
         D1_Beta[n+1][k]=0.0;
         D1_omega[n+1][k]=0.0;
         sum_lambda=0.0;
      }

      for(n=1;n<=RNS_lmax;n++)
         for(k=s0;k<=SDIV;k++) {
            for(m=1;m<=MDIV-2;m+=2) {

               sum_lambda += (DM/3.0)*(P_2n[m][n+1]*S_lambda[k][m]
                          + 4.0*P_2n[m+1][n+1]*S_lambda[k][m+1]
                          + P_2n[m+2][n+1]*S_lambda[k][m+2]);

               sum_Beta += (DM/3.0)*(sin((2.0*n-1.0)*theta[m])*S_Beta[k][m]
                           +4.0*sin((2.0*n-1.0)*theta[m+1])*S_Beta[k][m+1]
                           +sin((2.0*n-1.0)*theta[m+2])*S_Beta[k][m+2]);

               sum_omega += (DM/3.0)*(sin_theta[m]*P1_2n_1[m][n+1]*S_omega[k][m]
                            +4.0*sin_theta[m+1]*P1_2n_1[m+1][n+1]*S_omega[k][m+1]
                            +sin_theta[m+2]*P1_2n_1[m+2][n+1]*S_omega[k][m+2]);
	        }

            D1_lambda[n+1][k]=sum_lambda;
            D1_Beta[n+1][k]=sum_Beta;
            D1_omega[n+1][k]=sum_omega;
            sum_lambda=0.0;
            sum_Beta=0.0;
            sum_omega=0.0;
	     }

      free_dmatrix(S_lambda,1,SDIV,1,MDIV);
      free_dmatrix(S_Beta,1,SDIV,1,MDIV);
      free_dmatrix(S_omega,1,SDIV,1,MDIV);


      /* RADIAL INTEGRATION */

     if(fmod(s0,2)==0.0) k_max=SDIV-4;   /* s0 even */
        else k_max=SDIV-2;                /* s0 odd */

      D2_lambda = dmatrix(1,SDIV,1,RNS_lmax+1);
      D2_Beta = dmatrix(1,SDIV,1,RNS_lmax+1);
      D2_omega = dmatrix(1,SDIV,1,RNS_lmax+1);

      n=0;
      for(s=s0;s<=SDIV;s++) {
            for(k=s0;k<=k_max;k+=2) {
               sum_lambda += (DS/3.0)*( f_lambda[s][n+1][k]*D1_lambda[n+1][k]
                          + 4.0*f_lambda[s][n+1][k+1]*D1_lambda[n+1][k+1]
                          + f_lambda[s][n+1][k+2]*D1_lambda[n+1][k+2]);

 	        }

	         D2_lambda[s][n+1]=sum_lambda;
	         D2_Beta[s][n+1]=0.0;
	         D2_omega[s][n+1]=0.0;
             sum_lambda=0.0;
	  }

      for(s=s0;s<=SDIV;s++)
         for(n=1;n<=RNS_lmax;n++) {
            for(k=s0;k<=k_max;k+=2) {

               sum_lambda += (DS/3.0)*( f_lambda[s][n+1][k]*D1_lambda[n+1][k]
                          + 4.0*f_lambda[s][n+1][k+1]*D1_lambda[n+1][k+1]
                          + f_lambda[s][n+1][k+2]*D1_lambda[n+1][k+2]);

               sum_Beta += (DS/3.0)*( f_Beta[s][n+1][k]*D1_Beta[n+1][k]
                           + 4.0*f_Beta[s][n+1][k+1]*D1_Beta[n+1][k+1]
                           + f_Beta[s][n+1][k+2]*D1_Beta[n+1][k+2]);

               sum_omega += (DS/3.0)*( f_omega[s][n+1][k]*D1_omega[n+1][k]
                            + 4.0*f_omega[s][n+1][k+1]*D1_omega[n+1][k+1]
                            + f_omega[s][n+1][k+2]*D1_omega[n+1][k+2]);
            }
	         D2_lambda[s][n+1]=sum_lambda;
	         D2_Beta[s][n+1]=sum_Beta;
	         D2_omega[s][n+1]=sum_omega;
             sum_lambda=0.0;
             sum_Beta=0.0;
             sum_omega=0.0;
	     }

      free_dmatrix(D1_lambda,1,RNS_lmax+1,1,SDIV);
      free_dmatrix(D1_Beta,1,RNS_lmax+1,1,SDIV);
      free_dmatrix(D1_omega,1,RNS_lmax+1,1,SDIV);


      /* SUMMATION OF COEFFICIENTS */

      /* set fields at s0 (not really needed since given by initial conditions...) */

     for(m=1;m<=MDIV;m++) {
         lambda[s0][m] = 0.0;
         Beta[s0][m] = 0.0;
         omega[s0][m] = omega_bh;
     }

     /* update fields for s>=s0+1 */

     for(s=s0+1;s<=SDIV;s++)
         for(m=1;m<=MDIV;m++) {

        lsm=lambda[s][m];
        Bsm=Beta[s][m];
        omsm=omega[s][m];
        temp1=sin_theta[m];

        sum_lambda = (1.0 - (s_gp[s0]*(1.0-s_gp[s]))/(s_gp[s]*(1.0-s_gp[s0]))
                                     - P_2n[m][0+1]*D2_lambda[s][0+1]);

        sum_Beta = 1.0 - SQ((s_gp[s0]*(1.0-s_gp[s]))/(s_gp[s]*(1.0-s_gp[s0])));

        sum_omega = pow((s_gp[s0]*(1.0-s_gp[s]))/(s_gp[s]*(1.0-s_gp[s0])),3.0)*omega_bh;

        for(n=1;n<=RNS_lmax;n++) {
            sum_lambda -= P_2n[m][n+1]*D2_lambda[s][n+1];
            sum_Beta -=  2.0*PI*SQ(r_e)*Pi1_2n_1[m][n+1]*D2_Beta[s][n+1];
            sum_omega -= SQ(r_e)*Pi2_n[m][n+1]*D2_omega[s][n+1];
        }

        Beta[s][m]=Bsm + cf*(sum_Beta-Bsm);
        lambda[s][m]=lsm + cf*(sum_lambda-lsm);
        omega[s][m]=omsm + cf*(sum_omega-omsm);
        sum_lambda=0.0;
        sum_Beta=0.0;
        sum_omega=0.0;

      }


      free_dmatrix(D2_lambda,1,SDIV,1,RNS_lmax+1);
      free_dmatrix(D2_Beta,1,SDIV,1,RNS_lmax+1);
      free_dmatrix(D2_omega,1,SDIV,1,RNS_lmax+1);


      /* CHECK FOR DIVERGENCE */

      if(fabs(omega[s0+1][1])>100.0 || fabs(lambda[s0+1][1])>100.0
         || fabs(Beta[s0+1][1])>300.0) {
         a_check=200;
		 printf("a_check=200\n");
   /*      exit(0); */
      }


      /* TREAT INFINITY WHEN SMAX=1.0 */

      if(SMAX==1.0) {
         for(m=1;m<=MDIV;m++) {
            lambda[SDIV][m]=1.0;
            Beta[SDIV][m]=1.0;
            omega[SDIV][m]=0.0;
	     }
      }



 /*****************************************************
  * STEP 9
  ******************************************************/

     /* USE alpha EQUATION IN CST FORM ! */

     /* COMPUTE gamma_hat, rho_hat */

     rho_h = dmatrix(1,SDIV,1,MDIV);

     for(s=s0+1; s<=SDIV; s++)
         for(m=1; m<=MDIV; m++) {

             r_gp = r_e*s_gp[s]/(1.0-s_gp[s]);

             nu_h[s][m] = log(lambda[s][m]);
             gamma_h[s][m] = log(Beta[s][m]);
	     rho_h[s][m] = 2.0*nu_h[s][m] - gamma_h[s][m];
     }

     /* COMPUTE da_dm */

     da_dm = dmatrix(1,SDIV,1,MDIV);
     dgds = dmatrix(1,SDIV,1,MDIV);
     dgdm = dmatrix(1,SDIV,1,MDIV);

     for(s=s0+6;s<=SDIV;s++)
        for(m=1;m<=MDIV;m++) {

          dgds[s][m]=deriv_s0_4(gamma_h,s,m,s0);
          dgdm[s][m]=deriv_m(gamma_h,s,m);
          }

    for(s=s0+6;s<=SDIV;s++)
       for(m=1;m<=MDIV;m++) {

          sgp=s_gp[s];
          s1=sgp*(1.0-sgp);
          mum=mu[m];
          m1=1.0-SQ(mum);

          d_gama_s=dgds[s][m];

          d_rho_s=deriv_s0_4(rho_h,s,m,s0);
          d_omega_s=deriv_s0_4(omega,s,m,s0);

          d_gama_ss=s1*deriv_ss0(gamma_h,s,m,s0)+(1.0-2.0*sgp)
                                       *d_gama_s;

          d_rho_m=deriv_m(rho_h,s,m);
          d_gama_m=dgdm[s][m];
          d_omega_m=deriv_m(omega,s,m);
          d_gama_mm=m1*deriv_m(dgdm,s,m)-2.0*mum*d_gama_m;
          d_gama_sm=deriv_sm(gamma_h,s,m);


          d_rho_m=0.0;
          d_gama_m=0.0;
          d_omega_m=0.0;
          d_gama_mm=0.0;
          d_gama_sm=0.0;


          temp1=2.0*SQ(sgp)*(sgp/(1.0-sgp))*m1*d_omega_s*d_omega_m

                *(1.0+s1*d_gama_s) - (SQ(SQ(sgp)*d_omega_s) -

                SQ(sgp*d_omega_m/(1.0-sgp))*m1)*(-mum+m1*d_gama_m);

          temp2=1.0/(m1 *SQ(1.0+s1*d_gama_s) + SQ(-mum+m1*d_gama_m));

          temp3=s1*d_gama_ss + SQ(s1*d_gama_s);

          temp4=d_gama_m*(-mum+m1*d_gama_m);

          temp5=(SQ(s1*(d_rho_s+d_gama_s)) - m1*SQ(d_rho_m+d_gama_m))

                *(-mum+m1*d_gama_m);

          temp6=s1*m1*(0.5*(d_rho_s+d_gama_s)* (d_rho_m+d_gama_m)

                + d_gama_sm + d_gama_s*d_gama_m)*(1.0 + s1*d_gama_s);

          temp7=s1*mum*d_gama_s*(1.0+s1*d_gama_s);

          temp8=m1*exp(-2*rho_h[s][m]);

          da_dm[s][m] = -0.5*(d_rho_m+d_gama_m) - temp2*(0.5*(temp3 -

          d_gama_mm - temp4)*(-mum+m1*d_gama_m) + 0.25*temp5

          - temp6 +temp7 + 0.25*temp8*temp1);
       }

      /* Adam's method */

      for(s=s0+6;s<=SDIV;s++) {
         alpha[s][1]=0.0;
         for(m=1;m<=2;m++)
           alpha[s][m+1]= alpha[s][m] + 0.5*DM*(da_dm[s][m+1]+
                             da_dm[s][m]);
      }

      for(s=s0+6;s<=SDIV;s++) {
         alpha[s][1]=0.0;
         for(m=3;m<=MDIV-1;m++)
            alpha[s][m+1]= alpha[s][m] + (DM/12.0)*(23.0*da_dm[s][m]
                                       -16.0*da_dm[s][m-1]+5.0*da_dm[s][m-2]);
      }


      free_dmatrix(da_dm,1,SDIV,1,MDIV);
      free_dmatrix(dgds,1,SDIV,1,MDIV);
      free_dmatrix(dgdm,1,SDIV,1,MDIV);


      for(s=s0+6;s<=SDIV;s++)
         for(m=1;m<=MDIV;m++) {

             alpha[s][m] += -alpha[s][MDIV]+0.5*(gamma_h[s][MDIV]-rho_h[s][MDIV]);

         }

      for(s=s0+1;s<=s0+5;s++)
         for(m=1;m<=MDIV;m++) {

             alpha[s][m] = 0.5*(gamma_h[s][m]-rho_h[s][m]);
              /* this needs to be revised for KERR BH ?????!!!!!!!!! */

            }


      if(SMAX==1.0) {
         for(m=1;m<=MDIV;m++)
            alpha[SDIV][m] = 0.0;
      }

      /* extrapolate alpha to s0*/


   for(m=1;m<=MDIV;m++) {
         for(s=1;s<=SDIV;s++) {
             alpha_m[s] = alpha[s][1]; /* choose same for all angles! */
         }
         alpha[s0][m] = extrap2(s_gp,alpha_m,SDIV,s_gp[s0],s0+1);
   }


      dif=fabs(r_e_old-r_e)/r_e;
      n_of_it++;



      free_dmatrix(rho_h,1,SDIV,1,MDIV);
      free_dmatrix(nu_h,1,SDIV,1,MDIV);
      free_dmatrix(gamma_h,1,SDIV,1,MDIV);


 }   /* end while */

printf("n_of_it=%d, diff=%4.3e\n",n_of_it,dif);
printf("\n");


	 /* Rescale back Omega_diff and omega */

  /*for(s=1;s<=2*SDIV/3; s++) */            /* THIS WAS THE BUG OLEG FOUND !!!!!!!!!!!!!!!!!!! */
        for(s=1;s<=SDIV; s++)
	   for(m=1; m<=MDIV; m++) {
              Omega_diff[s][m] /= r_e;
              omega[s][m] /= r_e;
             }


     /* Rescale back Omega_c, Omega_max and Omega_e, omega OTHER OMEGAs ????????????????????????

	   compute and output Omega_i, Omega_e, Omega_max etc.   ??????????????????????????????????*/

     (*Omega_e) /= r_e;
     (*Omega_max) /= r_e;



     /* UPDATE r_e_new */

     (*r_e_new) = r_e;

    free_f3tensor(f_lambda, 1,SDIV,1,RNS_lmax+1,1,SDIV);
    free_f3tensor(f_Beta,1,SDIV,1,RNS_lmax+1,1,SDIV);
    free_f3tensor(f_omega,1,SDIV,1,RNS_lmax+1,1,SDIV);
    free_dmatrix(P_2n,   1,MDIV,1,RNS_lmax+1);
    free_dmatrix(P1_2n_1,1,MDIV,1,RNS_lmax+1);
    free_dmatrix(Pi1_2n_1,1,MDIV,1,RNS_lmax+1);
	  free_dmatrix(Pi2_n,1,MDIV,1,RNS_lmax+1);


  /* FREE MEMORY FOR VECTORS */

free_dvector(density_mu_0, 1, SDIV);
free_dvector(d_density_ds_mu_0, 1, SDIV);
free_dvector(Omega_mu_0 , 1, SDIV);
free_dvector(omega_mu_0, 1, SDIV);
free_dvector(v2_mu_0, 1, SDIV);
free_dvector(nu_mu_0, 1, SDIV);
free_dvector(gamma_mu_0, 1, SDIV);
free_dvector(S_lambda_m, 1, SDIV);
free_dvector(S_Beta_m, 1, SDIV);
free_dvector(S_omega_m, 1, SDIV);
//free_dvector(lambda_m, 1, SDIV);
//free_dvector(Beta_m, 1, SDIV);
//free_dvector(omega_m, 1, SDIV);
free_dvector(alpha_m, 1, SDIV);
free_dvector(MC_temp, 1, SDIV);
//free_dvector(H_raw_mu_0, 1, SDIV);

free_dvector(sin_theta, 1, MDIV);
free_dvector(theta, 1, MDIV);


    /*additional */


   /********************************************************************
   / SUMMARY OF MODEL PARAMETERS
    *******************************************************************/

   printf("SUMMARY OF MODEL PARAMETERS\n");
   printf("------------------------------------------------------------------------\n");
   printf("\n");
   printf("Fixed parameters:\n");
   printf("r_e/h0=%6.5e, l=%6.5e, K=%6.5e, Gamma_P=%6.5e\n",
           1.0/(s_gp[s0]/(1.0-s_gp[s0])), l0 , eos_K, Gamma_P);
   printf("\n");
   printf("Derived parameters:\n");
   printf("h0=%6.5e, r_e= %6.5e, r_in=%6.5e, r_max=%6.5e, dens_max=%6.5e\n",
           r_e*s_gp[s0]/(1.0-s_gp[s0]), r_e, r_e*(*s_rmin)/(1.0-(*s_rmin)),
           r_e*(*s_max)/(1.0-(*s_max)), (*dens_max));
   printf("r_in/r_e=%6.5e, r_in/r_max=%6.5e, r_in/h0=%6.5e, r_max/h0=%6.5e\n",
            (*s_rmin)/(1.0-(*s_rmin)), (*s_rmin)/(1.0-(*s_rmin))/((*s_max)/(1.0-(*s_max))),
            (*s_rmin)/(1.0-(*s_rmin))/(s_gp[s0]/(1.0-s_gp[s0])) ,
            (*s_max)/(1.0-(*s_max))/(s_gp[s0]/(1.0-s_gp[s0]))) ;
   printf("s_0=%6.5e, s_in= %6.5e\n", s_gp[s0],(*s_rmin));
   printf("\n");
}

/*C*/
/********************************************************************/
/* Compute various quantities for BH+torus.                         */
/********************************************************************/
void comp_bh_torus(double *s_gp,
                   double *mu,
                   double Gamma_P,
	                 double eos_K,
                   double r_ratio,
                   double *dens_max,
                   double *r_e_new,
                   double **lambda,
                   double **Beta,
                   double **alpha,
                   double **omega,
		               double **density,
                   double **energy,
                   double **pressure,
                   double **H,
                   double **H_raw,
                   double **velocity_sq,
			             double **Omega_diff,
                   double **Wlnmut,
			             double *h0_h,
			             double l0,
			             double omega_bh,
                   double *Omega_i,
			             double *Omega_e,
			             double *Omega_max,
			             double *s_max,
			             int s0,
                   int vac,
                   double *Mbh,
                   double *Mt,
                   double *M0t,
                   double *Ut,
                   double *Jt,
                   double *Tt,
                   double *Ma,
                   double *Ja,
                   double *Mbherr,
                   double *Omega_Kepler,
                   double *l_Kepler,
                   double s_rmin,
                   double *DeltaW,
                   int RNS_lmax)
{
 int s,
     m,
     n_nearest;

 double *D_m,                   /* int. quantity for Mt */
        *D_m_0,                 /* int. quantity for M0t */
        *D_U,                   /* int. quantity for Ut */
        *D_J,                   /* int. quantity for Jt */
        *D_T,                   /* int. quantity for Tt */
        *Ja_temp,
	      *Ja1_temp,
	      *MC_temp,
	      MC,
	      MC3,
	      MC4,
       *nu_eq,
       *psi_eq,
       *omega_eq,
        *d_nu_eq_ds,
        *d_psi_eq_ds,
        *d_omega_eq_ds,
        *gtt_eq,
        *gtphi_eq,
        *gphiphi_eq,
        **gtt,
        **gtphi,
        **gphiphi,
        Wtemp,
	    	*Wlnmut_eq,
	     	Win,
	    	Wout;

	FILE *jfile,
	     *j1file,
	     *j2file,
	     *mcfile;



/* ALLLOCATE MEMORY FOR VECTORS */

D_m = dvector(1, SDIV);
D_m_0 = dvector(1, SDIV);
D_U = dvector(1, SDIV);
D_J = dvector(1, SDIV);
D_T = dvector(1, SDIV);
Ja_temp = dvector(1, SDIV);
Ja1_temp = dvector(1, SDIV);
MC_temp = dvector(1, SDIV);
d_nu_eq_ds = dvector(1, SDIV);
d_psi_eq_ds = dvector(1, SDIV);
d_omega_eq_ds = dvector(1, SDIV);
gtt_eq = dvector(1, SDIV);
gtphi_eq = dvector(1, SDIV);
gphiphi_eq = dvector(1, SDIV);
Wlnmut_eq = dvector(1, SDIV);
nu_eq = dvector(1,SDIV);
psi_eq = dvector(1,SDIV);
omega_eq = dvector(1,SDIV);

/* ALLLOCATE MEMORY FOR MATRICES */

gtt = dmatrix(1, SDIV, 1, MDIV);
gtphi = dmatrix(1, SDIV, 1, MDIV);
gphiphi = dmatrix(1, SDIV, 1, MDIV);


  /* Torus mass and rest mass */

   (*Mt) = 0.0;              /* initialize */
   (*M0t) = 0.0;
   (*Ut) = 0.0;
   (*Jt) = 0.0;
   (*Tt) = 0.0;

   for(s=1;s<=SDIV;s++) {
    D_m[s]=0.0;           /* initialize */
    D_m_0[s]=0.0;
    D_U[s]=0.0;
    D_J[s] = 0.0;
    D_T[s] = 0.0;

    for(m=1;m<=MDIV-2;m+=2) {

	 if(density[s][m]>0.0) {

		      D_m[s] += (1.0/(3.0*(MDIV-1)))*( exp(2.0*alpha[s][m])*Beta[s][m]*
              (((energy[s][m]+pressure[s][m])/(1.0-velocity_sq[s][m]))*
              (1.0+velocity_sq[s][m]+(2.0*s_gp[s]*sqrt(velocity_sq[s][m])/
              (1.0-s_gp[s]))*sqrt(1.0-mu[m]*mu[m])*(*r_e_new)*omega[s][m]*
              Beta[s][m]/SQ(lambda[s][m])) + 2.0*pressure[s][m])

            + 4.0*exp(2.0*alpha[s][m+1])*Beta[s][m+1]*
              (((energy[s][m+1]+pressure[s][m+1])/(1.0-velocity_sq[s][m+1]))*
              (1.0+velocity_sq[s][m+1]+(2.0*s_gp[s]*sqrt(velocity_sq[s][m+1])/
              (1.0-s_gp[s]))*sqrt(1.0-mu[m+1]*mu[m+1])*(*r_e_new)*omega[s][m+1]*
              Beta[s][m]/SQ(lambda[s][m+1])) + 2.0*pressure[s][m+1])

            + exp(2.0*alpha[s][m+2])*Beta[s][m+2]*
              (((energy[s][m+2]+pressure[s][m+2])/(1.0-velocity_sq[s][m+2]))*
              (1.0+velocity_sq[s][m+2]+(2.0*s_gp[s]*sqrt(velocity_sq[s][m+2])/
              (1.0-s_gp[s]))*sqrt(1.0-mu[m+2]*mu[m+2])*(*r_e_new)*omega[s][m+2]*
              Beta[s][m]/SQ(lambda[s][m+2])) + 2.0*pressure[s][m+2]));

     D_m_0[s] += (1.0/(3.0*(MDIV-1)))*( (Beta[s][m]/lambda[s][m])*exp(2.0*alpha[s][m])
                                        *density[s][m]/sqrt(1.0-velocity_sq[s][m])

             + 4.0* (Beta[s][m+1]/lambda[s][m+1])*exp(2.0*alpha[s][m+1])
               *density[s][m+1]/sqrt(1.0-velocity_sq[s][m+1])

             + (Beta[s][m+2]/lambda[s][m+2])*exp(2.0*alpha[s][m+2])
               *density[s][m+2]/sqrt(1.0-velocity_sq[s][m+2]));

     D_U[s] += (1.0/(3.0*(MDIV-1)))*( (Beta[s][m]/lambda[s][m])*exp(2.0*alpha[s][m])
                                        *(energy[s][m]-density[s][m])/sqrt(1.0-velocity_sq[s][m])

             + 4.0* (Beta[s][m+1]/lambda[s][m+1])*exp(2.0*alpha[s][m+1])
               *(energy[s][m+1]-density[s][m+1])/sqrt(1.0-velocity_sq[s][m+1])

             + (Beta[s][m+2]/lambda[s][m+2])*exp(2.0*alpha[s][m+2])
               *(energy[s][m+2]-density[s][m+2])/sqrt(1.0-velocity_sq[s][m+2]));


     D_J[s] += (1.0/(3.0*(MDIV-1)))*( sqrt(1.0-mu[m]*mu[m])*
              SQ(exp(alpha[s][m])*Beta[s][m]/lambda[s][m])*(energy[s][m]
              +pressure[s][m])*sqrt(velocity_sq[s][m])/(1.0-velocity_sq[s][m])

              +4.0*sqrt(1.0-mu[m+1]*mu[m+1])*
              SQ(exp(alpha[s][m+1])*Beta[s][m+1]/lambda[s][m+1])*(energy[s][m+1]
              +pressure[s][m+1])*sqrt(velocity_sq[s][m+1])/
              (1.0-velocity_sq[s][m+1])

              + sqrt(1.0-mu[m+2]*mu[m+2])*
              SQ(exp(alpha[s][m+2])*Beta[s][m+2]/lambda[s][m+2])*(energy[s][m+2]
              +pressure[s][m+2])*sqrt(velocity_sq[s][m+2])/
              (1.0-velocity_sq[s][m+2]));


     D_T[s] += (1.0/(3.0*(MDIV-1)))*( sqrt(1.0-mu[m]*mu[m])*
              SQ(exp(alpha[s][m])*Beta[s][m]/lambda[s][m])*(energy[s][m]
              +pressure[s][m])*(*r_e_new)*Omega_diff[s][m]
              *sqrt(velocity_sq[s][m])/(1.0-velocity_sq[s][m])

              +4.0*sqrt(1.0-mu[m+1]*mu[m+1])*
              SQ(exp(alpha[s][m+1])*Beta[s][m+1]/lambda[s][m+1])*(energy[s][m+1]
              +pressure[s][m+1])*(*r_e_new)*Omega_diff[s][m+1]
              *sqrt(velocity_sq[s][m+1])/(1.0-velocity_sq[s][m+1])

              + sqrt(1.0-mu[m+2]*mu[m+2])*
              SQ(exp(alpha[s][m+2])*Beta[s][m+2]/lambda[s][m+2])*(energy[s][m+2]
              +pressure[s][m+2])*(*r_e_new)*Omega_diff[s][m+2]
              *sqrt(velocity_sq[s][m+2])/(1.0-velocity_sq[s][m+2]));
	 }

	}
   }

   if(SMAX==1.0) {       /* copied this from 3.1, check */
        D_m[SDIV]=0.0;
        D_m_0[SDIV]=0.0;
    }

    for(s=1;s<=SDIV-2;s+=2) {
     (*Mt) += (SMAX/(3.0*(SDIV-1)))*(pow(sqrt(s_gp[s])/(1.0-s_gp[s]),4.0)*
          D_m[s]+4.0*pow(sqrt(s_gp[s+1])/(1.0-s_gp[s+1]),4.0)*D_m[s+1]
          +pow(sqrt(s_gp[s+2])/(1.0-s_gp[s+2]),4.0)*D_m[s+2]);

     (*M0t) += (SMAX/(3.0*(SDIV-1)))*(pow(sqrt(s_gp[s])/(1.0-s_gp[s]),4.0)*
          D_m_0[s]+4.0*pow(sqrt(s_gp[s+1])/(1.0-s_gp[s+1]),4.0)*D_m_0[s+1]
          +pow(sqrt(s_gp[s+2])/(1.0-s_gp[s+2]),4.0)*D_m_0[s+2]);

     (*Ut) += (SMAX/(3.0*(SDIV-1)))*(pow(sqrt(s_gp[s])/(1.0-s_gp[s]),4.0)*
          D_U[s]+4.0*pow(sqrt(s_gp[s+1])/(1.0-s_gp[s+1]),4.0)*D_U[s+1]
          +pow(sqrt(s_gp[s+2])/(1.0-s_gp[s+2]),4.0)*D_U[s+2]);


     (*Jt) += (SMAX/(3.0*(SDIV-1)))*((pow(s_gp[s],3.0)/pow(1.0-s_gp[s],5.0))*
          D_J[s]+ 4.0*(pow(s_gp[s+1],3.0)/pow(1.0-s_gp[s+1],5.0))*
          D_J[s+1] + (pow(s_gp[s+2],3.0)/pow(1.0-s_gp[s+2],5.0))*
          D_J[s+2]);

     (*Tt) += (SMAX/(3.0*(SDIV-1)))*((pow(s_gp[s],3.0)/pow(1.0-s_gp[s],5.0))*
          D_T[s]+ 4.0*(pow(s_gp[s+1],3.0)/pow(1.0-s_gp[s+1],5.0))*
          D_T[s+1] + (pow(s_gp[s+2],3.0)/pow(1.0-s_gp[s+2],5.0))*
          D_T[s+2]);

    }



    (*Mt) *= 4*PI*pow((*r_e_new),3.0);
    (*M0t) *= 4*PI*pow((*r_e_new),3.0);
    (*Ut) *= 4*PI*pow((*r_e_new),3.0);


    (*Jt) *= 4*PI*pow((*r_e_new),4.0);
    (*Tt) *= 2.0*PI*pow((*r_e_new),3.0);

    /* ASYMPTOTIC MASS AND ANGULAR MOMENTUM OF SPACETIME */

    (*Ma)=(*r_e_new)*SQ(s_gp[SDIV])*
            (lambda[SDIV-2][1]-4.0*lambda[SDIV-1][1]+3.0*lambda[SDIV][1])/(2.0*DS);


    /* CREATE Output_torus DIRECTORY IF IT DOES NOT EXIST ALREADY */

    struct stat st = {0};

    if(stat("./Output_torus", &st) == -1) {
      mkdir("./Output_torus", 0777);
    }

	jfile = fopen("Output_torus/jfile.dat","w");
	j1file = fopen("Output_torus/j1file.dat","w");
	j2file = fopen("Output_torus/j2file.dat","w");

    for(s=SDIV/2;s<=SDIV-1;s++) {

        Ja_temp[s]= -(1.0/6.0)*pow((*r_e_new),3.0)*pow(s_gp[s],4.0)/SQ(1.0-s_gp[s])*
            (omega[s+1][1]-omega[s-1][1])/(2.0*DS);

        fprintf(jfile,"%d %6.5e\n", s, Ja_temp[s]);

		Ja1_temp[s]= -(1.0/6.0)*pow((*r_e_new),3.0)*pow(s_gp[s],4.0)/SQ(1.0-s_gp[s])*
            (omega[s-2][1]-4.0*omega[s-1][1]+3.0*omega[s][1])/(2.0*DS);

		fprintf(j1file,"%d %6.5e\n", s, Ja1_temp[s]);

		fprintf(j2file,"%d %6.5e\n", s, 0.5*(Ja_temp[s]+Ja1_temp[s]));

    }

	mcfile = fopen("Output_torus/mcfile.dat","w");

	for(s=s0+1;s<=SDIV/2;s++) {

		MC_temp[s] = 0.5*(*h0_h)*(*r_e_new)*(Beta[s][1]/lambda[s][1]);

		fprintf(mcfile,"%d %6.5e\n", s, MC_temp[s]);
	}

	MC= extrap2(s_gp,MC_temp,SDIV,s_gp[s0],s0+1);
	MC3= extrap3(s_gp,MC_temp,SDIV,s_gp[s0],s0+1);
	MC4= extrap(s_gp,MC_temp,SDIV,s_gp[s0],s0+1);


	(*Mbh)=MC3;
	(*Mbherr)= fabs( (MC-MC3)/MC3);

        printf("Black hole mass extrapolation from circumference:\n");
	printf("MC2=%6.5e, MC3=%6.5e, MC4=%6.5e, rel. diff. MC2-MC3=%6.5e\n"
                    ,MC,MC3,MC4, (*Mbherr));
        printf("\n");


    /* Keplerian angular velocity */

    for(s=1;s<=SDIV;s++) {
        if(s>=s0 || s<=SDIV/2+2) {
          nu_eq[s] = log( lambda[s][1] );
          psi_eq[s] = log( Beta[s][1]*(*r_e_new)*s_gp[s]/(lambda[s][1]*(1.0-s_gp[s])) );
          omega_eq[s] = omega[s][1];
        }
        else {
               nu_eq[s] = 0.0;
               psi_eq[s] =  0.0;
               omega_eq[s] =  0.0;
        }
    }

    for(s=1;s<=SDIV;s++) {
        if(s>=s0 || s<=SDIV/2+1) {
          d_nu_eq_ds[s]=deriv_s0_1d(nu_eq,s,s0);
          d_psi_eq_ds[s]=deriv_s0_1d(psi_eq,s,s0);
          d_omega_eq_ds[s]=deriv_s0_1d(omega_eq,s,s0);
          gtt_eq[s] = -exp(2.0*nu_eq[s])+SQ(omega_eq[s]*exp(psi_eq[s]));
          gtphi_eq[s] = -omega_eq[s]*exp(2.0*psi_eq[s]);
          gphiphi_eq[s] = exp(2.0*psi_eq[s]);
          Omega_Kepler[s] = omega[s][1] + d_omega_eq_ds[s]/(2.0*d_psi_eq_ds[s])

                          + sqrt( exp(2.0*(nu_eq[s]-psi_eq[s]))*d_nu_eq_ds[s]/d_psi_eq_ds[s]

                                  +SQ( d_omega_eq_ds[s]/(2.0*d_psi_eq_ds[s])) );

          l_Kepler[s] = -( gtphi_eq[s] + Omega_Kepler[s]*gphiphi_eq[s])/

                       ( gtt_eq[s] + Omega_Kepler[s]*gtphi_eq[s]);
        }
        else{
            d_nu_eq_ds[s]= 0.0;
            d_psi_eq_ds[s]= 0.0;
            d_omega_eq_ds[s]= 0.0;
            Omega_Kepler[s] = 0.0;
            l_Kepler[s] = 0.0;
        }
    }


      for(s=1;s<=SDIV;s++)
         for(m=1;m<=MDIV;m++) {
             gtt[s][m] = -SQ(lambda[s][m])+(1.0-SQ(mu[m]))*SQ(omega[s][m]*
                               Beta[s][m]*(*r_e_new)*s_gp[s]/(lambda[s][m]*(1.0-s_gp[s])));
             gtphi[s][m] = -omega[s][m]*(1.0-SQ(mu[m]))*SQ(
                               Beta[s][m]*(*r_e_new)*s_gp[s]/(lambda[s][m]*(1.0-s_gp[s])));
             gphiphi[s][m] =  (1.0-SQ(mu[m]))*SQ(
                               Beta[s][m]*(*r_e_new)*s_gp[s]/(lambda[s][m]*(1.0-s_gp[s])));

                 Wtemp = -(gphiphi[s][m]+2.0*l0*gtphi[s][m]+SQ(l0)*gtt[s][m])/
                             (gtt[s][m]*gphiphi[s][m]-SQ(gtphi[s][m]));
                 if(Wtemp>0.0)
                   Wlnmut[s][m] = -0.5*log(Wtemp);
                 else
                     Wlnmut[s][m] =0.0;
             }

	/* Compute DeltaW */

	for(s=1;s<=SDIV;s++)
		Wlnmut_eq[s]=Wlnmut[s][1];

	n_nearest = 3*SDIV/8;
    Win= interp( s_gp, Wlnmut_eq, SDIV, s_rmin, &n_nearest);

	n_nearest = SDIV/2;
    Wout= interp( s_gp, Wlnmut_eq,  SDIV, 0.5, &n_nearest);

	(*DeltaW) = Win-Wout;

	/*printf("Win=%6.5e  Wout=%6.5e  DeltaW=%6.5e\n",Win, Wout, Win-Wout); */


/* FREE MEMORY FOR VECTORS */

free_dvector(D_m, 1, SDIV);
free_dvector(D_m_0, 1, SDIV);
free_dvector(D_U, 1, SDIV);
free_dvector(D_J, 1, SDIV);
free_dvector(D_T, 1, SDIV);
free_dvector(Ja_temp, 1, SDIV);
free_dvector(Ja1_temp, 1, SDIV);
free_dvector(MC_temp, 1, SDIV);
free_dvector(d_nu_eq_ds, 1, SDIV);
free_dvector(d_psi_eq_ds, 1, SDIV);
free_dvector(d_omega_eq_ds, 1, SDIV);
free_dvector(gtt_eq, 1, SDIV);
free_dvector(gtphi_eq, 1, SDIV);
free_dvector(gphiphi_eq, 1, SDIV);
free_dvector(nu_eq, 1, SDIV);
free_dvector(psi_eq, 1, SDIV);
free_dvector(omega_eq, 1, SDIV);

/* FREE MEMORY FOR MATRICES */

free_dmatrix(gtt , 1, SDIV, 1, MDIV);
free_dmatrix(gtphi, 1, SDIV, 1, MDIV);
free_dmatrix(gphiphi, 1, SDIV, 1, MDIV);

}


/*************************************************************************
* Print output for model: torus
*************************************************************************/
void print_torus( double n_P,
                  double Gamma_P,
                  double eos_K,
                  double *s_gp,
                  double *mu,
                  int    s0,
                  double r_e,
                  double s_rmin,
                  double s_max,
	                double dens_max,
                  double Mt,
                  double Ma,
                  double Mbh,
                  double M0t,
                  double Ut,
                  double Tt,
                  double Jt,
                  double Ja,
                  double l0,
	                double *Omega_Kepler,
                  double *l_Kepler,
                  double **Wlnmut,
                  double **velocity_sq,
                  double **Omega_diff,
	                double **density,
                  double **pressure,
                  double **lambda,
                  double **Beta,
                  double **alpha,
                  double **omega,
                  double DeltaW)
{
  int i,                                /* counter for x_grid */
	  j,                                /* counter for z_grid */
	  s,			                    /* counter for s_grid */
	  m,                                /* counter for m_grid */
      s_i,                              /* index of s for bilinear interpolation */
      mu_j;                             /* index of mu for bilinear interpolation*/

  double *x_grid,                       /* coordinates of uniform x-grid */
         *z_grid,                       /* coordinates of uniform z-grid */
         bilin_tmp,                     /* temporary value from bilinear interpolation */
         s_tmp,                         /* temporaty value of s */
         mu_tmp;                        /* temporary value of mu */

	FILE  *Omega_Kepler_file,
        *l_Kepler_file,
        *l_Keplerminl0_file,
        *W_eq_file,
        *output_file,
	    *d_file,
	    *v_file,
        *Om_file,
        *lambda_file,
        *Beta_file,
        *omega_file,
        *alpha_file,
	    *density2Dxz_file,
        *W2Dxz_file,
	    *initialdata_file;

   /* Terminal output */

   printf("Derived quantities:\n");
   printf("\n");
   printf("Ratio of torus mass to bh mass:        Mt/Mbh  =  %6.5e\n",Mt/Mbh);
   printf("Asymptotic spacetime mass:             Ma      =  %6.5e\n",Ma);
   printf("Black hole mass:                       Mbh     =  %6.5e\n",Mbh);
   printf("Black hole Komar charge:               MH      =  %6.5e\n",Ma-Mt);
   printf("Torus mass:                            Mt      =  %6.5e\n",Mt);
   printf("Torus rest mass:                       M0t     =  %6.5e\n",M0t);
   printf("Torus internal energy:                 Ut      =  %6.5e\n",Ut);
   printf("Torus rotational energy:               Tt      =  %6.5e\n",Tt);
   printf("Torus gravitational potential energy:  Wt      = %6.5e\n", Ma-Mbh-M0t-Tt-Ut);
   printf("Torus rotational to potential energy:  T/|W|   =  %6.5e\n",Tt/fabs(Ma-Mbh-M0t-Tt-Ut));
   printf("Torus angular momentum:                Jt      =  %6.5e\n",Jt);
   /*      printf("Asymptotic spacetime angular momentum is Ja=%6.5e\n",Ja);*/
   printf("\n");
   printf("Mass differences: MH=%6.5e < M-M0=%6.5e < Mbh=%6.5e\n",Ma-Mt,Ma-M0t,Mbh);
   printf("\n");
   printf("\n");

   printf("RESCALED QUANTITIES:\n");
   printf("\n");
   printf("Fixed parameters:\n");
   printf("\n");
   printf("Ratio of outer torus radius/BH radius: r_e/h0  =  %6.5e\n",1.0/(s_gp[s0]/(1.0-s_gp[s0])));
   printf("Specific angular momentum:             l/Mbh   =  %6.5e\n",l0/Mbh);
   printf("Polytropic constant:              K/Mbh^(2/N)  =  %6.5e\n",eos_K/pow(Mbh,2.0/n_P));
   printf("Polytropic Gamma:                     Gamma_P  =  %6.5e\n",Gamma_P);
   printf("\n");
   printf("Derived parameters:\n");
   printf("\n");
   printf("Horizon radius:                        h0/Mbh  =  %6.5e\n",r_e*s_gp[s0]/(1.0-s_gp[s0])/Mbh);
   printf("Inner torus radius:                  r_in/Mbh  =  %6.5e\n",r_e*s_rmin/(1.0-s_rmin)/Mbh);
   printf("Radius of maximum density:          r_max/Mbh  =  %6.5e\n",r_e*s_max/(1.0-s_max)/Mbh);
   printf("Outer torus radius:                   r_e/Mbh  =  %6.5e\n",r_e/Mbh);
   printf("Maximum density:                dens_max*Mbh^2 =  %6.5e\n",dens_max*SQ(Mbh));
   printf("Torus mass:                            Mt/Mbh  =  %6.5e\n",Mt/Mbh);
   printf("Asymptotic spacetime mass:             Ma/Mbh  =  %6.5e\n",Ma/Mbh);
   printf("Black hole mass:                       Mbh/Mbh =  %6.5e\n",Mbh/Mbh);
   printf("Black hole Komar charge:               MH/Mbh  =  %6.5e\n",(Ma-Mt)/Mbh);
   printf("Torus rest mass:                       M0t/Mbh =  %6.5e\n",M0t/Mbh);
   printf("Torus internal energy:                 Ut/Mbh  =  %6.5e\n",Ut/Mbh);
   printf("Torus rotational energy:               Tt/Mbh  =  %6.5e\n",Tt/Mbh);
   printf("Torus gravitational potential energy:  Wt/Mbh  = %6.5e\n", (Ma-Mbh-M0t-Tt-Ut)/Mbh);
   printf("Torus rotational to potential energy:  T/|W|   =  %6.5e\n",Tt/fabs(Ma-Mbh-M0t-Tt-Ut));
   printf("Torus angular momentum:               Jt/Mbh^2 =  %6.5e\n",Jt/SQ(Mbh));
   /*      printf("Asymptotic spacetime angular momentum is Ja=%6.5e\n",Ja);*/
   printf("\n");
   printf("Additional useful quantities:\n");
   printf("\n");
   printf("Ratio:                               r_in/r_e  =  %6.5e\n",s_rmin/(1.0-s_rmin));
   printf("Ratio:                             r_in/r_max  =  %6.5e\n",s_rmin/(1.0-s_rmin)/(s_max/(1.0-s_max)) );
   printf("Ratio:                               r_in/h_0  =  %6.5e\n",s_rmin/(1.0-s_rmin)/(s_gp[s0]/(1.0-s_gp[s0])) );
   printf("Ratio:                              r_max/h_0  =  %6.5e\n",s_max/(1.0-s_max)/(s_gp[s0]/(1.0-s_gp[s0])));
   printf("Mass differences:\n");
   printf("MH/Mbh=%6.5e < (M-M0)/Mbh=%6.5e < Mbh/Mbh=%6.5e\n",(Ma-Mt)/Mbh,(Ma-M0t)/Mbh,Mbh/Mbh);
   printf("\n");

   printf("Effective potential difference W_in - Wout = %6.5e\n",DeltaW);





   printf("\n");
   printf("Hmax=%6.5e\n",log(1.0+Gamma_P/(Gamma_P-1.0)*eos_K*pow(dens_max,Gamma_P-1.0)) );

}
