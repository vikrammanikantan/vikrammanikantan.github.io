#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"


void horflux_CheckParameters(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  if (Gamma < 0)
  {
      CCTK_ERROR("You have to set 'HorizonFlux::Gamma");
  }

}
