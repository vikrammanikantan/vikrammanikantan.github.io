#!/bin/sh

#/ Usage: make_single_bh.sh charge spin
#/ Prepare a par file for a single BH with given charge and spin
#/ For a RN BH, omit the spin
usage() {
    grep '^#/' "$0" | cut -c4-
    exit 0
}
expr "$*" : ".*--help" > /dev/null && usage

if [ "$#" -lt 1 ]; then
    echo "Illegal number of arugments. Try --help"
    exit 1
fi

if [ -z "$2" ]
then
    par_name="RN"$(echo "$1" | cut -d "." -f 2)".par"
    sed "s/CHARGE/$1/ ; s/SPIN/0/" skeleton_single_BH_hires.par > generated/"$par_name"  && echo "Produced $par_name"
else
    par_name="KN"$(echo "$1" | cut -d "." -f 2)"-"$(echo "$2" | cut -d "." -f 2)".par"
    sed "s/CHARGE/$1/ ; s/SPIN/$2/" skeleton_single_BH_hires.par > generated/"$par_name"  && echo "Produced $par_name"
fi
