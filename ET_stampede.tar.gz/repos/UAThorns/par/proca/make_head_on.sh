#!/bin/sh

#/ Usage: make_head_on.sh distance charge1 charge2 boost1 boost2 spin1 spin2
#/ Prepare a par file for a head on collision
#/ For a RN BH, omit the spin
usage() {
    grep '^#/' "$0" | cut -c4-
    exit 0
}
expr "$*" : ".*--help" > /dev/null && usage

if [ "$#" -lt 3 ]; then
    echo "Illegal number of arugments. Try --help"
    exit 1
fi

distance="$1"
parb=$(echo "scale=1; $distance /2" | bc -l)
charge1="$2"
charge2="$3"

if [ -z "$4" ]; then boost1="0.0"; else boost1="$4"; fi
if [ -z "$5" ]; then boost2="0.0"; else boost2="$5"; fi
if [ -z "$6" ]; then  spin1="0.0"; else  spin1="$6"; fi
if [ -z "$7" ]; then  spin2="0.0"; else  spin2="$7"; fi

name="HO$distance""-""$charge1""-""$charge2""-""$boost1""-""$boost2""-""$spin1""-""$spin2"".par"

sed "s/DISTANCE/$distance/g ;
     s/CHARGE1/$charge1/g ;
     s/CHARGE2/$charge2/g ;
     s/BOOST1/$boost1/g ;
     s/BOOST2/$boost2/g ;
     s/SPIN1/$spin1/g ;
     s/SPIN2/$spin2/g ;" skeleton_head_on.par > generated/"$name"

echo "Produced $name"
