#!/home/u20/gabrielebozzola/.linuxbrew/bin/bash

write_pars() {
    local prefix=$1
    local -n rhos=$2
    local -n rps=$3
    local gamma=$4
    local adiff=$5
    for i in $(seq 0 $((${#rhos[@]}-1))  )
    do
        echo "Model ""$prefix""_$i (Gamma = $gamma, Adiff = $adiff): rp/re = ${rps[$i]}, rho_c = ${rhos[$i]}"
        sed "s/RP/${rps[$i]}/ ; s/RHO/${rhos[$i]}/ ; s/MAMMAGAMMA/$gamma/ ; s/ADIFF/$adiff/" skeleton.par > generated/"$prefix""_""$i"".par"
    done
    echo ""
}

prefix="A"
gamma="2"
adiff="1.50"
RHOS=( 0.300 0.310 0.320 0.325 0.330 )
RPS=( 1.0 1.0 1.0 1.0 1.0 )

write_pars "$prefix" RHOS RPS "$gamma" "$adiff"

prefix="I"
gamma="2.5"
adiff="1.50"
RHOS=( 0.680 0.685 0.690 0.695 0.700 )
RPS=( 1.0 1.0 1.0 1.0 1.0 )

write_pars "$prefix" RHOS RPS "$gamma" "$adiff"

prefix="X"
gamma="3"
adiff="1.50"
RHOS=( 0.90 0.91 0.92 0.93 0.94 )
RPS=( 1.0 1.0 1.0 1.0 1.0 )

write_pars "$prefix" RHOS RPS "$gamma" "$adiff"
