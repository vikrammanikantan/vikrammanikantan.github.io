#include <stdio.h>
#include <stdlib.h>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "DD_utilities.h"
#include "DoubleDonuts.h"

static
void initialize_to_zero(derivs w, int num_tot){
  /* Set to 0 all the elements in v */
  for (int j = 0; j < num_tot; ++j){
    w.d0[j] = 0.0;
    w.d1[j] = 0.0;
    w.d2[j] = 0.0;
    w.d3[j] = 0.0;
    w.d11[j] = 0.0;
    w.d12[j] = 0.0;
    w.d13[j] = 0.0;
    w.d22[j] = 0.0;
    w.d23[j] = 0.0;
    w.d33[j] = 0.0;
  }
}


void DD_InitSetPar(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
  *par_not_found = 0;
}


void DD_SetParNotFound(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  if (!give_bare_mass){
    *par_not_found = 1;
    CCTK_INFO("I will compute the DD parameters!");
  }else{
    *par_not_found = 0;
  }

}

void
DD_find_bare_parameters (CCTK_ARGUMENTS)
{

  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  * mp = par_m_plus;
  * mm = par_m_minus;

  int const nvar = 1, n1 = npoints_A, n2 = npoints_B, n3 = npoints_phi;
  int const ntotal = n1 * n2 * n3 * nvar;
  int const nvar_mom = 3;
  int const ntotal_mom = n1 * n2 * n3 * nvar_mom;
  CCTK_REAL admMass;

    /* If bare masses are not given, iteratively solve for them given the
       target ADM masses target_M_plus and target_M_minus and with initial
       guesses given by par_m_plus and par_m_minus. */
  if(!(give_bare_mass) && *par_not_found){

    CCTK_REAL *FF;
    int i,j,k;
    derivs uF, vF, vmomF;

    FF = dvector (0, ntotal - 1);
    allocate_derivs (&vF, ntotal);
    allocate_derivs (&vmomF, ntotal_mom);
    allocate_derivs (&uF, ntotal);

    initialize_to_zero(vmomF, ntotal_mom);

    CCTK_REAL *Fsources;

    Fsources = calloc(4 * n1 * n2 * n3, sizeof(CCTK_REAL));
    for (i = 0; i < n1; i++)
      for (j = 0; j < n2; j++)
        for (k = 0; k < n3; k++){
          Fsources[Index(0,i,j,k,4,n1,n2,n3)]=0.0;
        }

    CCTK_REAL up, um;

    CCTK_REAL tmp, adm_err, u_0;
    char valbuf[100];

    CCTK_REAL tM  = *donut_black_hole_mass;

    CCTK_REAL q = par_m_plus / par_m_minus;

    CCTK_VInfo (CCTK_THORNSTRING, "Attempting to find bare masses.");
    CCTK_VInfo (CCTK_THORNSTRING, "WARNING: CHECK REFINEMENT LEVEL RADII AND AH CENTERS WITH THE NEW PAR_B.");
    CCTK_VInfo (CCTK_THORNSTRING, "Parameters: par_b %g, par_m_plus %g, par_m_minus %g", par_b, par_m_plus, par_m_minus);
    CCTK_VInfo (CCTK_THORNSTRING, "Target ADM mass: M_ADM=%g", (double) tM);
    CCTK_VInfo (CCTK_THORNSTRING, "ADM mass tolerance: %g", (double) adm_tol);

    /* Loop until both ADM masses are within adm_tol of their target */
      initialize_to_zero(uF, ntotal);
      initialize_to_zero(vF, ntotal);


      /* CCTK_VInfo (CCTK_THORNSTRING, "Bare masses: mp=%.15g, mm=%.15g", (double)*mp, (double)*mm); */
      Newton (cctkGH, nvar, n1, n2, n3, vF, Newton_tol, 1, 1, vmomF, Fsources, *mp, *mm);

      F_of_v (cctkGH, nvar, n1, n2, n3, vF, FF, uF, 1, vmomF, Fsources, *mp, *mm);

      up = PunctIntPolAtArbitPosition(0, nvar, n1, n2, n3, vF, par_b, 0., 0.);
      um = PunctIntPolAtArbitPosition(0, nvar, n1, n2, n3, vF,-par_b, 0., 0.);

      /* Calculate the ADM mass from the current bare mass guess */
      *mp_adm = (1 + up) * *mp + *mp * *mm / (4. * par_b);
      *mm_adm = (1 + um) * *mm + *mp * *mm / (4. * par_b);

      u_0 = PunctEvalAtArbitPosition(vF.d0, 0, 1, 0, 0, nvar, n1, n2, n3);
      admMass = (*mp + *mm - 4*par_b*u_0);
      CCTK_VInfo (CCTK_THORNSTRING, "The total ADM mass is %.15g", (double) admMass);

      /* Check how far the current ADM masses are from the target */
      adm_err = fabs(tM-admMass);
      CCTK_VInfo (CCTK_THORNSTRING, "ADM mass error: %.15g",
                  (double)adm_err);

      /* Invert the ADM mass equation and update the bare mass guess so that
         it gives the correct target ADM masses */
      /* tmp = - (1 + um) + sqrt( (1 + um) * (1 + um) + q / par_b * ((tM + 4 * par_b * u_0)/(q + 1)) ); */
      *mm = *mm / admMass * tM;
      *mp = *mp / admMass * tM;

      /* Set the par_m_plus and par_m_minus parameters */
      /* While setting a new parameter value is immediately reflected in Cactus’ database, */
      /* the value of the parameter is not changed immediately in the routine that sets the */
      /* new value: It is updated only the next time a routine is entered (or rather, when the */
      /* DECLARE CCTK PARAMETERS is encountered the next time). It is therefore advisable to */
      /* set the new parameter value in a routine scheduled at a time earlier to when the new */
      /* value is required. */

      sprintf (valbuf,"%.17g", (double) *mp);
      CCTK_ParameterSet ("par_m_plus", "DoubleDonuts", valbuf);

      sprintf (valbuf,"%.17g", (double) *mm);
      CCTK_ParameterSet ("par_m_minus", "DoubleDonuts", valbuf);

      sprintf (valbuf,"%.17g", (double) par_b * tM / admMass);
      CCTK_ParameterSet ("par_b", "DoubleDonuts", valbuf);

      if ( (adm_err < adm_tol) ) {
        CCTK_VInfo (CCTK_THORNSTRING, "Found bare parameters");
        *par_not_found = 0;
        CCTK_VInfo (CCTK_THORNSTRING, "Starting with par_b=%.15g, par_m_plus=%.15g, par_m_minus=%.15g",
                    (double) par_b, (double) par_m_plus, (double) par_m_minus);
      }

    free_derivs (&vF, ntotal);
    free_derivs (&uF, ntotal);
    free_derivs (&vmomF, ntotal_mom);
    free_dvector (FF, 0, ntotal - 1);
    free(Fsources);
  }

}
