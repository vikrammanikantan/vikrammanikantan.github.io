/* DoubleDonuts:  File  "Equations.c"*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "cctk_Parameters.h"
#include "DD_utilities.h"
#include "DoubleDonuts.h"

/* U.d0[ivar]   = U[ivar];  (ivar = 0..nvar-1) */
/* U.d1[ivar]   = U[ivar]_x;  */
/* U.d2[ivar]   = U[ivar]_y;  */
/* U.d3[ivar]   = U[ivar]_z;  */
/* U.d11[ivar]  = U[ivar]_xx; */
/* U.d12[ivar]  = U[ivar]_xy; */
/* U.d13[ivar]  = U[ivar]_xz;*/
/* U.d22[ivar]  = U[ivar]_yy;*/
/* U.d23[ivar]  = U[ivar]_yz;*/
/* U.d33[ivar]  = U[ivar]_zz;*/

CCTK_REAL
BY_KKofxyz (CCTK_REAL x, CCTK_REAL y, CCTK_REAL z,
            int n1, int n2, int n3, derivs v_mom)
{
  DECLARE_CCTK_PARAMETERS;

  CCTK_REAL A, B, phi;

  /* This routine is used to solve the equations, so we can
   * assume that xyz are on the spectral grid. */

  xyz_To_AB3(x, y, z, n1, n2, n3, &A, &B, &phi);

  int i,j,k;

  i = rint (n1 / Pi * (Pi - acos(A)) - 0.5);
  j = rint (n2 / Pi * (Pi - acos(B)) - 0.5);
  k = rint (n3 * 0.5 * phi / Pi);

  int ii, jj;
  CCTK_REAL r_plus, r2_plus, r3_plus, r_minus, r2_minus, r3_minus, np_Pp, nm_Pm,
    Aij, AijAij, n_plus[3], n_minus[3], np_Sp[3], nm_Sm[3];

  /* /\* There might be some singular behavior around r = 0 *\/ */
  /* /\* What we do here is to avoid r = 0, but keeping the same values *\/ */
  /* /\* of i,j,k *\/ */
  /* CCTK_REAL epsilon_b = TCP_epsilon * par_b; */
  /* if (fabs(y) < epsilon_b && fabs(z) < epsilon_b){ */
  /*   y = y > 0 ? epsilon_b : - epsilon_b; */
  /*   z = z > 0 ? epsilon_b : - epsilon_b; */
  /* } */

  /* /\* We recompute A,B for consistency *\/ */
  /* /\* xyz_To_AB3 takes xyz as input,  *\/ */
  /* xyz_To_AB3(x, y, z, n1, n2, n3, &A, &B, &phi); */

  /* Vij is the in-homogeneous contribution to the extrinsic curvature */
  /* Recall that: Aᵢⱼ = 2∂₍ᵢVⱼ₎ - 2 / 3 ∂ₖ Vᵏ */
  CCTK_REAL Vij[3][3];

  for (ii = 0; ii < 3; ++ii)
    for (jj = 0; jj < 3; ++jj)
      Vij[ii][jj] = 0.;

  if (solve_momentum_constraint){
    /* We need the derivatives of Vⁱ in Cartesian coordinates to
       set up the equations correctly. However, the datatype derivs
       only works in the (A,B,ϕ) space, so we need to perform a
       coordinate transformation like the following:
       ∂ₓ Vⁱ = ∂ A / ∂ x ∂_A Vⁱ + ∂ B / ∂ x ∂_B Vⁱ + ∂ ϕ / ∂ x ∂_ϕ Vⁱ
       To perform this operation we use code already available, in
       fact there is the routine AB3_To_xyz that performs the same
       operation. The function acts on a derivs, so we prepare a
       derivs with the quantity we want to transform. This will be UU.

       There is a minor complication: the code doesn't solve for V,
       but for VAUX defined as V = (A - 1) VAUX, so what is inside
       v_mom is actually VAUX. However, ∂ᵢ VAUX = ∂ᵢ A VAUX + (A - 1) VAUX,
       so we also need ∂ᵢ A. To get it, we follow the same idea: we
       prepare the derivs UUU that has as non-zero entry only A = A
       and ∂ A = 1. We then transform it with AB3_To_xyz which will
       give us ∂ᵢ A.
    */

    CCTK_REAL Vx, Vy, Vz, dx_Vx, dy_Vx, dz_Vx,
      dx_Vy, dy_Vy, dz_Vy, dx_Vz, dy_Vz, dz_Vz, div_V;

    /* There is a factor of A - 1 missing, We will add it later. */
    /* This is VAUX. */
    Vx   = v_mom.d0[Index (0, i, j, k, 3, n1, n2, n3)];
    Vy   = v_mom.d0[Index (1, i, j, k, 3, n1, n2, n3)];
    Vz   = v_mom.d0[Index (2, i, j, k, 3, n1, n2, n3)];

    CCTK_REAL dA_dx, dA_dy, dA_dz;

    CCTK_REAL dA_Vx, dB_Vx, dphi_Vx, dA_Vy, dB_Vy, dphi_Vy, dA_Vz, dB_Vz, dphi_Vz;

    dA_Vx   = v_mom.d1[Index (0, i, j, k, 3, n1, n2, n3)];
    dA_Vy   = v_mom.d1[Index (1, i, j, k, 3, n1, n2, n3)];
    dA_Vz   = v_mom.d1[Index (2, i, j, k, 3, n1, n2, n3)];
    dB_Vx   = v_mom.d2[Index (0, i, j, k, 3, n1, n2, n3)];
    dB_Vy   = v_mom.d2[Index (1, i, j, k, 3, n1, n2, n3)];
    dB_Vz   = v_mom.d2[Index (2, i, j, k, 3, n1, n2, n3)];
    dphi_Vx = v_mom.d3[Index (0, i, j, k, 3, n1, n2, n3)];
    dphi_Vy = v_mom.d3[Index (1, i, j, k, 3, n1, n2, n3)];
    dphi_Vz = v_mom.d3[Index (2, i, j, k, 3, n1, n2, n3)];

    /* Let's prepare a temp derivs with these entries */
    derivs UU;
    allocate_derivs(&UU, 3);

    UU.d0[0] = Vx;
    UU.d0[1] = Vy;
    UU.d0[2] = Vz;
    UU.d1[0] = dA_Vx;
    UU.d1[1] = dA_Vy;
    UU.d1[2] = dA_Vz;
    UU.d2[0] = dB_Vx;
    UU.d2[1] = dB_Vy;
    UU.d2[2] = dB_Vz;
    UU.d3[0] = dphi_Vx;
    UU.d3[1] = dphi_Vy;
    UU.d3[2] = dphi_Vz;

    for (int inde = 0; inde < 3; inde++){
      UU.d11[inde] = 0.;
      UU.d12[inde] = 0.;
      UU.d13[inde] = 0.;
      UU.d22[inde] = 0.;
      UU.d23[inde] = 0.;
      UU.d33[inde] = 0.;
    }

    AB3_To_xyz(3, A, B, phi, n1, n2, n3, UU);

    /* UU is now in xyz, so we can read the quantities we are interested in. */
    dx_Vx = UU.d1[0];
    dx_Vy = UU.d1[1];
    dx_Vz = UU.d1[2];
    dy_Vx = UU.d2[0];
    dy_Vy = UU.d2[1];
    dy_Vz = UU.d2[2];
    dz_Vx = UU.d3[0];
    dz_Vy = UU.d3[1];
    dz_Vz = UU.d3[2];

    free_derivs(&UU, 3);

    /* Now we need the ∂ᵢ A */
    derivs UUU;
    allocate_derivs(&UUU, 1);

    UUU.d0[0]  = A;               /* This is the "A" entry */
    UUU.d1[0]  = 1.;              /* This is the derivative with respect to A */
    UUU.d2[0]  = 0.;              /* All the other entries are zero */
    UUU.d3[0]  = 0.;
    UUU.d11[0] = 0.;
    UUU.d12[0] = 0.;
    UUU.d13[0] = 0.;
    UUU.d22[0] = 0.;
    UUU.d23[0] = 0.;
    UUU.d33[0] = 0.;

    AB3_To_xyz(1, A, B, phi, n1, n2, n3, UUU);

    /* FIXME: The notation is inconsistent, change the name of the derivatives
       of V, or these */
    dA_dx = UUU.d1[0];
    dA_dy = UUU.d2[0];
    dA_dz = UUU.d3[0];

    free_derivs(&UUU, 1);

    /* The actual V is (A-1) of the VAUX computed above. */
    /* The derivative transform like this: */
    dx_Vx = (A - 1.) * dx_Vx + dA_dx * Vx;
    dx_Vy = (A - 1.) * dx_Vy + dA_dx * Vy;
    dx_Vz = (A - 1.) * dx_Vz + dA_dx * Vz;
    dy_Vx = (A - 1.) * dy_Vx + dA_dy * Vx;
    dy_Vy = (A - 1.) * dy_Vy + dA_dy * Vy;
    dy_Vz = (A - 1.) * dy_Vz + dA_dy * Vz;
    dz_Vx = (A - 1.) * dz_Vx + dA_dz * Vx;
    dz_Vy = (A - 1.) * dz_Vy + dA_dz * Vy;
    dz_Vz = (A - 1.) * dz_Vz + dA_dz * Vz;

    /* V = (A - 1) VAUX */
    Vx *= (A - 1.);
    Vy *= (A - 1.);
    Vz *= (A - 1.);

    /* Divergence */
    div_V = dx_Vx + dy_Vy + dz_Vz;

    /* Recall that: Aᵢⱼ = 2∂₍ᵢVⱼ₎ - 2 / 3 ∂ₖ Vᵏ */
    Vij[0][0] = 2. * dx_Vx - 2./3. * div_V;
    Vij[1][1] = 2. * dy_Vy - 2./3. * div_V;
    Vij[2][2] = 2. * dz_Vz - 2./3. * div_V;

    Vij[0][1] = dx_Vy + dy_Vx;
    Vij[0][2] = dx_Vz + dz_Vx;
    Vij[1][0] = dy_Vx + dx_Vy;
    Vij[1][2] = dy_Vz + dz_Vy;
    Vij[2][0] = dz_Vx + dx_Vz;
    Vij[2][1] = dz_Vy + dy_Vz;
  }

  r2_plus  = (x - par_b) * (x - par_b) + y * y + z * z;
  r2_minus = (x + par_b) * (x + par_b) + y * y + z * z;
  r_plus   = sqrt (r2_plus);
  r_minus  = sqrt (r2_minus);

  r2_plus  = sqrt (pow (r2_plus, 2) + pow (DD_epsilon, 4));
  r2_minus = sqrt (pow (r2_minus, 2) + pow (DD_epsilon, 4));

  r3_plus  = r_plus * r2_plus;
  r3_minus = r_minus * r2_minus;

  n_plus [0] = (x - par_b) / r_plus;
  n_minus[0] = (x + par_b) / r_minus;
  n_plus [1] = y / r_plus;
  n_minus[1] = y / r_minus;
  n_plus [2] = z / r_plus;
  n_minus[2] = z / r_minus;

  /* dot product: np_Pp = (n_+).(P_+); nm_Pm = (n_-).(P_-) */
  np_Pp = 0;
  nm_Pm = 0;
  for (ii = 0; ii < 3; ii++)
    {
      np_Pp += n_plus[ii] * par_P_plus[ii];
      nm_Pm += n_minus[ii] * par_P_minus[ii];
    }
  /* cross product: np_Sp[i] = [(n_+) x (S_+)]_i; nm_Sm[i] = [(n_-) x (S_-)]_i*/
  np_Sp[0] = n_plus[1] * par_S_plus[2] - n_plus[2] * par_S_plus[1];
  np_Sp[1] = n_plus[2] * par_S_plus[0] - n_plus[0] * par_S_plus[2];
  np_Sp[2] = n_plus[0] * par_S_plus[1] - n_plus[1] * par_S_plus[0];
  nm_Sm[0] = n_minus[1] * par_S_minus[2] - n_minus[2] * par_S_minus[1];
  nm_Sm[1] = n_minus[2] * par_S_minus[0] - n_minus[0] * par_S_minus[2];
  nm_Sm[2] = n_minus[0] * par_S_minus[1] - n_minus[1] * par_S_minus[0];

  AijAij = 0;

  for (ii = 0; ii < 3; ii++)
    {
      for (jj = 0; jj < 3; jj++)
        {				/* Bowen-York-Curvature + */
          Aij = Vij[ii][jj]             /* Vij = 0 if not solving_momentum_constraint*/
            + 1.5 * (par_P_plus[ii] * n_plus[jj] + par_P_plus[jj] * n_plus[ii]
                     + np_Pp * n_plus[ii] * n_plus[jj]) / r2_plus
            + 1.5 * (par_P_minus[ii] * n_minus[jj] + par_P_minus[jj] * n_minus[ii]
                     + nm_Pm * n_minus[ii] * n_minus[jj]) / r2_minus
            - 3.0 * (np_Sp[ii] * n_plus[jj] + np_Sp[jj] * n_plus[ii]) / r3_plus
            - 3.0 * (nm_Sm[ii] * n_minus[jj] + nm_Sm[jj] * n_minus[ii]) / r3_minus;
          if (ii == jj)
            {
              Aij -= + 1.5 * (np_Pp / r2_plus + nm_Pm / r2_minus);
            }
          AijAij += Aij * Aij;
        }
    }

    return AijAij;
}

void
BY_Aijofxyz (CCTK_REAL x, CCTK_REAL y, CCTK_REAL z, CCTK_REAL Aij[3][3], const CCTK_REAL *mp, const CCTK_REAL *mm,
             int n1, int n2, int n3, derivs v_mom, derivs cf_v_mom, GRID_SETUP_METHOD gsm)
{
  DECLARE_CCTK_PARAMETERS;

  /* This routine follows the previous one. */
  /* This is used when interpolating on the Carpet grid, so we need to evaluate
   * the various quantities. */

  int i,j;                      /* Counters */

  /* This is the contribution due the momentum to the extrinsic curvature.
     It is zeroed so that it the momentum constraint is not solved there
     is no contribution at all. */
  CCTK_REAL Vij[3][3];

  for (i = 0; i < 3; ++i)
    for (j = 0; j < 3; ++j)
      Vij[i][j] = 0.;

  if (solve_momentum_constraint){
    /* Read the comments in the previous routine to understand what is
       going here. The only difference is that here we don't have directly
       the values at (x,y,z) as we had for the collocation points, so we
       interpolate them. This is why we need cf_v_mom, which are the
       spectral coefficients.*/

    CCTK_REAL phi, A, B;

    /* There might be some singular behavior around r = 0 */
    /* What we do here is to avoid r = 0, but keeping the same values */
    /* of i,j,k */
    /* CCTK_REAL epsilon_b = TCP_epsilon * par_b; */
    /* if (fabs(y) < epsilon_b && fabs(z) < epsilon_b){ */
    /*   y = y > 0 ? epsilon_b : - epsilon_b; */
    /*   z = z > 0 ? epsilon_b : - epsilon_b; */
    /* } */

    /* /\* We recompute A,B for consistency *\/ */
    /* /\* xyz_To_AB3 takes xyz as input,  *\/ */
    /* xyz_To_AB3(x, y, z, n1, n2, n3, &A, &B, &phi); */

    CCTK_REAL Vx, Vy, Vz, dx_Vx, dy_Vx, dz_Vx,
      dx_Vy, dy_Vy, dz_Vy, dx_Vz, dy_Vz, dz_Vz, div_V;

    /* There is a factor of A - 1 missing, I'll add it later */
    Vx = PunctEvalAtArbitPositionFast (cf_v_mom.d0, 0, A, B, phi, 3, n1, n2, n3);
    Vy = PunctEvalAtArbitPositionFast (cf_v_mom.d0, 1, A, B, phi, 3, n1, n2, n3);
    Vz = PunctEvalAtArbitPositionFast (cf_v_mom.d0, 2, A, B, phi, 3, n1, n2, n3);

    CCTK_REAL dA_dx, dA_dy, dA_dz;

    CCTK_REAL dA_Vx, dB_Vx, dphi_Vx, dA_Vy, dB_Vy, dphi_Vy, dA_Vz, dB_Vz, dphi_Vz;

    dA_Vx   = PunctEvalAtArbitPositionFast (cf_v_mom.d1, 0, A, B, phi, 3, n1, n2, n3);
    dA_Vy   = PunctEvalAtArbitPositionFast (cf_v_mom.d1, 1, A, B, phi, 3, n1, n2, n3);
    dA_Vz   = PunctEvalAtArbitPositionFast (cf_v_mom.d1, 2, A, B, phi, 3, n1, n2, n3);
    dB_Vx   = PunctEvalAtArbitPositionFast (cf_v_mom.d2, 0, A, B, phi, 3, n1, n2, n3);
    dB_Vy   = PunctEvalAtArbitPositionFast (cf_v_mom.d2, 1, A, B, phi, 3, n1, n2, n3);
    dB_Vz   = PunctEvalAtArbitPositionFast (cf_v_mom.d2, 2, A, B, phi, 3, n1, n2, n3);
    dphi_Vx = PunctEvalAtArbitPositionFast (cf_v_mom.d3, 0, A, B, phi, 3, n1, n2, n3);
    dphi_Vy = PunctEvalAtArbitPositionFast (cf_v_mom.d3, 1, A, B, phi, 3, n1, n2, n3);
    dphi_Vz = PunctEvalAtArbitPositionFast (cf_v_mom.d3, 2, A, B, phi, 3, n1, n2, n3);

    /* Let's prepare a temp derivs with these entries */

    derivs UU;
    allocate_derivs(&UU, 3);

    UU.d0[0] = Vx;
    UU.d0[1] = Vy;
    UU.d0[2] = Vz;
    UU.d1[0] = dA_Vx;
    UU.d1[1] = dA_Vy;
    UU.d1[2] = dA_Vz;
    UU.d2[0] = dB_Vx;
    UU.d2[1] = dB_Vy;
    UU.d2[2] = dB_Vz;
    UU.d3[0] = dphi_Vx;
    UU.d3[1] = dphi_Vy;
    UU.d3[2] = dphi_Vz;

    for (int inde = 0; inde < 3; inde++){
      UU.d11[inde] = 0.;
      UU.d12[inde] = 0.;
      UU.d13[inde] = 0.;
      UU.d22[inde] = 0.;
      UU.d23[inde] = 0.;
      UU.d33[inde] = 0.;
    }

    AB3_To_xyz(3, A, B, phi, n1, n2, n3, UU);

    dx_Vx = UU.d1[0];
    dx_Vy = UU.d1[1];
    dx_Vz = UU.d1[2];
    dy_Vx = UU.d2[0];
    dy_Vy = UU.d2[1];
    dy_Vz = UU.d2[2];
    dz_Vx = UU.d3[0];
    dz_Vy = UU.d3[1];
    dz_Vz = UU.d3[2];

    free_derivs(&UU, 3);

    derivs UUU;
    allocate_derivs(&UUU, 1);

    UUU.d0[0] = A;
    UUU.d1[0] = 1;
    UUU.d2[0] = 0;
    UUU.d3[0] = 0;
    UUU.d11[0] = 0.;
    UUU.d12[0] = 0.;
    UUU.d13[0] = 0.;
    UUU.d22[0] = 0.;
    UUU.d23[0] = 0.;
    UUU.d33[0] = 0.;

    AB3_To_xyz(1, A, B, phi, n1, n2, n3, UUU);

    dA_dx = UUU.d1[0];
    dA_dy = UUU.d2[0];
    dA_dz = UUU.d3[0];

    /* /\* DO I NEED THIS? *\/ */
    /* /\* To eliminate spurious effects due to the coordinate singularity *\/ */
    /* if ((y*y + z*z) < epsilon_b * epsilon_b && fabs(x) > par_b){ */
    /*   dA_dy = 0; */
    /*   dA_dz = 0; */
    /* } */

    free_derivs(&UUU, 1);

    /* The actual V is (A-1) of the V computed above */

    dx_Vx = (A - 1) * dx_Vx + dA_dx * Vx;
    dx_Vy = (A - 1) * dx_Vy + dA_dx * Vy;
    dx_Vz = (A - 1) * dx_Vz + dA_dx * Vz;
    dy_Vx = (A - 1) * dy_Vx + dA_dy * Vx;
    dy_Vy = (A - 1) * dy_Vy + dA_dy * Vy;
    dy_Vz = (A - 1) * dy_Vz + dA_dy * Vz;
    dz_Vx = (A - 1) * dz_Vx + dA_dz * Vx;
    dz_Vy = (A - 1) * dz_Vy + dA_dz * Vy;
    dz_Vz = (A - 1) * dz_Vz + dA_dz * Vz;

    Vx *= (A - 1);
    Vy *= (A - 1);
    Vz *= (A - 1);

    div_V = dx_Vx + dy_Vy + dz_Vz;

    Vij[0][0] = 2. * dx_Vx - 2./3. * div_V;
    Vij[1][1] = 2. * dy_Vy - 2./3. * div_V;
    Vij[2][2] = 2. * dz_Vz - 2./3. * div_V;

    Vij[0][1] = dx_Vy + dy_Vx;
    Vij[0][2] = dx_Vz + dz_Vx;
    Vij[1][0] = dy_Vx + dx_Vy;
    Vij[1][2] = dy_Vz + dz_Vy;
    Vij[2][0] = dz_Vx + dx_Vz;
    Vij[2][1] = dz_Vy + dy_Vz;

  /* for (i = 0; i < 3; i++) */
  /*     for (j = 0; j < 3; j++) */
  /*       if (fabs(x) > 100 || fabs(y) > 100 || fabs(z) > 100) */
  /*         printf("%g %g %g %d %d %g\n", x, y, z, i, j, (x * x + y * y + z * z) * Vij[i][j]); */

  }

  CCTK_REAL r_plus, r2_plus, r3_plus, r_minus, r2_minus, r3_minus, np_Pp, nm_Pm,
    n_plus[3], n_minus[3], np_Sp[3], nm_Sm[3];

  r2_plus = (x - par_b) * (x - par_b) + y * y + z * z;
  r2_minus = (x + par_b) * (x + par_b) + y * y + z * z;
  r2_plus = sqrt (pow (r2_plus, 2) + pow (DD_epsilon, 4));
  r2_minus = sqrt (pow (r2_minus, 2) + pow (DD_epsilon, 4));
  if (r2_plus < pow(DD_Tiny,2))
    r2_plus = pow(DD_Tiny,2);
  if (r2_minus < pow(DD_Tiny,2))
    r2_minus = pow(DD_Tiny,2);
  r_plus = sqrt (r2_plus);
  r_minus = sqrt (r2_minus);
  r3_plus = r_plus * r2_plus;
  r3_minus = r_minus * r2_minus;

  n_plus[0] = (x - par_b) / r_plus;

  n_minus[0] = (x + par_b) / r_minus;
  n_plus[1] = y / r_plus;
  n_minus[1] = y / r_minus;
  n_plus[2] = z / r_plus;
  n_minus[2] = z / r_minus;

  /* dot product: np_Pp = (n_+).(P_+); nm_Pm = (n_-).(P_-) */
  np_Pp = 0;
  nm_Pm = 0;
  for (i = 0; i < 3; i++)
    {
      np_Pp += n_plus[i] * par_P_plus[i];
      nm_Pm += n_minus[i] * par_P_minus[i];
    }
  /* cross product: np_Sp[i] = [(n_+) x (S_+)]_i; nm_Sm[i] = [(n_-) x (S_-)]_i*/
  np_Sp[0] = n_plus[1] * par_S_plus[2] - n_plus[2] * par_S_plus[1];
  np_Sp[1] = n_plus[2] * par_S_plus[0] - n_plus[0] * par_S_plus[2];
  np_Sp[2] = n_plus[0] * par_S_plus[1] - n_plus[1] * par_S_plus[0];
  nm_Sm[0] = n_minus[1] * par_S_minus[2] - n_minus[2] * par_S_minus[1];
  nm_Sm[1] = n_minus[2] * par_S_minus[0] - n_minus[0] * par_S_minus[2];
  nm_Sm[2] = n_minus[0] * par_S_minus[1] - n_minus[1] * par_S_minus[0];
  for (i = 0; i < 3; i++)
    {
      for (j = 0; j < 3; j++)
        {				/* Bowen-York-Curvature :*/
          Aij[i][j] =  Vij[i][j]
            + 1.5 * (par_P_plus[i] * n_plus[j] + par_P_plus[j] * n_plus[i]
                     + np_Pp * n_plus[i] * n_plus[j]) / r2_plus
            + 1.5 * (par_P_minus[i] * n_minus[j] + par_P_minus[j] * n_minus[i]
                     + nm_Pm * n_minus[i] * n_minus[j]) / r2_minus
            - 3.0 * (np_Sp[i] * n_plus[j] + np_Sp[j] * n_plus[i]) / r3_plus
            - 3.0 * (nm_Sm[i] * n_minus[j] + nm_Sm[j] * n_minus[i]) / r3_minus;
          if (i == j){
            Aij[i][j] -= +1.5 * (np_Pp / r2_plus + nm_Pm / r2_minus);
          }
        }
    }
}


/*-----------------------------------------------------------*/
/********           Nonlinear Equations                ***********/
/*-----------------------------------------------------------*/
void
NonLinEquations (CCTK_REAL rho_adm, CCTK_REAL mp, CCTK_REAL mm,
                 CCTK_REAL Sx, CCTK_REAL Sy, CCTK_REAL Sz,
                 int equation_to_solve,
                 CCTK_REAL A, CCTK_REAL B, CCTK_REAL X, CCTK_REAL R,
		 CCTK_REAL x, CCTK_REAL r, CCTK_REAL phi,
		 CCTK_REAL y, CCTK_REAL z, derivs U, CCTK_REAL *values,
                 int n1, int n2, int n3, derivs cf_v_mom)
{
  DECLARE_CCTK_PARAMETERS;

  switch (equation_to_solve){
    /* Case 0: Momentum */
    case 0:
      {
        /* In the case of mom the variables are in 0,1,2 */
        CCTK_REAL d0_div_U = U.d11[0] + U.d12[1] + U.d13[2];
        CCTK_REAL d1_div_U = U.d12[0] + U.d22[1] + U.d23[2];
        CCTK_REAL d2_div_U = U.d13[0] + U.d23[1] + U.d33[2];
        CCTK_REAL lap0_U   = U.d11[0] + U.d22[0] + U.d33[0];
        CCTK_REAL lap1_U   = U.d11[1] + U.d22[1] + U.d33[1];
        CCTK_REAL lap2_U   = U.d11[2] + U.d22[2] + U.d33[2];

        values[0] = lap0_U + 1./3. * d0_div_U - (8 * Pi) * Sx;
        values[1] = lap1_U + 1./3. * d1_div_U - (8 * Pi) * Sy;
        values[2] = lap2_U + 1./3. * d2_div_U - (8 * Pi) * Sz;

        break;
      }
      /* Case 1: Hamiltonian */
    case 1:
      {
        CCTK_REAL r_plus, r_minus, psi, psi2, psi3, psi4, psi7;

        r_plus = sqrt ((x - par_b) * (x - par_b) + y * y + z * z);
        r_minus = sqrt ((x + par_b) * (x + par_b) + y * y + z * z);

        psi =
            1. + 0.5 * mp / r_plus + 0.5 * mm / r_minus + U.d0[0];
        psi2 = psi * psi;
        psi3 = psi2 * psi;
        psi4 = psi2 * psi2;
        psi7 = psi * psi2 * psi4;

        values[0] =
            U.d11[0] + U.d22[0] + U.d33[0] + 0.125 * BY_KKofxyz (x, y, z, n1, n2, n3, cf_v_mom) / psi7 +
            2.0 * Pi * rho_adm / psi3;
        break;
      }
  }
}

/*-----------------------------------------------------------*/
/********               Linear Equations                ***********/
/*-----------------------------------------------------------*/
void
LinEquations (CCTK_REAL rho_adm, CCTK_REAL mp, CCTK_REAL mm,
              CCTK_REAL A, CCTK_REAL B, CCTK_REAL X, CCTK_REAL R,
	      CCTK_REAL x, CCTK_REAL r, CCTK_REAL phi,
	      CCTK_REAL y, CCTK_REAL z, derivs dU, derivs U, CCTK_REAL *values,
              int equation_to_solve,
              int n1, int n2, int n3, derivs cf_v_mom)
{
  DECLARE_CCTK_PARAMETERS;
  switch (equation_to_solve){
    /* Case 0: Momentum */
    case 0:
      {
        /* We assume that we can swap derivatives */

        /* Divergence of Vⁱ: ∂ₖ Vᵏ */
        CCTK_REAL d0_div_U = dU.d11[0] + dU.d12[1] + dU.d13[2];
        CCTK_REAL d1_div_U = dU.d12[0] + dU.d22[1] + dU.d23[2];
        CCTK_REAL d2_div_U = dU.d13[0] + dU.d23[1] + dU.d33[2];

        /* Laplacian of V: ∇² Vⁱ */
        CCTK_REAL lap0_U   = dU.d11[0] + dU.d22[0] + dU.d33[0];
        CCTK_REAL lap1_U   = dU.d11[1] + dU.d22[1] + dU.d33[1];
        CCTK_REAL lap2_U   = dU.d11[2] + dU.d22[2] + dU.d33[2];

        /* (∇²V)ⁱ + 1/3 δⁱʲ ∂ⱼ (∂ₖ Vᵏ) = 0 */
        values[0] = lap0_U + 1./3. * d0_div_U;
        values[1] = lap1_U + 1./3. * d1_div_U;
        values[2] = lap2_U + 1./3. * d2_div_U;
        break;
      }
      /* Case 1: Hamiltonian */
    case 1:
      {
        CCTK_REAL r_plus, r_minus, psi, psi2, psi4, psi8;

        r_plus = sqrt ((x - par_b) * (x - par_b) + y * y + z * z);
        r_minus = sqrt ((x + par_b) * (x + par_b) + y * y + z * z);

        psi =
            1. + 0.5 * mp / r_plus + 0.5 * mm / r_minus + U.d0[0];
        psi2 = psi * psi;
        psi4 = psi2 * psi2;
        psi8 = psi4 * psi4;

        values[0] = dU.d11[0] + dU.d22[0] + dU.d33[0]
                    - 0.875 * BY_KKofxyz (x, y, z, n1, n2, n3, cf_v_mom) / psi8 * dU.d0[0];
                    - 6 * Pi * rho_adm / psi4 * dU.d0[0];
      }
  }
}

/*-----------------------------------------------------------*/
