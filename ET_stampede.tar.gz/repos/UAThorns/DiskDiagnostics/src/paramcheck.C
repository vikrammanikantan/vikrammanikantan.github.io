#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"


void CheckParameters(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  if (Gamma < 0)
  {
      CCTK_ERROR("You have to set 'DiskDiagnostics::Gamma");
  }

  CCTK_INT* christ_comp_every = ((CCTK_INT *) CCTK_ParameterGet("compute_every", "Christoffel", NULL));
  assert(christ_comp_every);

  if (compute_every % *christ_comp_every != 0)
  {
      CCTK_ERROR("compute_every has to be a multiple of Christoffel::compute_every");
  }

  CCTK_INT save_dgab = *((CCTK_INT *) CCTK_ParameterGet("save_dgab", "Christoffel", NULL));

  if (save_dgab == 0)
  {
      CCTK_ERROR("Christoffel::save_dgab has to be set to True");
  }

}
