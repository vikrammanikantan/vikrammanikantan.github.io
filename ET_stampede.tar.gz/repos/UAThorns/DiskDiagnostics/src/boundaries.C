#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"

void DiskDiagnostics_Boundaries(CCTK_ARGUMENTS)
{

    DECLARE_CCTK_ARGUMENTS;
    DECLARE_CCTK_PARAMETERS;

    CCTK_INT ierr;
    CCTK_INT bndsize;

    if (compute_every < 0 || cctk_iteration&compute_every != 0) return;

    CCTK_INT* derivs_order = ((CCTK_INT *) CCTK_ParameterGet("derivs_order", "Christoffel", NULL));
    assert(derivs_order);

    if (*derivs_order == 6)
        bndsize = 5;
    else if (*derivs_order == 4)
        bndsize = 3;
    else if (*derivs_order == 2)
        bndsize = 1;
    else
        CCTK_ERROR("derivs_order not yet implemented.");

    ierr = Boundary_SelectGroupForBC(cctkGH, CCTK_ALL_FACES, bndsize, -1,
                                     "DiskDiagnostics::disk_diagnostics", "flat");
    if (ierr < 0)
        CCTK_ERROR("Failed to register BC for DiskDiagnostics::disk_diagnostics!");

}
