#ifndef __integrate_h
#define __integrate_h
#include "cctk.h"

CCTK_REAL plf_Midpoint2DIntegral(CCTK_REAL const *f, int nx, int ny,
                             CCTK_REAL hx, CCTK_REAL hy);

CCTK_REAL plf_Trapezoidal2DIntegral(CCTK_REAL const *f, int nx, int ny, CCTK_REAL hx, CCTK_REAL hy);

CCTK_REAL plf_Simpson2DIntegral(CCTK_REAL const *f, int nx, int ny,
                            CCTK_REAL hx, CCTK_REAL hy);

CCTK_REAL plf_DriscollHealy2DIntegral(CCTK_REAL const *f, int nx, int ny,
                                  CCTK_REAL hx, CCTK_REAL hy);

#endif
