#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "cctk.h"
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"
#include "interpolate.hh"
#include "integrate.hh"

////////////////////////////////////////////////////////////////////////
// Integration
////////////////////////////////////////////////////////////////////////

void LFlux_Integrate(int array_size, int nthetap,
    CCTK_REAL const array1r[], CCTK_REAL const array1i[],
    CCTK_REAL const array2r[], CCTK_REAL const array2i[],
    CCTK_REAL const th[], CCTK_REAL const ph[],
    CCTK_REAL *outre, CCTK_REAL *outim)
{
  DECLARE_CCTK_PARAMETERS

  int nradii_from_multipole = *((const CCTK_INT*) CCTK_ParameterGet("nradii", "Multipole", NULL));

  if (nradii != nradii_from_multipole)
    CCTK_WARN(0, "nradii in LFlux has to be same as in Multipole!");

  int il = 0;
  int iu = 1;
  CCTK_REAL dth = th[iu] - th[il];
  iu = ntheta + 1;
  CCTK_REAL dph = ph[iu] - ph[il];

  static CCTK_REAL *fr = 0;
  static CCTK_REAL *fi = 0;
  static bool allocated_memory = false;

  // Construct an array for the real integrand
  if (!allocated_memory)
  {
    fr = new CCTK_REAL[array_size];
    fi = new CCTK_REAL[array_size];
    allocated_memory = true;
  }

  // the below calculations take the integral of conj(array1)*array2*sin(th)*sin(th)
  for (int i = 0; i < array_size; i++)
  {
    fr[i] = (array1r[i] * array2r[i] +
             array1i[i] * array2i[i] ) * sin(th[i]) * sin(th[i]);
    fi[i] = (array1r[i] * array2i[i] -
             array1i[i] * array2r[i] ) * sin(th[i]) * sin(th[i]);
  }

  if (CCTK_Equals(integration_method, "midpoint"))
  {
    CCTK_WARN(CCTK_WARN_ABORT, "midpoint is not worth using");
  }
  else if (CCTK_Equals(integration_method, "trapezoidal"))
  {
    *outre = plf_Trapezoidal2DIntegral(fr, ntheta, nphi, dth, dph);
    *outim = plf_Trapezoidal2DIntegral(fi, ntheta, nphi, dth, dph);
  }
  else if (CCTK_Equals(integration_method, "Simpson"))
  {
    if (nphi % 2 != 0 || ntheta % 2 != 0)
    {
      CCTK_WARN (CCTK_WARN_ABORT, "The Simpson integration method requires even ntheta and even nphi");
    }
    *outre = plf_Simpson2DIntegral(fr, ntheta, nphi, dth, dph);
    *outim = plf_Simpson2DIntegral(fi, ntheta, nphi, dth, dph);
  }
  else if (CCTK_Equals(integration_method, "DriscollHealy"))
  {
    if (ntheta % 2 != 0)
    {
      CCTK_WARN (CCTK_WARN_ABORT, "The Driscoll&Healy integration method requires even ntheta");
    }
    *outre = plf_DriscollHealy2DIntegral(fr, ntheta, nphi, dth, dph);
    *outim = plf_DriscollHealy2DIntegral(fi, ntheta, nphi, dth, dph);
  }
  else
  {
    CCTK_WARN(CCTK_WARN_ABORT, "internal error");
  }
}


extern "C" void calc_flux_Lz(CCTK_ARGUMENTS) {

  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  if (out_every == 0 || cctk_iteration % out_every != 0)
    return;

  const int array_size=(ntheta+1)*(nphi+1);

  CCTK_INT real_index1 = CCTK_VarIndex("NPScalars_Proca::phi1re");
  CCTK_INT real_index2 = CCTK_VarIndex("NPScalars_Proca::phi2re");
  CCTK_INT imag_index1 = CCTK_VarIndex("NPScalars_Proca::phi1im");
  CCTK_INT imag_index2 = CCTK_VarIndex("NPScalars_Proca::phi2im");

  for(int i=0; i<nradii; i++) {

    CCTK_REAL real1[array_size];
    CCTK_REAL imag1[array_size];
    CCTK_REAL real2[array_size];
    CCTK_REAL imag2[array_size];
    CCTK_REAL th[array_size];
    CCTK_REAL ph[array_size];
    CCTK_REAL xs[array_size];
    CCTK_REAL ys[array_size];
    CCTK_REAL zs[array_size];

    const double delta_theta = M_PI / ntheta;
    const double delta_phi = 2 * M_PI / nphi;

    for (int it = 0; it <= ntheta; it++)
      for (int ip = 0; ip <= nphi; ip++) {
        const int ind = it + (ntheta+1)*ip;

        th[ind] = it * delta_theta;
        ph[ind] = ip * delta_phi;
        xs[ind] = radius[i] * cos(ph[ind])*sin(th[ind]);
        ys[ind] = radius[i] * sin(ph[ind])*sin(th[ind]);
        zs[ind] = radius[i] * cos(th[ind]);
      }

    // Interpolate Phi1
    LFlux_Interp(CCTK_PASS_CTOC, xs, ys, zs, real_index1, imag_index1, real1, imag1);

    // Interpolate Phi2
    LFlux_Interp(CCTK_PASS_CTOC, xs, ys, zs, real_index2, imag_index2, real2, imag2);

    CCTK_REAL im_int;
    CCTK_REAL re_int;

    LFlux_Integrate(array_size, ntheta,
                    real1, imag1,
                    real2, imag2, th, ph,
                    &re_int, &im_int);

    double r3 = radius[i] * radius[i] * radius[i];
    double pre = 1 / (2 * M_PI) * r3;
    Proca_LFlux_im[i] = pre * im_int;
    Proca_LFlux_re[i] = pre * re_int;
  }
}
