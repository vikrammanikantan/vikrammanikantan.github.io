#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>

#include <math.h>

void IllinoisGRMHD_zero_horizon_mask(CCTK_ARGUMENTS){
    DECLARE_CCTK_ARGUMENTS;
    DECLARE_CCTK_PARAMETERS;

    CCTK_INT zero = 0;

#pragma omp parallel for
        for(int ijk=0; ijk<cctk_ash[0]*cctk_ash[1]*cctk_ash[2]; ijk++)
            horizon_mask[ijk] = zero;
}

void IllinoisGRMHD_compute_horizon_mask(CCTK_ARGUMENTS){
    DECLARE_CCTK_ARGUMENTS
    DECLARE_CCTK_PARAMETERS

    if (!apply_fixes_using_ah) return;

    CCTK_INT zero = 0;
    CCTK_INT one = 1;

    char param_str[30];

    CCTK_REAL origin_x, origin_y, origin_z;

    CCTK_INT *horizon_find_every;
    horizon_find_every = ((CCTK_INT *) CCTK_ParameterGet("find_every", "AHFinderDirect", NULL));

    CCTK_INT *horizon_find_every_individual;

    CCTK_INT find_every;

    CCTK_INT *N_horizons;
    N_horizons = ((CCTK_INT *) CCTK_ParameterGet("N_horizons", "AHFinderDirect", NULL));
    if ((N_horizons == NULL) || (*N_horizons < 0)) *N_horizons = 0;

    /* Check if we have to re compute the mask */
    CCTK_INT recompute = 0;

    for (int horizon = 1; horizon <= *N_horizons; horizon++){

        snprintf(param_str, sizeof(param_str), "find_every_individual[%d]", horizon);

        horizon_find_every_individual = ((CCTK_INT *) CCTK_ParameterGet(param_str, "AHFinderDirect", NULL));

        find_every = *horizon_find_every_individual > 0 ? *horizon_find_every_individual : *horizon_find_every;

        if (cctk_iteration % find_every == 0){
            recompute = 1;
            break;
        }
    }

    if (recompute == 1){

        if(CCTK_Equals(verbose, "essential") || CCTK_Equals(verbose, "essential+iteration output"))
            CCTK_INFO("Updating horizon mask");

#pragma omp parallel for
        for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++)
            horizon_mask[ijk] = zero;

        for (int horizon = 1; horizon <= *N_horizons; horizon++){

            if (HorizonWasFound(horizon)) {
                HorizonLocalCoordinateOrigin(horizon, &origin_x, &origin_y, &origin_z);
                if (HorizonRadiusInDirection(horizon,
                                             cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2],
                                             x, y, z,
                                             radius_h) >= 0) {
                    #pragma omp parallel for
                    for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++) {
                        /* calculate the distance to the origin of the horizon */
                        CCTK_REAL distance = sqrt((x[ijk]-origin_x)*(x[ijk]-origin_x) +
                                                  (y[ijk]-origin_y)*(y[ijk]-origin_y) +
                                                  (z[ijk]-origin_z)*(z[ijk]-origin_z));

                        /* if it is inside the horizon, set the mask accordingly */
                        if (distance <= ah_radius_fix_fraction * radius_h[ijk])
                            horizon_mask[ijk] = one;
                    }
                }
            }
        }
    }
}
