// static void add_cooling(const cGH *cctkGH,const int *cctk_lsh,const int *cctk_nghostzones,    CCTK_REAL **metric,gf_and_gz_struct *in_prims, eos_struct &eos, CCTK_REAL *tau_rhs, CCTK_REAL *st_x_rhs,CCTK_REAL *st_y_rhs,CCTK_REAL *st_z_rhs, CCTK_REAL *x,CCTK_REAL *y,CCTK_REAL *z, CCTK_REAL *lambda) {

static void add_cooling(const cGH *cctkGH, 
                        CCTK_REAL **metric,
                        gf_and_gz_struct *in_prims,
                        eos_struct &eos) {

  DECLARE_CCTK_ARGUMENTS;
  //DECLARE_CCTK_FUNCTIONS;
  DECLARE_CCTK_PARAMETERS;

  CCTK_REAL xL;
  CCTK_REAL yL;
  CCTK_REAL zL;
  CCTK_REAL rL;
  CCTK_REAL tau_c_var;

  /*============================================*/
  //Calculating the separation of the BHs to determine where and how to apply cooling timescale.
  CCTK_REAL xh_centroid;
  CCTK_REAL yh_centroid;
  CCTK_REAL zh_centroid;
  CCTK_REAL xh_local;
  CCTK_REAL yh_local;
  CCTK_REAL zh_local;
  CCTK_REAL r_inn = 15; //2*fmax(rh1, rh2); 
  bool foundflag;

  // finding the position of the first BH horizon
  if (HorizonWasFound(1) && HorizonWasFound(2)){
    CCTK_REAL horizon_number = 1;
    foundflag = HorizonLocalCoordinateOrigin(horizon_number, &xh_local, &yh_local, &zh_local);
    //foundflag = HorizonCentroid(horizon_number, xh_centroid, yh_centroid, zh_centroid);
    CCTK_REAL x_bh1 = xh_local;
    CCTK_REAL y_bh1 = yh_local;
    CCTK_REAL z_bh1 = zh_local;
    CCTK_REAL rh1 = sqrt(x_bh1*x_bh1 + y_bh1*y_bh1 + z_bh1*z_bh1);   

    // finding the position of the second BH horizon
    horizon_number = 2;
    foundflag = HorizonLocalCoordinateOrigin(horizon_number, &xh_local, &yh_local, &zh_local);
    //foundflag = HorizonCentroid(horizon_number, xh_centroid, yh_centroid, zh_centroid);
    CCTK_REAL x_bh2 = xh_local; 
    CCTK_REAL y_bh2 = yh_local;
    CCTK_REAL z_bh2 = zh_local;
    CCTK_REAL rh2 = sqrt(x_bh2*x_bh2 + y_bh2*y_bh2 + z_bh2*z_bh2);

    CCTK_REAL r_inn = 2*fmax(rh1, rh2); 
  }
  /* ============================================*/

  //   Notice in the loop below that we go from 3 to cctk_lsh-2 for i, j, AND k, even though
  //   we are only computing the flux in one direction at a time. This is because in the end,
  //   we only need the rhs's from 3 to cctk_lsh-3 for i, j, and k.
#pragma omp parallel for
  for(int k=cctk_nghostzones[2];k<cctk_lsh[2]-(cctk_nghostzones[2]-1);k++) 
    for(int j=cctk_nghostzones[1];j<cctk_lsh[1]-(cctk_nghostzones[1]-1);j++) 
      for(int i=cctk_nghostzones[0];i<cctk_lsh[0]-(cctk_nghostzones[0]-1);i++) {
        int index = CCTK_GFINDEX3D(cctkGH,i,j,k);

        // Set metric and associated variables
        CCTK_REAL METRIC[NUMVARS_FOR_METRIC_FACEVALS]; for(int ii=0;ii<NUMVARS_FOR_METRIC_FACEVALS;ii++) METRIC[ii] = metric[ii][index];
        CCTK_REAL METRIC_LAP_PSI4[NUMVARS_METRIC_AUX]; SET_LAPSE_PSI4(METRIC_LAP_PSI4,METRIC);

        // retrieve the local coordinates
        xL = x[index];
        yL = y[index];
        zL = z[index];
        rL = sqrt(xL*xL + yL*yL + zL*zL);

        // If we are not in the ghostzones, then add third-order accurate curvature terms to \tilde{S}_i RHS's
        //    Without this if() statement, _rhs variables are in general set to nonzero values in ghostzones, which messes up frozen BC's.
        //    Also, this if() statement should speed up the computation slightly.
        if(k<cctk_lsh[2]-cctk_nghostzones[2] && j<cctk_lsh[1]-cctk_nghostzones[1] && i<cctk_lsh[0]-cctk_nghostzones[0]) {

          CCTK_REAL Psi6 = METRIC_LAP_PSI4[PSI2]*METRIC_LAP_PSI4[PSI4];
          CCTK_REAL half_alpha_sqrtgamma = 0.5*METRIC_LAP_PSI4[LAPSE]*Psi6;


          // The cooling process is considered here, if the cooling timescale (tau_c) is positive
          // alpha is METRIC_LAP_PSI4[LAPSE] 

          CCTK_REAL alpha_sqrtgamma = 2.0*half_alpha_sqrtgamma;

          // The following function calculates eps_th, which is needed for lambda_cooling
          // in_prims[0] is rho_b, that is the rest mass density (which is a grid function and change over time). It is defined in the driver_ecaluate_....C file
    
          // The "vector" U represents the primitive variables: rho, P, vx, vy, vz, Bx, By, and Bz.
          CCTK_REAL U[8]; // 8 primitives in the set: {rho_b,P,vx,vy,vz,Bx,By,Bz}
          for(int ii=0;ii<8;ii++) U[ii] = in_prims[ii].gf[index];
 
          CCTK_REAL P_cold,eps_cold,dPcold_drho,eps_th,h,gamma_cold;
          compute_P_cold__eps_cold__dPcold_drho__eps_th__h__gamma_cold(U,eos,P_cold,eps_cold,dPcold_drho,eps_th,h,gamma_cold);

          // for position greater 
          if (rL > r_inn){
              tau_c_var = 2*M_PI*sqrt(rL*rL*rL);
          } 
          else {
              tau_c_var = 2*M_PI*sqrt(r_inn*r_inn*r_inn);
          }

          CCTK_REAL lambda_cooling = (in_prims[0].gf[index]/tau_c_var)*eps_th; 
          lambda[index] = lambda_cooling;

         // u_0 (up) is calculated below based on the impose_speed_limit_output_u0 function in inlined_functions.C
         // the limit is not imposed here again
         // then u_i are calculated using u_0 and v_i 

         CCTK_REAL uUP[4], uDN[4];
         
         // Derivation of first equation:
         // \gamma_{ij} (v^i + \beta^i)(v^j + \beta^j)/(\alpha)^2
         //   = \gamma_{ij} 1/(u^0)^2 ( \gamma^{ik} u_k \gamma^{jl} u_l /(\alpha)^2 <- Using Eq. 53 of arXiv:astro-ph/0503420
         //   = 1/(u^0 \alpha)^2 u_j u_l \gamma^{jl}  <- Since \gamma_{ij} \gamma^{ik} = \delta^k_j
         //   = 1/(u^0 \alpha)^2 ( (u^0 \alpha)^2 - 1 ) <- Using Eq. 56 of arXiv:astro-ph/0503420
         //   = 1 - 1/(u^0 \alpha)^2 <= 1
         CCTK_REAL psi4 = METRIC_LAP_PSI4[PSI4];
         CCTK_REAL ONE_OVER_LAPSE = METRIC_LAP_PSI4[LAPSEINV];
         CCTK_REAL one_minus_one_over_alpha_u0_squared = psi4*(METRIC[GXX]* SQR(U[VX] + METRIC[SHIFTX]) +
                                                               2.0*METRIC[GXY]*(U[VX] + METRIC[SHIFTX])*(U[VY] + METRIC[SHIFTY]) +
                                                               2.0*METRIC[GXZ]*(U[VX] + METRIC[SHIFTX])*(U[VZ] + METRIC[SHIFTZ]) +
                                                               METRIC[GYY]* SQR(U[VY] + METRIC[SHIFTY]) +
                                                               2.0*METRIC[GYZ]*(U[VY] + METRIC[SHIFTY])*(U[VZ] + METRIC[SHIFTZ]) +
                                                               METRIC[GZZ]* SQR(U[VZ] + METRIC[SHIFTZ]) )*SQR(ONE_OVER_LAPSE);

         // A = 1.0-one_minus_one_over_alpha_u0_squared = 1-(1-1/(al u0)^2) = 1/(al u0)^2
         // 1/sqrt(A) = al u0
         //CCTK_REAL alpha_u0_minus_one = 1.0/sqrt(1.0-one_minus_one_over_alpha_u0_squared)-1.0;
         //uUP[0]          = (alpha_u0_minus_one + 1.0)*ONE_OVER_LAPSE;
         CCTK_REAL alpha_u0 = 1.0/sqrt(1.0-one_minus_one_over_alpha_u0_squared);
         uUP[0] = alpha_u0*ONE_OVER_LAPSE;


         for(int ii=0;ii<3;ii++) uUP[UX+ii] = uUP[0]*U[VX+ii];
  
         CCTK_REAL g4dn[4][4];
         CCTK_REAL LAPSE_SQUARED=SQR(METRIC_LAP_PSI4[LAPSE]);
         CCTK_REAL BETADN[4],BETAUP[4] = { 0.0, METRIC[SHIFTX],METRIC[SHIFTY],METRIC[SHIFTZ] };
         lower_4vector_output_spatial_part(METRIC_LAP_PSI4[PSI4],METRIC,BETAUP, BETADN);

         // g_{00} = - alpha^2 + gamma_{ij} beta^i beta^j = - alpha^2 beta_i beta^i
         g4dn[0][0] = -LAPSE_SQUARED + (BETAUP[1]*BETADN[1] + BETAUP[2]*BETADN[2] + BETAUP[3]*BETADN[3]);
         // g_{0i} =  gamma_{ij} beta^j = beta_i
         g4dn[0][1] = g4dn[1][0] = BETADN[1];
         g4dn[0][2] = g4dn[2][0] = BETADN[2];
         g4dn[0][3] = g4dn[3][0] = BETADN[3];
         // g_{ij} =  gamma_{ij} = Psi^4 \tilde{gamma_ij}
         g4dn[1][1] =              METRIC[GXX]*METRIC_LAP_PSI4[PSI4];
         g4dn[1][2] = g4dn[2][1] = METRIC[GXY]*METRIC_LAP_PSI4[PSI4];
         g4dn[1][3] = g4dn[3][1] = METRIC[GXZ]*METRIC_LAP_PSI4[PSI4];
         g4dn[2][2] =              METRIC[GYY]*METRIC_LAP_PSI4[PSI4];
         g4dn[2][3] = g4dn[3][2] = METRIC[GYZ]*METRIC_LAP_PSI4[PSI4];
         g4dn[3][3] =              METRIC[GZZ]*METRIC_LAP_PSI4[PSI4];

         
         for(int ind=0;ind<4;ind++) {
             uDN[ind]=0.0; for(int jj=0;jj<4;jj++) uDN[ind] += uUP[jj]*g4dn[ind][jj];
          }

         // we only want to activate the cooling process if the eps_th is positive, otherwise we get heating instead of cooling

         if (eps_th > 0) {
             CCTK_REAL tau_modification = -METRIC_LAP_PSI4[LAPSE]*alpha_sqrtgamma*lambda_cooling;
             CCTK_REAL st_modification = -alpha_sqrtgamma*lambda_cooling;

             tau_rhs[index]  += tau_modification*uUP[0];
             st_x_rhs[index] += st_modification*uDN[1];
             st_y_rhs[index] += st_modification*uDN[2];
             st_z_rhs[index] += st_modification*uDN[3];
            }

         // To check if the cooling works well and compare the result of the rest-mass density with manual calculations, we can use the following command:
         // printf("/t %f",eps_th+eps_cold);


	}

      }

}






