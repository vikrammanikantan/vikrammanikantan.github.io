//----------------------------------------------------------------------------
//
// $Id: $
//
//----------------------------------------------------------------------------
//
// Contains methods for integrating the OV equations
//
//----------------------------------------------------------------------------

#include "cctk.h"
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"

#include <stdio.h>
#include <math.h>
#include <iostream>
#include <iomanip>
//#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <fstream>

//#define PI acos(-1.0) // <-- BAD.  Use M_PI.
#define N_INT 1000
#define FREE_ARG char*
#define NR_END 1

#define velx (&vel[0*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])
#define vely (&vel[1*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])
#define velz (&vel[2*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])
#define velx_p (&vel_p[0*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])
#define vely_p (&vel_p[1*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])
#define velz_p (&vel_p[2*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])
#define velx_p_p (&vel_p_p[0*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])
#define vely_p_p (&vel_p_p[1*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])
#define velz_p_p (&vel_p_p[2*cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]])

#define SQ(x) ((x)*(x))              /* square macro */

void Setup_Hybrid_EOS_magnetar(double K_poly, double n, char * eos_file,int neos,double *rho_tab,double *P_tab,double *eps_tab,double *k_tab,double *gamma_tab);
void polar_derivs(double **f, double **f1, double **f2,
                  double **f12,
                  int NS, int NU, double RADEQUAT);
double bicub_int(double **f, int NS, int NU,
                 double RADEQUAT,
                 double riso, double theta,
                 double **f1, double **f2, double **f12);
void bcuint(double *y, double *y1, double *y2, double *y12, double x1l,
            double x1u, double x2l, double x2u, double x1, double x2,
            double & ansy, double & ansy1, double & ansy2);
void bcucof(double *y, double *y1, double *y2, double *y12,
            double d1, double d2, double **c);
double **dmatrix(long nrl, long nrh, long ncl, long nch)
/* allocate a double matrix with subscript range m[nrl..nrh][ncl..nch] */
{
        long i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
        double **m;

        /* allocate pointers to rows */
        m=(double **) malloc((size_t)((nrow+NR_END)*sizeof(double*)));
        if (!m) CCTK_WARN(0, "allocation failure 1 in matrix()");
        m += NR_END;
        m -= nrl;

        /* allocate rows and set pointers to them */
        m[nrl]=(double *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double)));
        if (!m[nrl]) CCTK_WARN(0, "allocation failure 2 in matrix()");
        m[nrl] += NR_END;
        m[nrl] -= ncl;

        for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;

        /* return pointer to array of pointers to rows */
        return m;
}
void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch)
/* free a double matrix allocated by dmatrix() */
{
        free((FREE_ARG) (m[nrl]+ncl-NR_END));
        free((FREE_ARG) (m+nrl-NR_END));
}

static char *rcsid = "$Meow...$";
CCTK_FILEVERSION(Magnetar_initialdata_readfiles)

extern "C" void Magnetar_initialdata_readfiles(CCTK_ARGUMENTS)
{
  using namespace std;
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  int NS,NU;
  double COMEGA, ROTFUNC, RADEQUAT_TEMP,n;

  double *ri, *mui, **pol_p0, **pol_alphi, **pol_rhoi, **pol_gami, **pol_omgi;
  double **pol_omgv, **pol_vOm;
  double **dr_p0, **dt_p0, **drt_p0;
  double **dr_alphi, **dt_alphi, **drt_alphi;
  double **dr_rhoi, **dt_rhoi, **drt_rhoi;
  double **dr_gami, **dt_gami, **drt_gami;
  double **dr_omgi, **dt_omgi, **drt_omgi;
  double **dr_omgv, **dt_omgv, **drt_omgv;
  ifstream pdat(rns_dat_file);
  if( !pdat) {
    cerr << "Error opening RNS data file" << endl;
    exit (1);
  }
  double Mass = 0.2;
  char buf[100],c;
  double RestMass, AngM;
  pdat.get(buf,100,'='); pdat.get(c); pdat >> RestMass;
  pdat.get(buf,100,'='); pdat.get(c); pdat >> AngM;
  pdat.get(buf,100,'='); pdat.get(c); pdat >> Mass;

  pdat >> NS >> NU;
  pdat >> RADEQUAT_TEMP >> n >> COMEGA >> ROTFUNC;
  cout << "RestMass = " << RestMass << endl;
  cout << "RADEQUAT_TEMP = " << RADEQUAT_TEMP << endl;
  cout << "Ang Mom = " << AngM << endl;
  cout << "ADM mass = " << Mass << endl;
  cout << "NS, NU = " << NS << "   " << NU << endl;
  cout << "COMEGA = " << COMEGA
       << ", ROTFUNC = " << ROTFUNC
       << ", n = " << n << endl;

  ri = new double[NS];
  mui = new double[NU+1];
  pol_p0 = new double*[NS];
  pol_alphi = new double*[NS];
  pol_rhoi = new double*[NS];
  pol_gami = new double*[NS];
  pol_omgv = new double*[NS];
  pol_omgi = new double*[NS];

  dr_p0 = new double*[NS];
  dr_alphi = new double*[NS];
  dr_rhoi = new double*[NS];
  dr_gami = new double*[NS];
  dr_omgv = new double*[NS];
  dr_omgi = new double*[NS];

  dt_p0 = new double*[NS];
  dt_alphi = new double*[NS];
  dt_rhoi = new double*[NS];
  dt_gami = new double*[NS];
  dt_omgv = new double*[NS];
  dt_omgi = new double*[NS];

  drt_p0 = new double*[NS];
  drt_alphi = new double*[NS];
  drt_rhoi = new double*[NS];
  drt_gami = new double*[NS];
  drt_omgv = new double*[NS];
  drt_omgi = new double*[NS];

  for(int i=0; i<NS; i++) {
    pol_p0[i] = new double[NU+1];
    pol_alphi[i] = new double[NU+1];
    pol_rhoi[i] = new double[NU+1];
    pol_gami[i] = new double[NU+1];
    pol_omgv[i] = new double[NU+1];
    pol_omgi[i] = new double[NU+1];

    dr_p0[i] = new double[NU+1];
    dr_alphi[i] = new double[NU+1];
    dr_rhoi[i] = new double[NU+1];
    dr_gami[i] = new double[NU+1];
    dr_omgv[i] = new double[NU+1];
    dr_omgi[i] = new double[NU+1];

    dt_p0[i] = new double[NU+1];
    dt_alphi[i] = new double[NU+1];
    dt_rhoi[i] = new double[NU+1];
    dt_gami[i] = new double[NU+1];
    dt_omgv[i] = new double[NU+1];
    dt_omgi[i] = new double[NU+1];

    drt_p0[i] = new double[NU+1];
    drt_alphi[i] = new double[NU+1];
    drt_rhoi[i] = new double[NU+1];
    drt_gami[i] = new double[NU+1];
    drt_omgv[i] = new double[NU+1];
    drt_omgi[i] = new double[NU+1];
  }
  for(int i=0; i<NS; i++) {
    for(int j=0; j<=NU; j++) {
      pdat >> ri[i] >> mui[j] >> pol_p0[i][j] >> pol_alphi[i][j]
           >> pol_rhoi[i][j] >> pol_gami[i][j] >> pol_omgi[i][j]
           >> pol_omgv[i][j];
    }
  }
  for(int i=0; i<NS; i++)
    for(int j=0; j<=NU; j++) {
      pol_omgi[i][j] = pol_omgi[i][j]/RADEQUAT_TEMP;
      pol_omgv[i][j] = pol_omgv[i][j]/RADEQUAT_TEMP;
    }


  polar_derivs(pol_p0,dr_p0,dt_p0,drt_p0,NS,NU,RADEQUAT_TEMP);
  polar_derivs(pol_alphi,dr_alphi,dt_alphi,drt_alphi,NS,NU,RADEQUAT_TEMP);
  polar_derivs(pol_rhoi,dr_rhoi,dt_rhoi,drt_rhoi,NS,NU,RADEQUAT_TEMP);
  polar_derivs(pol_gami,dr_gami,dt_gami,drt_gami,NS,NU,RADEQUAT_TEMP);
  polar_derivs(pol_omgi,dr_omgi,dt_omgi,drt_omgi,NS,NU,RADEQUAT_TEMP);
  polar_derivs(pol_omgv,dr_omgv,dt_omgv,drt_omgv,NS,NU,RADEQUAT_TEMP);

  double L[3][3];
  double R,Rho,R1,R2,phi1,phi2,t,u;
  double en_den,alpa,rho_m,gam,omg_m,omg_v;
  double grr,gtt,gpp;
  double riso;

  int istart = 0;
  int jstart = 0;
  int kstart = 0;
  int iend = cctk_lsh[0];
  int jend = cctk_lsh[1];
  int kend = cctk_lsh[2];

  // for (int vindex=0; vindex < kend*jend*iend; vindex++){
  for(int k=0;k<cctk_lsh[2];k++) for(int j=0;j<cctk_lsh[1];j++) for(int i=0;i<cctk_lsh[0];i++) {
        int vindex=CCTK_GFINDEX3D(cctkGH,i,j,k);
    R=sqrt(x[vindex]*x[vindex]+y[vindex]*y[vindex]+z[vindex]*z[vindex]);
    Rho = sqrt( x[vindex]*x[vindex]+y[vindex]*y[vindex] );
    riso = R;

    double sint = Rho/R;
    double phi, drho;
    double sinphi = y[vindex] / Rho;

    double cost = sqrt(1.0 - sint*sint);
    double theta_ang = acos(cost);
    double phi_ang = atan2(y[vindex],x[vindex]);
    //
    // Interpolate metric functions to gridpoint
    //
    en_den = bicub_int(pol_p0,NS,NU,RADEQUAT_TEMP,riso,theta_ang,
                       dr_p0,dt_p0,drt_p0);
    alpa    = bicub_int(pol_alphi,NS,NU,RADEQUAT_TEMP,riso,theta_ang,
                       dr_alphi,dt_alphi,drt_alphi);
    rho_m  = bicub_int(pol_rhoi,NS,NU,RADEQUAT_TEMP,riso,theta_ang,
                       dr_rhoi,dt_rhoi,drt_rhoi);
    gam    = bicub_int(pol_gami,NS,NU,RADEQUAT_TEMP,riso,theta_ang,
                       dr_gami,dt_gami,drt_gami);
    omg_v  = bicub_int(pol_omgv,NS,NU,RADEQUAT_TEMP,riso,theta_ang,
                       dr_omgv,dt_omgv,drt_omgv);
    omg_m  = bicub_int(pol_omgi,NS,NU,RADEQUAT_TEMP,riso,theta_ang,
                       dr_omgi,dt_omgi,drt_omgi);

    rho[vindex] = en_den  > rho_0_atm  ? en_den : rho_0_atm;


    // Assumes K = 1
    press[vindex]     = pow(rho[vindex], Poly_Gamma);
    eps[vindex] = press[vindex] / (rho[vindex] * (Poly_Gamma - 1));

    if(strcmp(add_perturbation, "yes") == 0 && rho[vindex] != rho_0_atm){
      /* Compute phi in the correct quadrant */
      if (x[vindex] >= 0 && y[vindex] > 0){
        phi = asin(sinphi);
      } else if (x[vindex] >= 0 && y[vindex] < 0){
        phi = asin(sinphi);
      } else if (x[vindex] < 0 && y[vindex] > 0){
        phi = M_PI - asin(sinphi);
      } else if (x[vindex] < 0 && y[vindex] < 0){
        phi = M_PI - asin(sinphi);
      } else {
        phi = 0;
      }

      drho = rho[vindex]*pert_amplitude*Rho*sin(pert_m*phi);

      if(drho>0.0) rho[vindex] += drho;

      if(strcmp(recompute_thermodynamical_quantities, "yes") == 0){
        press[vindex]     = pow(rho[vindex], Poly_Gamma);
        eps[vindex] = press[vindex] / (rho[vindex] * (Poly_Gamma - 1));
      }
    }

    if (i == 85 && j == 5 && k == 77) printf("RHO %g PRESS %g\n", rho[vindex], press[vindex]);

    //
    // Get physical metric in Cartesian coordinates
    //
    L[0][0] = x[vindex]/R;
    L[0][1] = y[vindex]/R;
    L[0][2] = z[vindex]/R;
    L[1][0] = x[vindex]*z[vindex]/(R*R * Rho);
    L[1][1] = y[vindex]*z[vindex]/(R*R * Rho);
    L[1][2] = - Rho/(R*R);
    L[2][0] = - y[vindex]/(Rho*Rho);
    L[2][1] = x[vindex]/(Rho*Rho);
    L[2][2] = 0.0;

    //WARNING: DO NOT USE thetaangle as defined below in the bicub_int statements!
    //         This screws up equatorial symmetries.
    double thetaangle=atan2(Rho,z[vindex]);
    double phiangle=atan2(y[vindex],x[vindex]);

    double sintheta = Rho/R; //sin(thetaangle);
    thetaangle=asin(sintheta);
    double costheta = cos(thetaangle);
    double cosphi = cos(phiangle);

    L[0][0] = sintheta*cosphi;
    L[0][1] = sintheta*sinphi;
    L[0][2] = costheta;
    L[1][0] = costheta*cosphi/R;
    L[1][1] = costheta*sinphi/R;
    L[1][2] = - sintheta/R;
    L[2][0] = - sinphi/(R*sintheta);
    L[2][1] = cosphi/(R*sintheta);
    L[2][2] = 0.0;

    grr = exp(2.0*alpa);
    gtt = riso*riso*exp(2.0*alpa);
    gpp = riso*riso*sintheta*sintheta*exp(gam-rho_m);
    gxx[vindex] = pow(L[0][0],2)*grr
      + pow(L[1][0],2)*gtt + pow(L[2][0],2)*gpp;
    //if(x[vindex]>0 && y[vindex]>0 && z[vindex]>0) printf("%e\t%e\t%e\t%e\t%e\t%e\t%e\t%e\n",x[vindex],y[vindex],z[vindex],gxx[vindex],pow(L[0][0],2),grr,gtt,gpp);
    gxy[vindex] = L[0][0]*L[0][1]*grr
      + L[1][0]*L[1][1]*gtt + L[2][0]*L[2][1]*gpp;
    gxz[vindex] = L[0][0]*L[0][2]*grr
      + L[1][0]*L[1][2]*gtt + L[2][0]*L[2][2]*gpp;
    gyy[vindex] = pow(L[0][1],2)*grr
      + pow(L[1][1],2)*gtt + pow(L[2][1],2)*gpp;
    gyz[vindex] = L[0][1]*L[0][2]*grr
      + L[1][1]*L[1][2]*gtt + L[2][1]*L[2][2]*gpp;
    gzz[vindex] = pow(L[0][2],2)*grr
      + pow(L[1][2],2)*gtt + pow(L[2][2],2)*gpp;
    if(fabs(sintheta)<1e-8) { printf("HI. %e %e %e %e %e %e\n",gxx[vindex],gxy[vindex],gxz[vindex],gyy[vindex],gyz[vindex],gzz[vindex]); }
    //
    // Set gauge functions
    //
    alp[vindex] = exp(0.5*(gam+rho_m));

    betax[vindex] = y[vindex]*omg_m;
    betay[vindex] = -x[vindex]*omg_m;
    betaz[vindex] = 0.0;
    dtbetax[vindex] = 0.0;
    dtbetay[vindex] = 0.0;
    dtbetaz[vindex] = 0.0;
    dtalp[vindex] = 0.0;


    if (en_den > rho_0_atm){

      velx[vindex] = (omg_m - omg_v) * y[vindex] / alp[vindex];
      vely[vindex] = -(omg_m - omg_v) * x[vindex] / alp[vindex];
      velz[vindex] = 0.0;

      // if (fabs(x[vindex] - 0.5) < 0.3 && fabs(y[vindex] - 0.5) < 0.3 && fabs(z[vindex] - 0.5) < 0.3)
      //   printf("riso %g R %g x %g y %g z %g B %g vx %g vy %g alp %g omega %g Omega %g rho %g\n", riso, R, x[vindex], y[vindex], z[vindex], B, velx[vindex], vely[vindex], alp[vindex], omg_m, omg_v, rho[vindex]);

        w_lorentz[vindex] = 1.0/sqrt(1.0-gxx[vindex]*SQ(velx[vindex])
                                  -gyy[vindex]*SQ(vely[vindex])
                                  -gzz[vindex]*SQ(velz[vindex])
                                  -2.0*gxy[vindex]*velx[vindex]*vely[vindex]
                                  -2.0*gyz[vindex]*vely[vindex]*velz[vindex]
                                  -2.0*gxz[vindex]*velx[vindex]*velz[vindex]);

    }else{                      // Atmosphere
      velx[vindex] = 0.0;
      vely[vindex] = 0.0;
      velz[vindex] = 0.0;
      w_lorentz[vindex] = 1.0;
    }


    if(gxx[vindex]!=gxx[vindex]) { CCTK_WARN(0, "FOUND A NAN! Do you have the origin on the grid? Try offesting the grid\n"); }
  }


    if (CCTK_ActiveTimeLevels(cctkGH, "ADMBase::metric") > 1)
    {
      #pragma omp parallel for
      for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
        {
          gxx_p[i] = gxx[i];
          gyy_p[i] = gyy[i];
          gzz_p[i] = gzz[i];
          gxy_p[i] = gxy[i];
          gxz_p[i] = gxz[i];
          gyz_p[i] = gyz[i];
        }
      if (CCTK_ActiveTimeLevels(cctkGH, "ADMBase::metric") > 2)
        {
          for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
            {
              gxx_p_p[i] = gxx[i];
              gyy_p_p[i] = gyy[i];
              gzz_p_p[i] = gzz[i];
              gxy_p_p[i] = gxy[i];
              gxz_p_p[i] = gxz[i];
              gyz_p_p[i] = gyz[i];
            }
        }
    }

  if (CCTK_ActiveTimeLevels(cctkGH, "ADMBase::lapse") > 1)
    {
      #pragma omp parallel for
      for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
        {
          alp_p[i] = alp[i];
          dtalp_p[i] = dtalp[i];
        }
      if (CCTK_ActiveTimeLevels(cctkGH, "ADMBase::lapse") > 2)
        {
          #pragma omp parallel for
          for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
            {
              alp_p_p[i] = alp[i];
              dtalp_p_p[i] = dtalp[i];
            }
        }
    }

  if (CCTK_ActiveTimeLevels(cctkGH, "ADMBase::shift") > 1)
    {
      #pragma omp parallel for
      for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
        {
          betax_p[i] = betax[i];
          betay_p[i] = betay[i];
          betaz_p[i] = betaz[i];
          dtbetax_p[i] = dtbetax[i];
          dtbetay_p[i] = dtbetay[i];
          dtbetaz_p[i] = dtbetaz[i];
        }
      if (CCTK_ActiveTimeLevels(cctkGH, "ADMBase::shift") > 2)
        {
          #pragma omp parallel for
          for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
            {
              betax_p_p[i] = betax[i];
              betay_p_p[i] = betay[i];
              betaz_p_p[i] = betaz[i];
              dtbetax_p_p[i] = dtbetax[i];
              dtbetay_p_p[i] = dtbetay[i];
              dtbetaz_p_p[i] = dtbetaz[i];
            }
        }
    }

  if (CCTK_ActiveTimeLevels(cctkGH, "HydroBase::rho") > 1)
    {
      #pragma omp parallel for
      for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
        {
          rho_p[i] = rho[i];
          velx_p[i] = velx[i];
          vely_p[i] = vely[i];
          velz_p[i] = velz[i];
          press_p[i] = press[i];
          eps_p[i] = eps[i];
          w_lorentz_p[i] = w_lorentz[i];
        }
      if (CCTK_ActiveTimeLevels(cctkGH, "HydroBase::rho") > 2)
        {
          #pragma omp parallel for
          for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
            {
              rho_p_p[i] = rho[i];
              velx_p_p[i] = velx[i];
              vely_p_p[i] = vely[i];
              velz_p_p[i] = velz[i];
              press_p_p[i] = press[i];
              eps_p_p[i] = eps[i];
              w_lorentz_p_p[i] = w_lorentz[i];
            }
        }
    }

  //
  // Free memory
  //

  delete[] ri;
  delete[] mui;
  delete[] pol_p0;
  delete[] pol_alphi;
  delete[] pol_rhoi;
  delete[] pol_gami;
  delete[] pol_omgi;
  delete[] pol_omgv;

  delete[] dr_p0;
  delete[] dr_alphi;
  delete[] dr_rhoi;
  delete[] dr_gami;
  delete[] dr_omgi;
  delete[] dr_omgv;

  delete[] dt_p0;
  delete[] dt_alphi;
  delete[] dt_rhoi;
  delete[] dt_gami;
  delete[] dt_omgi;
  delete[] dt_omgv;

  delete[] drt_p0;
  delete[] drt_alphi;
  delete[] drt_rhoi;
  delete[] drt_gami;
  delete[] drt_omgi;
  delete[] drt_omgv;

}

double bicub_int(double **f, int NS, int NU,
                 double RADEQUAT,
                 double riso, double theta,
                 double **f1, double **f2, double **f12)
{
  int l,m;
  double cost = cos(theta);
  l = int(riso*NS/(RADEQUAT+riso));
  m = int(cost*NU);
  if(m > NU-1) m = NU-1;
  if (l>NS-2) {
     printf("Outer boundary too far away!\n");
     printf("Set a smaller outer boundary so that a proper interpolation can be done from data in rns.dat.\n");
     exit(1);
  }

  double R1,R2,thet1,thet2;
  R1 = RADEQUAT*l/(NS-l);
  R2 = RADEQUAT*(l+1)/(NS-l-1);
  thet1 = acos(double(m)/double(NU));
  thet2 = acos(double(m+1)/double(NU));
  double y[5], y1[5], y2[5], y12[5];
  // function
  y[1] = f[l][m];       y[2] = f[l+1][m];
  y[3] = f[l+1][m+1];   y[4] = f[l][m+1];
  // r derivatives
  y1[1] = f1[l][m];       y1[2] = f1[l+1][m];
  y1[3] = f1[l+1][m+1];   y1[4] = f1[l][m+1];
  // theta derivatives
  y2[1] = f2[l][m];       y2[2] = f2[l+1][m];
  y2[3] = f2[l+1][m+1];   y2[4] = f2[l][m+1];
  // mixed derivatives
  y12[1] = f12[l][m];       y12[2] = f12[l+1][m];
  y12[3] = f12[l+1][m+1];   y12[4] = f12[l][m+1];

  // interpolate
  double f_out,f1_out,f2_out;
  bcuint(y,y1,y2,y12,R1,R2,thet1,thet2,riso,theta,
         f_out,f1_out,f2_out);
  return f_out;
}


void polar_derivs(double **f, double **f1, double **f2,
                  double **f12,
                  int NS, int NU, double RADEQUAT)
{
  int l,m;
  double *rg, *thg;
  rg = new double[NS];
  thg = new double[NU+1];
  for(l=0; l<NS; l++)
    rg[l] = RADEQUAT*l/(NS-l);
  for(m=0; m<=NU; m++)
    thg[m] = acos(double(m)/double(NU));

  // r derivatives
  for(m=0; m<=NU; m++) {
    f1[0][m] = (f[1][m] - f[0][m])/(rg[1]-rg[0]);
    for(l=1; l<NS-1; l++)
      f1[l][m] = (f[l+1][m]-f[l-1][m])/(rg[l+1]-rg[l-1]);
    f1[NS-1][m] = (f[NS-1][m]-f[NS-2][m])/(rg[NS-1]-rg[NS-2]);
  }
  // theta derivatives
  for(l=0; l<NS; l++) {
    f2[l][0] = (f[l][1] - f[l][0])/(thg[1]-thg[0]);
    for(m=1; m<NU; m++)
      f2[l][m] = (f[l][m+1]-f[l][m-1])/(thg[m+1]-thg[m-1]);
    //      f2[l][NU] = (f[l][NU]-f[l][NU-1])/(thg[NU]-thg[NU-1]);
    f2[l][NU] = 0.0;
  }
  // mixed derivatives
  for(l=0; l<NS; l++) {
    f12[l][0] = (f1[l][1] - f1[l][0])/(thg[1]-thg[0]);
    for(m=1; m<NU; m++)
      f12[l][m] = (f1[l][m+1]-f1[l][m-1])/(thg[m+1]-thg[m-1]);
    //      f12[l][NU] = (f1[l][NU]-f1[l][NU-1])/(thg[NU]-thg[NU-1]);
    f12[l][NU] = 0.0;
  }
}

void bcuint(double *y, double *y1, double *y2, double *y12,
            double x1l,double x1u, double x2l, double x2u,
            double x1, double x2,double & ansy, double & ansy1, double & ansy2) {
  /*   void bcucof(double *y, double *y1, double *y2, double *y12, */
  /*               double d1, double d2, double **c); */
  int i;
  double t,u,d1,d2,**c;

  c=dmatrix(1,4,1,4);
  d1=x1u-x1l;
  d2=x2u-x2l;
  bcucof(y,y1,y2,y12,d1,d2,c);
  if (x1u == x1l || x2u == x2l) { printf("ERROR: %e %e %e %e\n",x1u,x1l,x2u,x2l); CCTK_WARN(0, "Bad input in routine bcuint"); }
  t=(x1-x1l)/d1;
  u=(x2-x2l)/d2;
  ansy = ansy2 = ansy1 = 0.0;
  for (i=4;i>=1;i--) {
    ansy=t*ansy + ((c[i][4]*u+c[i][3])*u+c[i][2])*u + c[i][1];
    ansy2=t*ansy2 + (3.0*c[i][4]*u+2.0*c[i][3])*u + c[i][2];
    ansy1=u*ansy1 + (3.0*c[4][i]*t+2.0*c[3][i])*t + c[2][i];
  }
  ansy1 /= d1;
  ansy2 /= d2;
  free_dmatrix(c,1,4,1,4);
}

void bcucof(double *y, double *y1, double *y2, double *y12,
            double d1, double d2, double **c) {
  static int wt[16][16]=
    { 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,
      -3,0,0,3,0,0,0,0,-2,0,0,-1,0,0,0,0,
      2,0,0,-2,0,0,0,0,1,0,0,1,0,0,0,0,
      0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,
      0,0,0,0,-3,0,0,3,0,0,0,0,-2,0,0,-1,
      0,0,0,0,2,0,0,-2,0,0,0,0,1,0,0,1,
      -3,3,0,0,-2,-1,0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,0,-3,3,0,0,-2,-1,0,0,
      9,-9,9,-9,6,3,-3,-6,6,-6,-3,3,4,2,1,2,
      -6,6,-6,6,-4,-2,2,4,-3,3,3,-3,-2,-1,-1,-2,
      2,-2,0,0,1,1,0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,0,2,-2,0,0,1,1,0,0,
      -6,6,-6,6,-3,-3,3,3,-4,4,2,-2,-2,-2,-1,-1,
      4,-4,4,-4,2,2,-2,-2,2,-2,-2,2,1,1,1,1};
  int l,k,j,i;
  double xx,d1d2,cl[16],x[16];

  d1d2=d1*d2;
  for (i=1;i<=4;i++) {
    x[i-1]=y[i];
    x[i+3]=y1[i]*d1;
    x[i+7]=y2[i]*d2;
    x[i+11]=y12[i]*d1d2;
  }
  for (i=0;i<=15;i++) {
    xx=0.0;
    for (k=0;k<=15;k++) xx += wt[i][k]*x[k];
    cl[i]=xx;
  }
  l=0;
  for (i=1;i<=4;i++)
    for (j=1;j<=4;j++) c[i][j]=cl[l++];
}


extern "C" void sync_curv(CCTK_ARGUMENTS){
  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

    if (CCTK_ActiveTimeLevels(cctkGH, "ADMBase::curv") > 1)
    {
      #pragma omp parallel for
      for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
        {
          kxx_p[i] = kxx[i];
          kyy_p[i] = kyy[i];
          kzz_p[i] = kzz[i];
          kxy_p[i] = kxy[i];
          kxz_p[i] = kxz[i];
          kyz_p[i] = kyz[i];
        }
      if (CCTK_ActiveTimeLevels(cctkGH, "ADMBase::curv") > 2)
        {
          #pragma omp parallel for
          for(int i = 0; i < cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; i++)
            {
              kxx_p_p[i] = kxx[i];
              kyy_p_p[i] = kyy[i];
              kzz_p_p[i] = kzz[i];
              kxy_p_p[i] = kxy[i];
              kxz_p_p[i] = kxz[i];
              kyz_p_p[i] = kyz[i];
            }
        }
    }

    return;
}

void Cook_CheckParameters(CCTK_ARGUMENTS)
{
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  if (timelevels < 2)
  {
      CCTK_PARAMWARN("You have to set 'HydroBase::timelevels to at least 2");
  }
}
