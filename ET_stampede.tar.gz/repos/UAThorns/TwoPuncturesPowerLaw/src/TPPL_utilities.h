/* TwoPuncturesPowerLaw:  File  "utilities.h"*/

#include <math.h>

#include "cctk.h"

#define Pi  3.14159265358979323846264338328
#define Pih 1.57079632679489661923132169164	/* Pi/2*/
#define Piq 0.78539816339744830961566084582	/* Pi/4*/

#define TINY 1.0e-20
#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;}

#define nrerror TPPL_nrerror
#define TPPL_ivector TPPL_TPPL_ivector
#define TPPL_dvector TPPL_TPPL_dvector
#define TPPL_imatrix TPPL_TPPL_imatrix
#define TPPL_dmatrix TPPL_TPPL_dmatrix
#define TPPL_d3tensor TPPL_TPPL_d3tensor
#define free_TPPL_ivector TPPL_free_TPPL_ivector
#define free_TPPL_dvector TPPL_free_TPPL_dvector
#define free_TPPL_imatrix TPPL_free_TPPL_imatrix
#define free_TPPL_dmatrix TPPL_free_TPPL_dmatrix
#define free_TPPL_d3tensor TPPL_free_TPPL_d3tensor

#define TPPL_minimum2 TPPL_TPPL_minimum2
#define TPPL_minimum3 TPPL_TPPL_minimum3
#define TPPL_maximum2 TPPL_TPPL_maximum2
#define TPPL_maximum3 TPPL_TPPL_maximum3
#define TPPL_pow_int TPPL_TPPL_pow_int

#define TPPL_chebft_Zeros TPPL_TPPL_chebft_Zeros
#define TPPL_chebft_Extremes TPPL_TPPL_chebft_Extremes
#define TPPL_chder TPPL_TPPL_chder
#define TPPL_chebev TPPL_TPPL_chebev
#define TPPL_fourft TPPL_TPPL_fourft
#define TPPL_fourder TPPL_TPPL_fourder
#define TPPL_fourder2 TPPL_TPPL_fourder2
#define TPPL_fourev TPPL_TPPL_fourev

#define TPPL_norm1 TPPL_TPPL_norm1
#define TPPL_norm2 TPPL_TPPL_norm2
#define TPPL_scalarproduct TPPL_TPPL_scalarproduct

void nrerror (char error_text[]);
int *TPPL_ivector (long nl, long nh);
CCTK_REAL *TPPL_dvector (long nl, long nh);
int **TPPL_imatrix (long nrl, long nrh, long ncl, long nch);
CCTK_REAL **TPPL_dmatrix (long nrl, long nrh, long ncl, long nch);
CCTK_REAL ***TPPL_d3tensor (long nrl, long nrh, long ncl, long nch, long ndl,
		    long ndh);
void free_TPPL_ivector (int *v, long nl, long nh);
void free_TPPL_dvector (CCTK_REAL *v, long nl, long nh);
void free_TPPL_imatrix (int **m, long nrl, long nrh, long ncl, long nch);
void free_TPPL_dmatrix (CCTK_REAL **m, long nrl, long nrh, long ncl, long nch);
void free_TPPL_d3tensor (CCTK_REAL ***t, long nrl, long nrh, long ncl, long nch,
		    long ndl, long ndh);

int TPPL_minimum2 (int i, int j);
int TPPL_minimum3 (int i, int j, int k);
int TPPL_maximum2 (int i, int j);
int TPPL_maximum3 (int i, int j, int k);
int TPPL_pow_int (int mantisse, int exponent);

void TPPL_chebft_Zeros (CCTK_REAL u[], int n, int inv);
void TPPL_chebft_Extremes (CCTK_REAL u[], int n, int inv);
void TPPL_chder (CCTK_REAL *c, CCTK_REAL *cder, int n);
CCTK_REAL TPPL_chebev (CCTK_REAL a, CCTK_REAL b, CCTK_REAL c[], int m, CCTK_REAL x);
void TPPL_fourft (CCTK_REAL *u, int N, int inv);
void TPPL_fourder (CCTK_REAL u[], CCTK_REAL du[], int N);
void TPPL_fourder2 (CCTK_REAL u[], CCTK_REAL d2u[], int N);
CCTK_REAL TPPL_fourev (CCTK_REAL *u, int N, CCTK_REAL x);


CCTK_REAL TPPL_norm1 (CCTK_REAL *v, int n);
CCTK_REAL TPPL_norm2 (CCTK_REAL *v, int n);
CCTK_REAL TPPL_scalarproduct (CCTK_REAL *v, CCTK_REAL *w, int n);
