## UAThorns  ##
# Utilities for Einstein Toolkit developed at University of Arizona #

This repo contains in the master branch:

  * `RNSID`: Generate differentially rotating stars compatible with GRHydro
    and IllinoisGRMHD

  * `LapseFinder`: Find the location of the minimum of the lapse

  * `RhoBFinder`: Find the location of the maximum of the baryon density

  * `UADiagnostics`: Compute ADMMass, ADMAngularMomentum and Charge as surface integrals

  * `NSTracker`: Move the refinement levels according to LapseFinder or RhoBTracker

  * `simfactory`: Machine configurations to compile ET

  * `thornlists`: Thornlists that include some useful combinations of thorns

  * `ProcaConstraint`: Compute the violation of the Lorentz gauge/electric constraint

  * `Proca_LFlux`: Compute the angular momentum radiated away by electromagnetic waves
  (tested with Test_LFlux, with the Michel solution)

Par files and thornlists available:

  * `turning_points`: Simulations of collapse of differentially rotating stars.
  In `generated` there is a script that produces the par files baed on the skeletons
  `M.par` and `P.par`.

  * `fragmentation`: Simulations of fragmentation of differentially rotating stars.

  * `test_RNS`: Tests for RNSID

  * `test_Cook`: Tests for CookImporter

NOTES:

  * The branch `TCP_Faraday` contains an implementation of TwoChargedPunctures independent
    of the Proca code. It is not very useful and it should not be used.
