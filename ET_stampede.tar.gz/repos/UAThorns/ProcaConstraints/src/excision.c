#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>

#include <math.h>

void initialize_horizon_mask(CCTK_ARGUMENTS){
  /* Here we prepare a mask with zeros and ones. The points with zero are inside
     an horizon, the points with one outside. */
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

#pragma omp parallel for
  for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++)
    horizon_mask[ijk] = 1.0;
}

void excise_horizon_constraints(CCTK_ARGUMENTS){
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  if(compute_every <= 0 || cctk_iteration % compute_every != 0) return;

  CCTK_REAL origin_x, origin_y, origin_z;

  CCTK_INT *N_horizons;         /* At the moment the thorn requires AHFinderDirect */
  N_horizons = ((CCTK_INT *) CCTK_ParameterGet("N_horizons", "AHFinderDirect", NULL));
  if ((N_horizons == NULL) || (*N_horizons < 0)) *N_horizons = 0;

  for (int horizon = 1; horizon <= *N_horizons; horizon++){
    if (HorizonWasFound(horizon)) {
      HorizonLocalCoordinateOrigin(horizon, &origin_x, &origin_y, &origin_z);
      if (HorizonRadiusInDirection(horizon,
                                   cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2],
                                   x, y, z,
                                   radius_h) >= 0) {
        /* #pragma omp parallel for private(i,j,k) */
#pragma omp parallel for
        for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++) {
                /* calculate the distance to the origin of the horizon */
                CCTK_REAL distance = sqrt((x[ijk]-origin_x)*(x[ijk]-origin_x) +
                                          (y[ijk]-origin_y)*(y[ijk]-origin_y) +
                                          (z[ijk]-origin_z)*(z[ijk]-origin_z));

                /* if it is inside the horizon, set the mask accordingly */
                if (distance <= radius_h[ijk])
                  horizon_mask[ijk] *= 0.0;
        }
      }
      }
    }
}

  void excise_outer_boundary(CCTK_ARGUMENTS){
    DECLARE_CCTK_ARGUMENTS
      DECLARE_CCTK_PARAMETERS

      if(compute_every <= 0 || cctk_iteration % compute_every != 0 || radius_excision_outer_boundary <= 0) return;

#pragma omp parallel for
    for(int ijk=0; ijk<cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2]; ijk++) {
      /* calculate the distance to the origin */
      CCTK_REAL distance = sqrt(x[ijk]*x[ijk]  +
                                y[ijk]*y[ijk] +
                                z[ijk]*z[ijk]);
      if (distance > radius_excision_outer_boundary)
        horizon_mask[ijk] *= 0.0;
    }
  }
