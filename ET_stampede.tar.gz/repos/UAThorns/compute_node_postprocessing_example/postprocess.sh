#!/bin/bash

# Set up environment for pycactus
export PATH=~/ekwessel/.local:~/ekwessel/.local/bin:~/ekwessel/.local/lib:$PATH
export PYTHONPATH=~/ekwessel/.local/lib/python3.5/site-packages:$PYTHONPATH
export MPLBACKEND=Agg

# Generate simreports
simrep ppi_diagnostics --repdir diagnostics_rep

# Render movies
simvideo density_velocity --cscale-max 0.0065 --cscale-min 0.0 --domain manual --xmax 2 --ymax 2 --zmax 0.6 --resume
simvideo bns_density_xyxz --cscale-max 0.0065 --cscale-min 0.0 --domain manual --xmax 2 --ymax 2 --zmax 0.6 --resume
simvideo v_vec_xyxz --domain manual --xmax 2 --ymax 2 --zmax 0.6 --resume
simvideo P_xyxz --cscale-max 0.000015 --cscale-min 0.0 --domain manual --xmax 2 --ymax 2 --zmax 0.6 --resume
simvideo lapm1_xyxz --domain manual --xmax 2 --ymax 2 --zmax 0.6 --resume

