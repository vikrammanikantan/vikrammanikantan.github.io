# Thorn and PBS Settings to Enable Compute-Node Postprocessing on BlueWaters

## Explanation

The files in this directory are examples of a way to allow simulation jobs to terminate and run a post-processing script in the last few minutes of their walltime.
This makes two improvements over our usual configuration: 
1. This setup exits the cactus process after the final checkpoint is written, avoiding the waste of continuing to integrate forward until walltime runs out, producing iterations that will not be checkpointed and will therefore be re-simulated.
2. This demonstrates the correct way to get PostCactus-based python scripts to run on a bluewaters compute node, which requires a few steps not covered by the official documentation.

While the files included in this directory are long, there are only two or three relevant lines in each. I will summarize the changes made below, if you have difficulty finding them in the given files feel free to contact me at ekwessel@email.arizona.edu

## 1: Runtime-based Termination and Checkpoint

In bh_disk.par, you will see two slight changes from our usual method:
```
#cactus::cctk_itlast = 999999999
cactus::terminate = "runtime"         
cactus::max_runtime = 540.0 # 9 hours
```
These lines change the termination condition to runtime, and set the runtime before termination in minutes
Note that the itlast parameter is commented out, we do not need it anymore.
```
IOHDF5::checkpoint          = yes
IO::checkpoint_dir          = ./output/checkpoints
IO::out_mode                = np
IO::checkpoint_ID           = no
IO::checkpoint_every        = -1
IO::checkpoint_every_walltime_hours = 8.0 # If the termination checkpoints are reliable this may not be necessary
IO::checkpoint_on_terminate = yes
# Keep all checkpoints
IO::checkpoint_keep = -1
```
Here we have changed checkpoint_on_terminate to yes, which will make cactus start writing a checkpoint as soon as the termination runtime is reached. Since there is still walltime left, will work, but the upshot is that once the checkpoint is written, cactus will exit, rather than returning to iterate more. After cactus exits, you can add additional postprocessing code that will run in the leftover walltime. This is a useful place to manage checkpoints automatically, since you can be certain that none are being written or read. However, there is a chance that if the filesystem is slow these routines may not complete within the remaining walltime, so make your methods robust to being killed early.

## 2: PostCactus Post-Processing on a Compute Node
In this example I have placed postcactus script after a cactus run, but it could also be made its own seperate job, which might be an even better way of doing things.
The most important thing to note in the postprocess.sh script, is that we must load paths to wherever our python routines are installed (check your bashrc to see if you have any custom path alterations that need to be included in the compute environment, and we must set the shell variable for Matplotlibs backend to Agg, so that a window server is not needed to produce plots.
In order to run python code, the bwpy module must be loaded, and then the script that uses python must be called via aprun using the bluewaters python environment. It is possible there are better ways, but this is what I got to work. Note that postcactus currently does not have good parallelism support, so I use only one process on one node. A better way to do things might be to seperate movies and report generation into seperate jobs on the queue, and have each movie run seperately on its own node to take advantage of parallelism. However this would be a bit more involved. There was an attempt to implement multi-threading in simvideo itself, so that frames could be rendered on seperate processors, but this failed because the postcactus datastructures do not support access by multiple threads, and race conditions quickly cause all but one process to crash. Therefore, it is not easy to take advantage of multiple processors on each node.
