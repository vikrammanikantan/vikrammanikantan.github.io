#!/bin/bash
set -e  # exit on error

# Target directory
UATHORNS_DIR="repos/UAThorns"

# Create directory if needed
mkdir -p "$UATHORNS_DIR"
cd "$UATHORNS_DIR"

# List of repositories to check out
REPOS=(
    "Outflow"
    "Convert_to_HydroBase"
    "DiskDiagnostics"
    "TwoPuncturesPowerLaw"
    "DiskPowerLaw
    "QuasiLocalMeasuresMHD"
    "IllinoisGRMHD"
    "Christoffel"
    "ID_converter_ILGRMHD"
    "Seed_Magnetic_Fields"
)

# Clone each repo if not already present
for repo in "${REPOS[@]}"; do
    if [ ! -d "$repo" ]; then
        echo "Cloning $repo..."
        git clone "git@github.com:arizona-relativity/${repo}.git"
    else
        echo "Repo $repo already exists, skipping."
    fi
done
